import express from 'express';
import { qwen } from './qwen.js';
import path from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(express.json());
app.use(express.static('public'));

const EMAIL = process.env.EMAIL;
const PASSWORD = process.env.PASSWORD;
const PORT = process.env.PORT || 3000;

let sessionToken = null;
let currentChatId = null;

// Auto-login saat server berjalan
async function initializeAi() {
    console.log("🟢 Sedang menginisialisasi Vellzyy.ai...");
    const auth = await qwen.login(EMAIL, PASSWORD);
    if (auth) {
        sessionToken = auth.token;
        currentChatId = await qwen.createSession(sessionToken);
        console.log("🟢 Vellzyy.ai siap digunakan! Chat ID:", currentChatId);
    } else {
        console.error("🔴 Gagal login. Periksa email dan password di file .env");
    }
}
initializeAi();

// API Endpoint untuk menerima pesan dari frontend
app.post('/api/chat', async (req, res) => {
    const { message } = req.body;
    
    if (!sessionToken || !currentChatId) {
        return res.status(500).json({ reply: "Sistem AI belum siap atau gagal login." });
    }

    try {
        const response = await qwen.chat(sessionToken, currentChatId, message, { 
            stream: false,
            model: "qwen-plus-2025-07-28" // Bisa disesuaikan dengan models di qwen.js
        });
        
        if (response && response.status === 'success') {
            res.json({ reply: response.response });
        } else {
            res.status(500).json({ reply: "🔴 Terjadi kesalahan saat memproses pesan." });
        }
    } catch (error) {
        res.status(500).json({ reply: "Error: " + error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
