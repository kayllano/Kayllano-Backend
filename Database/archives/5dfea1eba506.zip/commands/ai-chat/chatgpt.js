module.exports = {
    name: "chatgpt",
    aliases: ["ai", "gpt"],
    category: "ai-chat",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text || ctx.quoted?.body;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "apa itu evangelion?")
            );

        try {

            // =========================
            // FETCH AI RESPONSE
            // =========================
            const { data: res } = await axios.get(
                "https://api.lexcode.biz.id/api/ai/copilot",
                {
                    params: {
                        prompt: input,
                        model: "think-deeper"
                    },
                    timeout: 60000
                }
            );

            if (!res.success || !res.result?.text) {
                return await ctx.reply(tools.msg.info("Gagal mendapatkan respons dari AI. Coba lagi nanti."));
            }

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                richResponse: [{
                    text: res.result.text
                }]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};