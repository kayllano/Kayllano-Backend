module.exports = {
    name: "claude",
    category: "ai-chat",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text || ctx.quoted?.body;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "apa itu evangelion?")
            );

        try {
            const { data } = await axios.get(
                "https://api.pixxxry.eu.cc/ai/claude",
                {
                    params: {
                        message: input,
                        session: "default"
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result?.status)
                return await ctx.reply("Gagal mendapatkan respon dari Claude.");

            await ctx.reply({
                richResponse: [
                    {
                        text: data.result.answer
                    }
                ]
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};