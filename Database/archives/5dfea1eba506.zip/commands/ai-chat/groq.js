module.exports = {
    name: "groq",
    category: "ai-chat",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text || ctx.quoted?.body;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "apa itu evangelion?")}`
            );

        try {
            const { data } = await axios.get("https://api.synoxcloud.xyz/ai-chat/x.ai-grok-4.1", {
                params: { pesan: input },
                timeout: 30000
            });

            if (!data?.status || !data?.result?.reply)
                throw new Error("Respons API tidak valid.");

            await ctx.reply({
                richResponse: [{ text: data.result.reply }]
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};