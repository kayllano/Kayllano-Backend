const { randomUUID } = require("node:crypto");

module.exports = {
    name: "qwen",
    category: "ai-chat",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text || ctx.quoted?.body;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "apa itu evangelion?")}\n` +
                tools.msg.generateNotes([
                    `Ketik ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} reset`)} untuk mereset riwayat percakapan.`
                ])
            );

        const senderDb = ctx.db.user;

        if (input.toLowerCase() === "reset") {
            (senderDb.sessionId ||= {}).qwen = randomUUID();
            senderDb.save();
            return await ctx.reply(tools.msg.info("Riwayat percakapan berhasil direset!"));
        }

        try {
            const { data } = await axios.get("https://api.synoxcloud.xyz/ai-chat/qwen3-next-80b-a3b-instruct", {
                params: { prompt: input },
                timeout: 30000
            });

            if (!data?.status || !data?.result?.reply)
                throw new Error("Respons API tidak valid.");

            await ctx.reply({ richResponse: [{ text: data.result.reply }] });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};