const fs = require("node:fs/promises");
const path = require("node:path");
const { exec } = require("node:child_process");
const { promisify } = require("node:util");

const execAsync = promisify(exec);

module.exports = {
name: "aicoder",
aliases: ["aicode", "gencode"],
category: "ai-generate",

permissions: {
    premium: true
},

code: async (ctx) => {
    try {
        const prompt = ctx.args.join(" ");

        if (!prompt) {
            return await ctx.reply(
                `*CONTOH PENGGUNAAN AICODER*\n\n` +
                `${ctx.used.prefix}${ctx.used.command} buat landing page portfolio modern\n` +
                `${ctx.used.prefix}${ctx.used.command} buat website toko online sederhana\n` +
                `${ctx.used.prefix}${ctx.used.command} buat aplikasi todo list dengan html css js\n` +
                `${ctx.used.prefix}${ctx.used.command} buat komponen button dengan tailwind\n\n` +
                `*💡 TIPS:*\n` +
                `• Gunakan bahasa Indonesia atau Inggris\n` +
                `• Sebutkan framework (React, Vue, Tailwind, dll)\n` +
                `• Jelaskan fitur yang diinginkan\n\n` +
                `*⚠️ NOTE:*\n` +
                `Hasil berupa file ZIP berisi source code lengkap.`
            );
        }

        await ctx.reply(
            tools.msg.info(
                "Generating code, mohon tunggu sekitar 30-60 detik..."
            )
        );

        const MODELS = [
            "zai-org/GLM-5",
            "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8"
        ];

        const BASE_URL =
            "https://llamacoder.together.ai/api";

        const TIMEOUT_MS = 90000;

        const fetchWithTimeout = async (
            url,
            options = {}
        ) => {

            const controller =
                new AbortController();

            const timer = setTimeout(
                () => controller.abort(),
                TIMEOUT_MS
            );

            try {

                return await fetch(url, {
                    ...options,
                    signal: controller.signal
                });

            } finally {

                clearTimeout(timer);

            }
        };

        let chatId = null;
        let lastMessageId = null;
        let usedModel = null;

        for (const model of MODELS) {

            try {

                const response =
                    await fetchWithTimeout(
                        `${BASE_URL}/create-chat`,
                        {
                            method: "POST",
                            headers: {
                                "Content-Type":
                                    "application/json"
                            },
                            body: JSON.stringify({
                                prompt,
                                model,
                                quality: "low"
                            })
                        }
                    );

                if (!response.ok) {
                    continue;
                }

                const data =
                    await response.json();

                if (data?.chatId) {

                    chatId =
                        data.chatId;

                    lastMessageId =
                        data.lastMessageId;

                    usedModel =
                        model;

                    break;
                }

            } catch {}

        }

        if (!chatId) {

            return await ctx.reply(
                tools.msg.info(
                    "Gagal membuat session AI."
                )
            );

        }

        const streamResponse =
            await fetchWithTimeout(
                `${BASE_URL}/get-next-completion-stream-promise`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        messageId:
                            lastMessageId,
                        model:
                            usedModel
                    })
                }
            );

        if (!streamResponse.ok) {

            return await ctx.reply(
                tools.msg.info(
                    `Stream Error (${streamResponse.status})`
                )
            );

        }

        let output = "";
        let buffer = "";

        const reader =
            streamResponse.body.getReader();

        const decoder =
            new TextDecoder();

        while (true) {

            const {
                done,
                value
            } = await reader.read();

            if (done) {
                break;
            }

            buffer += decoder.decode(
                value,
                { stream: true }
            );

            const lines =
                buffer.split("\n");

            buffer =
                lines.pop();

            for (const line of lines) {

                const trimmed =
                    line.trim();

                if (!trimmed) {
                    continue;
                }

                try {

                    const json =
                        JSON.parse(trimmed);

                    const content =
                        json?.choices?.[0]
                            ?.delta?.content;

                    if (content) {
                        output += content;
                    }

                } catch {}

            }
        }

        const files = [];

        const regex =
            /```(?:tsx?|jsx?|css|scss|json|html?|md|env|toml|yaml|yml)\{path=([^}]+)\}\n([\s\S]*?)```/g;

        let match;

        while (
            (match = regex.exec(output))
            !== null
        ) {

            files.push({
                path:
                    match[1]
                        .replace(/^\//, ""),
                content:
                    match[2]
            });

        }

        if (!files.length) {

            return await ctx.reply(
                tools.msg.info(
                    "AI tidak menghasilkan file. Coba prompt yang lebih spesifik."
                )
            );

        }

        const slug =
            prompt
                .replace(/\s+/g, "-")
                .replace(/[^a-z0-9-]/gi, "")
                .toLowerCase()
                .slice(0, 30);

        const tempDir =
            path.join(
                process.cwd(),
                `tmp_aicoder_${Date.now()}`
            );

        const zipName =
            `aicoder-${slug}.zip`;

        const zipPath =
            path.join(
                process.cwd(),
                zipName
            );

        try {

            await fs.mkdir(
                tempDir,
                { recursive: true }
            );

            for (const file of files) {

                const filePath =
                    path.join(
                        tempDir,
                        file.path
                    );

                await fs.mkdir(
                    path.dirname(
                        filePath
                    ),
                    {
                        recursive: true
                    }
                );

                await fs.writeFile(
                    filePath,
                    file.content,
                    "utf8"
                );
            }

            await execAsync(
                `cd "${tempDir}" && zip -r "${zipPath}" .`
            );

            const zipBuffer =
                await fs.readFile(
                    zipPath
                );

            await ctx.reply({
                document:
                    zipBuffer,
                mimetype:
                    "application/zip",
                fileName:
                    zipName,
                caption:
                    `✅ Selesai!\n\n` +
                    `📁 File: ${files.length}\n` +
                    `🤖 Model: ${
                        usedModel
                            ?.split("/")
                            .pop()
                    }\n\n` +
                    files
                        .slice(0, 15)
                        .map(
                            v =>
                                `• ${v.path}`
                        )
                        .join("\n")
            });

        } finally {

            execAsync(
                `rm -rf "${tempDir}" "${zipPath}"`
            ).catch(() => {});

        }

    } catch (error) {

        await tools.cmd.handleError(
            ctx,
            error,
            true
        );

    }
}

};