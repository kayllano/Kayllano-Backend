module.exports = {
    name: "genmyart",
    aliases: ["genart", "aiart"],
    category: "ai-generate",
    permissions: {
        coin: 10
    },

    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "anime girl with neko ears")}\n` +
                tools.msg.generateNotes([
                    "Style tersedia: anime, realistic, cartoon, digital-art, oil-painting, watercolor",
                    `Format: ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} <prompt> --style <style>`)}`
                ])
            );

        // Parse --style flag
        const styleMatch = input.match(/--style\s+(\S+)/i);
        const style      = styleMatch ? styleMatch[1] : "anime";
        const prompt     = input.replace(/--style\s+\S+/i, "").trim();

        await ctx.reply(tools.msg.info("Generating gambar..."));

        try {
            const { data } = await axios.get("https://api.synoxcloud.xyz/ai-generate/genmyart", {
                params: { prompt, style, resolution: "512x512" },
                timeout: 60000
            });

            if (!data?.status || !data?.images?.length)
                throw new Error("Gagal generate gambar.");

            await ctx.reply({
                image: { url: data.images[0] },
                caption:
                    `➛ ${formatter.bold("Prompt")}: ${data.prompt}\n` +
                    `➛ ${formatter.bold("Style")}: ${data.style}\n` +
                    `➛ ${formatter.bold("Resolusi")}: ${data.resolution}`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};