const crypto = require("crypto");

const RE_API = "https://remusic.ai/api/v1/ai-music/music";
const RE_UA  = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0";

const STYLES = {
    genre: ["Pop", "Rock", "Hip-Hop", "R&B", "Jazz", "Classical", "Electronic", "EDM", "Lo-fi", "Ambient", "Reggae", "Country", "Folk", "Metal", "Blues", "Funk", "Soul", "Disco", "House", "Techno", "Trap", "Drum and Bass", "K-Pop", "J-Pop", "Latin", "Afrobeat", "Cinematic", "Orchestral", "Acoustic", "Punk", "Gospel", "Indie", "Synthwave", "Bossa Nova"],
    mood:  ["Calm", "Happy", "Sad", "Energetic", "Romantic", "Epic", "Dark", "Dreamy", "Uplifting", "Melancholic", "Chill", "Aggressive", "Peaceful", "Nostalgic", "Mysterious", "Hopeful", "Sensual", "Playful", "Angry", "Triumphant"],
    vocal: ["Male Vocal", "Female Vocal", "Duet", "Choir", "Soft Vocal", "Powerful Vocal", "Rap", "Whisper"],
    tempo: ["Slow", "Mid-tempo", "Upbeat", "Fast"]
};

// =========================
// HELPERS
// =========================
const reSleep = ms => new Promise(r => setTimeout(r, ms));
const freshGa = () => `GA1.1.${Math.floor(Math.random() * 9e9 + 1e9)}.${Math.floor(Date.now() / 1000)}`;
const randIP  = () => Array.from({ length: 4 }, () => 1 + Math.floor(Math.random() * 254)).join(".");

function reHeaders() {
    return {
        "accept": "application/json, text/plain, */*",
        "content-type": "application/json",
        "origin": "https://remusic.ai",
        "referer": "https://remusic.ai/ai-music-generator",
        "user-agent": RE_UA,
        "cookie": `_ga=${freshGa()}; anonymous_user_id=${crypto.randomUUID()}`,
        "x-forwarded-for": randIP()
    };
}

function rePick(row) {
    return {
        id: row.song_id,
        title: row.title || null,
        status: row.status,
        audio: row.audio_url || null,
        image: row.image_url || row.cover_url || null,
        duration: row.duration || null,
        tags: row.tags || null,
        lyrics: row.lyrics || null
    };
}

async function reCreateJob(body, maxRetries) {
    let last = "create failed";
    for (let i = 0; i < maxRetries; i++) {
        const res  = await fetch(RE_API, { method: "POST", headers: reHeaders(), body: JSON.stringify(body) });
        const json = await res.json().catch(() => null);
        if (json && json.code === 100000 && Array.isArray(json.data) && json.data.length) return json.data;
        last = json ? `${json.code}: ${json.message}` : `http ${res.status}`;
        await reSleep(600);
    }
    throw new Error(last);
}

async function rePollJob(id) {
    for (let i = 0; i < 70; i++) {
        await reSleep(5000);
        const res  = await fetch(`${RE_API}/${id}`, { headers: reHeaders() });
        const json = await res.json().catch(() => null);
        const row  = Array.isArray(json?.data) ? json.data[0] : json?.data;
        if (!row) continue;
        if (row.status === "success" && row.audio_url) return row;
        if (["failed", "error", "fail"].includes(row.status)) throw new Error("generation failed");
    }
    throw new Error("generation timeout");
}

async function reGenerateMusic(prompt, styles = []) {
    const tags = styles.filter(Boolean).join(", ");
    const body = {
        mode: 1,
        supplier: 10,
        mv: "v4",
        is_instrumental: false,
        is_public: true,
        prompt: tags ? `${prompt}, ${tags}` : String(prompt)
    };
    const jobs  = await reCreateJob(body, 6);
    const songs = await Promise.all(
        jobs.map(j => rePollJob(j.song_id).then(rePick).catch(() => ({ id: j.song_id, status: "failed", audio: null })))
    );
    return songs;
}

// =========================
// MODULE
// =========================
module.exports = {
    name: "musicai",
    aliases: ["buatmusik", "genmusic", "aimusic"],
    category: "ai",
    permissions: {
        coin: 20
    },

    code: async (ctx) => {
        const prompt = ctx.text || ctx.quoted?.body;

        // =========================
        // PANDUAN (jika tidak ada prompt)
        // =========================
        if (!prompt)
            return await ctx.reply({
                text: `*Music AI Generator*\n\n` +
                    `› Buat musik original pakai AI hanya dengan deskripsi!\n\n` +
                    `*— Cara Pakai*\n` +
                    `› Format : ${ctx.used.prefix + ctx.used.command} [tema], [style], ...\n` +
                    `› Contoh : ${ctx.used.prefix + ctx.used.command} quiet at night, Jazz, Chill, Calm\n\n` +
                    `*— Genre*\n` +
                    `› ${STYLES.genre.join(", ")}\n\n` +
                    `*— Mood*\n` +
                    `› ${STYLES.mood.join(", ")}\n\n` +
                    `*— Vocal*\n` +
                    `› ${STYLES.vocal.join(", ")}\n\n` +
                    `*— Tempo*\n` +
                    `› ${STYLES.tempo.join(", ")}\n\n` +
                    `› Style bersifat opsional, bisa dikombinasikan bebas\n` +
                    `› Style harus sesuai daftar diatas agar terdeteksi`,
                footer: config.msg.footer
            });

        try {

            // =========================
            // PARSING PROMPT & STYLES
            // =========================
            const parts         = prompt.split(",").map(s => s.trim());
            const mainPrompt    = parts[0];
            const inputTags     = parts.slice(1);

            const allStyles     = [...STYLES.genre, ...STYLES.mood, ...STYLES.vocal, ...STYLES.tempo];
            const matchedStyles = inputTags.filter(t =>
                allStyles.some(s => s.toLowerCase() === t.toLowerCase())
            );

            // =========================
            // NOTIF PROSES
            // =========================
            await ctx.reply(tools.msg.info("Sedang membuat musik, harap tunggu... (sekitar 30-60 detik)"));

            // =========================
            // GENERATE
            // =========================
            const songs   = await reGenerateMusic(mainPrompt, matchedStyles);
            const success = songs.filter(s => s.audio);

            if (!success.length) {
                return await ctx.reply(tools.msg.info("Gagal membuat musik. Coba lagi nanti."));
            }

            // =========================
            // KIRIM HASIL
            // =========================
            for (const song of success) {
                await ctx.reply({
                    audio: { url: song.audio },
                    mimetype: "audio/mpeg",
                    fileName: `${song.title || mainPrompt}.mp3`,
                    caption:
                        `› ${formatter.bold("Title")}  : ${song.title || mainPrompt}\n` +
                        `› ${formatter.bold("Style")}  : ${matchedStyles.join(", ") || "-"}\n` +
                        `› ${formatter.bold("Durasi")} : ${song.duration ? song.duration + "s" : "-"}`
                });
            }

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};