const https = require("https");

module.exports = {
    name: "promptgen",
    aliases: ["genprompt", "promptgenerator"],
    category: "ai-generate",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            const prompt = ctx.args.join(" ");

            if (!prompt) {
                return await ctx.reply(
                    `*Prompt Generator*\n\n` +
                    `Contoh:\n` +
                    `• ${ctx.used.prefix}${ctx.used.command} website portfolio modern\n` +
                    `• ${ctx.used.prefix}${ctx.used.command} landing page toko online premium`
                );
            }

            await ctx.reply(
                tools.msg.info(
                    "Membuat prompt..."
                )
            );

            const payload = JSON.stringify({
                prompt,
                feature: "text-generate",
                language: "en"
            });

            const requestOptions = {
                hostname: "generatepromptai.com",
                port: 443,
                path: "/api/ai/generate-prompt",
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                    "Content-Length": Buffer.byteLength(payload)
                }
            };

            const result = await new Promise((resolve, reject) => {

                let fullResponse = "";

                const req = https.request(requestOptions, (res) => {

                    let buffer = "";

                    res.on("data", (chunk) => {

                        buffer += chunk.toString();

                        const lines = buffer.split("\n");
                        buffer = lines.pop();

                        for (const line of lines) {

                            if (
                                line.startsWith("data: ") &&
                                line.slice(6) !== "[DONE]"
                            ) {
                                try {

                                    const data = JSON.parse(
                                        line.slice(6)
                                    );

                                    if (data.content) {
                                        fullResponse += data.content;
                                    }

                                } catch {}

                            }

                        }

                    });

                    res.on("end", () => {
                        resolve(
                            fullResponse.trim()
                        );
                    });

                });

                req.on("error", reject);

                req.write(payload);
                req.end();

            });

            if (!result) {
                return await ctx.reply(
                    tools.msg.info(
                        "Gagal membuat prompt."
                    )
                );
            }

            const formatted = result
                .replace(/\. /g, ".\n\n")
                .replace(/\:\s/g, ":\n");

            await new AIRich(ctx._client)
                .setTitle("Prompt Generator")
                .addCode(
                    "javascript",
                    `/*\n${formatted}\n*/`
                )
                .send(
                    ctx.id,
                    {
                        forwarded: true
                    }
                );

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};