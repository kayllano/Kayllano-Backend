module.exports = {
    name: "editimage",
    aliases: ["editimg"],
    category: "ai-misc",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "make it evangelion art style!")
            );

        const [checkMedia, checkQuotedMedia] = [
            tools.cmd.checkMedia(ctx.msg.messageType, ["image"]),
            tools.cmd.checkQuotedMedia(ctx.quoted?.messageType, ["image"])
        ];

        if (!checkMedia && !checkQuotedMedia) return await ctx.reply(tools.msg.generateInstruction(["send", "reply"], ["image"]));

        try {
            const uploadUrl = await ctx.msg.upload() || await ctx.quoted.upload();
            const result = tools.api.createUrl("faaa", "/faa/editfoto", {
                url: uploadUrl,
                prompt: input
            });

            await ctx.reply({
                image: {
                    url: result
                },
                caption: `› ${formatter.bold("Prompt")}: ${input}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};