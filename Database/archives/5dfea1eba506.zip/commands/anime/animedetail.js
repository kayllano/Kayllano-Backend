module.exports = {
    name: "animedetail",
    category: "anime",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {
            const url = ctx.args[0];

            if (!url || !url.startsWith("http")) {
                return await ctx.reply(
                    tools.msg.info("URL anime tidak valid.")
                );
            }

            const { data } = await axios.get(
                "https://api.nexray.eu.cc/anime/samehadaku/detail",
                {
                    params: { url },
                    timeout: 30000
                }
            );

            if (!data?.status || !data?.result) {
                return await ctx.reply(
                    tools.msg.info("Gagal mengambil detail anime.")
                );
            }

            const r = data.result;
            const d = r.details;

            const caption =
                `*› ${r.title}*\n` +
                `───────────────\n` +
                `› Rating   : ★ ${r.rating}\n` +
                `› Status   : ${d.status}\n` +
                `› Tipe     : ${d.type}\n` +
                `› Episode  : ${d.total_episode}\n` +
                `› Durasi   : ${d.duration} menit\n` +
                `› Season   : ${d.season}\n` +
                `› Studio   : ${d.studio}\n` +
                `› Genre    : ${r.genres.join(", ")}\n` +
                `───────────────\n` +
                `_${r.synopsis.substring(0, 200)}..._`;

            const epList = r.episodeList || [];

            // Bagi episode ke beberapa section, max 10 per section
            const sections = [];
            const chunkSize = 10;

            for (let i = 0; i < epList.length; i += chunkSize) {
                const chunk = epList.slice(i, i + chunkSize);
                const start = epList[i]?.episode_number;
                const end = epList[Math.min(i + chunkSize - 1, epList.length - 1)]?.episode_number;

                sections.push({
                    title: `Episode ${end} - ${start}`,
                    rows: chunk.map(ep => ({
                        title: ep.title,
                        description: ep.date,
                        id: `${ctx.used.prefix}animestream ${ep.url}`
                    }))
                });
            }

            // WA max 10 sections, potong jika lebih
            const limitedSections = sections.slice(0, 10);

            await ctx.reply({
                image: { url: r.thumbnail },
                caption,
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: `Pilih Episode (${epList.length} eps)`,
                        sections: limitedSections
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
