module.exports = {
    name: "anime",
    category: "anime",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {
            const input = ctx.args.join(" ");

            if (!input) {
                return await ctx.reply(
                    `*› Anime Search*\n` +
                    `───────────────\n` +
                    `Cara pakai:\n` +
                    `› ${ctx.used.prefix}anime <judul>\n\n` +
                    `Contoh:\n` +
                    `› ${ctx.used.prefix}anime overlord`
                );
            }

            const { data } = await axios.get(
                "https://api.nexray.eu.cc/anime/samehadaku/search",
                {
                    params: { q: input },
                    timeout: 30000
                }
            );

            if (!data?.status || !data?.result?.data?.length) {
                return await ctx.reply(
                    tools.msg.info(
                        `Tidak ditemukan hasil untuk "${input}".`
                    )
                );
            }

            const results = data.result.data;

            const rows = results.map(anime => ({
                title: anime.title,
                description: `${anime.type} · ${anime.status} · ★ ${anime.score}`,
                id: `${ctx.used.prefix}animedetail ${anime.url}`
            }));

            await ctx.reply({
                text:
                    `*› Hasil Pencarian: "${input}"*\n` +
                    `───────────────\n` +
                    `Ditemukan ${results.length} anime. Pilih salah satu:`,
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Pilih Anime",
                        sections: [
                            {
                                title: `Hasil: ${input}`,
                                rows
                            }
                        ]
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
