module.exports = {
    name: "animestream",
    category: "anime",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {
            const url = ctx.args[0];

            if (!url || !url.startsWith("http")) {
                return await ctx.reply(
                    tools.msg.info("URL episode tidak valid.")
                );
            }

            const { data } = await axios.get(
                "https://api.nexray.eu.cc/anime/samehadaku/stream",
                {
                    params: { url },
                    timeout: 30000
                }
            );

            if (!data?.status || !data?.result) {
                return await ctx.reply(
                    tools.msg.info("Gagal mengambil link stream/download.")
                );
            }

            const r = data.result;

            // Kumpulkan semua link
            const allLinks = [];
            for (const fmt of r.downloadLinks || []) {
                for (const ql of fmt.list || []) {
                    for (const sv of ql.servers || []) {
                        allLinks.push({
                            quality: ql.quality,
                            provider: sv.provider,
                            url: sv.url
                        });
                    }
                }
            }

            if (!allLinks.length) {
                return await ctx.reply(
                    tools.msg.info("Tidak ada link download tersedia untuk episode ini.")
                );
            }

            // Group per quality
            const grouped = {};
            for (const link of allLinks) {
                if (!grouped[link.quality]) grouped[link.quality] = [];
                grouped[link.quality].push(link);
            }

            // Buat sections per quality, max 10 rows per section
            const sections = Object.entries(grouped).map(([quality, links]) => ({
                title: `Kualitas ${quality}`,
                rows: links.slice(0, 10).map(link => ({
                    title: link.provider,
                    description: link.url,
                    id: `open_url:${link.url}`
                }))
            }));

            // CTA button per quality (max 3)
            const ctaButtons = Object.entries(grouped).slice(0, 3).map(([quality, links]) => ({
                text: `↓ ${quality}`,
                url: links[0].url,
                useWebview: false
            }));

            const text =
                `*› ${r.title}*\n` +
                `───────────────\n` +
                `Pilih kualitas dan provider.\n` +
                `Link akan terbuka di browser.`;

            await ctx.reply({
                text,
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Pilih Quality & Provider",
                        sections
                    },
                    ...ctaButtons
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
