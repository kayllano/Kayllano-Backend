const { PDFDocument } = require("pdf-lib");
const sharp = require("sharp");

module.exports = {
    name: "komiku",
    aliases: ["bacacomik", "komik"],
    category: "anime",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            const input = ctx.text?.trim();

            if (!input) {
                return await ctx.reply({
                    text: `*Komiku Reader*\n\n` +
                        `› Format cari: .komiku [judul]\n` +
                        `› Contoh: .komiku solo leveling\n\n` +
                        `› Format baca: .komiku [url komiku.org]\n` +
                        `› Contoh: .komiku https://komiku.org/manga/solo-leveling`,
                    footer: config.msg.footer
                });
            }

            // =========================
            // MODE 3: BACA CHAPTER → PDF
            // =========================
            if (input.startsWith("chapter|")) {
                const chapterUrl = input.replace("chapter|", "").trim();

                await ctx.reply(tools.msg.info("Mengambil gambar chapter, harap tunggu..."));

                const { data: res } = await axios.get(
                    "https://api.nexray.eu.cc/anime/komiku/chapter",
                    {
                        params: { url: chapterUrl },
                        timeout: 30000
                    }
                );

                if (!res?.status || !res?.result?.images?.length) {
                    return await ctx.reply(tools.msg.info("Gagal mengambil gambar chapter."));
                }

                const { title, images } = res.result;

                await ctx.reply(tools.msg.info(`Mengonversi ${images.length} halaman ke PDF...`));

                // =========================
                // DOWNLOAD & CONVERT KE PDF
                // =========================
                const pdfDoc = await PDFDocument.create();

                for (const img of images) {
                    try {
                        const { data: buffer } = await axios.get(img.url, {
                            responseType: "arraybuffer",
                            timeout: 30000,
                            headers: {
                                Referer: "https://komiku.org/",
                                "User-Agent": "Mozilla/5.0"
                            }
                        });

                        // convert ke PNG dulu via sharp biar pdf-lib bisa baca
                        const pngBuffer = await sharp(Buffer.from(buffer))
                            .toFormat("png")
                            .toBuffer();

                        const pngImage  = await pdfDoc.embedPng(pngBuffer);
                        const page      = pdfDoc.addPage([pngImage.width, pngImage.height]);
                        page.drawImage(pngImage, {
                            x: 0,
                            y: 0,
                            width: pngImage.width,
                            height: pngImage.height
                        });
                    } catch {
                        // skip halaman yang gagal
                    }
                }

                const pdfBytes = await pdfDoc.save();
                const pdfBuffer = Buffer.from(pdfBytes);

                // =========================
                // KIRIM PDF
                // =========================
                await ctx.reply({
                    document: pdfBuffer,
                    mimetype: "application/pdf",
                    fileName: `${title || "chapter"}.pdf`,
                    caption:
                        `› ${formatter.bold("Judul")}: ${title}\n` +
                        `› ${formatter.bold("Total Halaman")}: ${images.length}`
                });

                return;
            }

            // =========================
            // MODE 2: DETAIL KOMIK + LIST CHAPTER FULL
            // =========================
            if (/^https:\/\/komiku\.org\/manga\//i.test(input)) {

                const { data: res } = await axios.get(
                    "https://api.nexray.eu.cc/anime/komiku/detail",
                    {
                        params: { url: input },
                        timeout: 30000
                    }
                );

                if (!res?.status || !res?.result?.chapters?.length) {
                    return await ctx.reply(tools.msg.info("Chapter tidak ditemukan."));
                }

                const detail  = res.result;
                const status  = detail.info?.["status:"] || "-";
                const genres  = (detail.genres || []).join(", ") || "-";
                const total   = detail.chapters.length;

                // kirim per batch 25 chapter kalau > 25
                const batchSize = 25;
                const batches   = [];
                for (let i = 0; i < detail.chapters.length; i += batchSize) {
                    batches.push(detail.chapters.slice(i, i + batchSize));
                }

                // kirim info dulu
                await ctx.reply({
                    image: { url: detail.thumbnail },
                    caption:
                        `› ${formatter.bold("Judul")}: ${detail.title}\n` +
                        `› ${formatter.bold("Status")}: ${status}\n` +
                        `› ${formatter.bold("Genre")}: ${genres}\n` +
                        `› ${formatter.bold("Total Chapter")}: ${total}\n` +
                        `› ${formatter.bold("Halaman")}: ${batches.length} bagian`,
                    footer: config.msg.footer
                });

                // kirim tiap batch sebagai section terpisah
                for (let b = 0; b < batches.length; b++) {
                    const rows = batches[b].map(c => ({
                        title: c.title,
                        description: c.date || "Tap untuk baca",
                        id: `${ctx.used.prefix + ctx.used.command} chapter|${c.link}`
                    }));

                    await ctx.reply({
                        text: `› ${formatter.bold("Chapter")} (Bagian ${b + 1}/${batches.length})`,
                        footer: config.msg.footer,
                        nativeFlow: [
                            {
                                text: `Bagian ${b + 1}`,
                                sections: [
                                    {
                                        title: `Chapter ${b * batchSize + 1} - ${Math.min((b + 1) * batchSize, total)}`,
                                        rows
                                    }
                                ]
                            }
                        ]
                    });
                }

                return;
            }

            // =========================
            // MODE 1: CARI KOMIK
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/anime/komiku/search",
                {
                    params: { q: input },
                    timeout: 30000
                }
            );

            if (!res?.status || !res?.result?.length) {
                return await ctx.reply(tools.msg.info(`Komik "${input}" tidak ditemukan.`));
            }

            const hasil = res.result;

            const rows = hasil.slice(0, 20).map(v => ({
                title: v.title,
                description: `${v.type || "-"} | ${v.description || ""}`.trim(),
                id: `${ctx.used.prefix + ctx.used.command} ${v.link}`
            }));

            await ctx.reply({
                image: { url: hasil[0].thumbnail },
                caption:
                    `› ${formatter.bold("Hasil Pencarian")}: ${input}\n` +
                    `› ${formatter.bold("Total")}: ${hasil.length} komik`,
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Pilih Komik",
                        sections: [
                            {
                                title: "Daftar Komik",
                                rows
                            }
                        ]
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};