module.exports = {
    name: "sprem",
    aliases: ["stikerpremium", "premstiker"],
    category: "converter",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI QUOTED
            // =========================
            const quoted = ctx.quoted?.message?.stickerMessage;
            if (!quoted) {
                return await ctx.reply(
                    formatter.monospace("Reply ke stiker yang ingin dijadikan premium!")
                );
            }

            // =========================
            // RELAY STIKER PREMIUM
            // =========================
            await ctx.core.relayMessage(
                ctx._msg.key.remoteJid,
                {
                    messageContextInfo: {
                        messageSecret: "rme8dNt3wUoOXIqw5rIpoHsnCSGJtcy/kMJVsBfyukA="
                    },
                    lottieStickerMessage: {
                        message: {
                            stickerMessage: {
                                url: quoted.url,
                                fileSha256: quoted.fileSha256,
                                fileEncSha256: quoted.fileEncSha256,
                                mediaKey: quoted.mediaKey,
                                mimetype: quoted.mimetype || "image/webp",
                                height: quoted.height,
                                width: quoted.width,
                                directPath: quoted.directPath,
                                fileLength: quoted.fileLength,
                                mediaKeyTimestamp: quoted.mediaKeyTimestamp,
                                isAnimated: quoted.isAnimated || false,
                                stickerSentTs: quoted.stickerSentTs || Date.now(),
                                isAvatar: quoted.isAvatar || false,
                                isAiSticker: quoted.isAiSticker || false,
                                isLottie: quoted.isLottie || false,
                                premium: 1
                            }
                        }
                    }
                },
                {}
            );

            await ctx._msg.react("⭐");

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};