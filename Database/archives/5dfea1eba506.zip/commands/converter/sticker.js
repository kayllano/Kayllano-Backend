const { Sticker, StickerTypes } = require("wa-sticker-formatter");
const sharp = require("sharp");

module.exports = {
    name: "sticker",
    aliases: ["s", "stiker"],
    category: "converter",
    code: async (ctx) => {
        const [checkMedia, checkQuotedMedia] = [
            tools.cmd.checkMedia(ctx.msg.messageType, ["image", "video"]),
            tools.cmd.checkQuotedMedia(ctx.quoted?.messageType, ["image", "video"])
        ];

        if (!checkMedia && !checkQuotedMedia)
            return await ctx.reply(tools.msg.generateInstruction(["send", "reply"], ["image", "video"]));

        try {
            const buffer = await ctx.msg.download() || await ctx.quoted.download();
            const [packname, author] = ctx.text?.split("|") || [];
            const userStickerwm = ctx.db.user?.stickerwm;

            const msgType = ctx.msg.messageType?.toLowerCase() || "";
            const quotedType = ctx.quoted?.messageType?.toLowerCase() || "";
            const isVideo = msgType.includes("video") || quotedType.includes("video");

            if (isVideo) {
                // Video: Diberi batas quality dan fps agar ukuran file tidak bengkak (< 1MB)
                const sticker = new Sticker(buffer, {
                    pack: packname || userStickerwm?.packname || config.sticker.packname,
                    author: author || userStickerwm?.author || config.sticker.author,
                    type: StickerTypes.CROPPED,
                    categories: ["🌕"],
                    id: ctx.msg.key.id,
                    quality: 5, // Mengompres bobot video beresolusi rendah/antep
                    fps: 10      // Memangkas frame rate agar stiker lancar diputar di WA
                });
                return await ctx.reply({ sticker: await sticker.build() });
            }

            // Gambar: resize dulu pakai sharp baru jadiin stiker
            const resizedBuffer = await sharp(buffer)
                .resize(515, 515, { fit: "fill" })
                .toBuffer();

            const sticker = new Sticker(resizedBuffer, {
                pack: packname || userStickerwm?.packname || config.sticker.packname,
                author: author || userStickerwm?.author || config.sticker.author,
                type: StickerTypes.FULL,
                categories: ["🌕"],
                id: ctx.msg.key.id,
                quality: 50
            });

            await ctx.reply({ sticker: await sticker.build() });
        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
