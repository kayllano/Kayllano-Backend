const axios = require("axios");
const FormData = require("form-data");

module.exports = {
    name: "toanime",
    aliases: [""],
    category: "converter",
    permissions: {
        coin: 10
    },

    code: async (ctx) => {
        try {

            let buffer = null;

            if (ctx.quoted?.download) {
                buffer = await ctx.quoted.download();
            } else if (ctx.msg?.download) {
                buffer = await ctx.msg.download();
            }

            if (!buffer) {
                return await ctx.reply(
                    `${tools.msg.generateInstruction(
                        ["send", "reply"],
                        ["image"]
                    )}\n` +
                    tools.msg.generateCmdExample(
                        ctx.used,
                        ""
                    )
                );
            }

            await ctx.reply(
                tools.msg.info("Mengubah gambar ke gaya Anime...")
            );

            const form = new FormData();

            form.append(
                "apikey",
                "kyugay"
            );

            form.append(
                "image",
                buffer,
                "image.jpg"
            );

            const { data } = await axios.post(
                "https://api.theresav.biz.id/image/toanime",
                form,
                {
                    headers: form.getHeaders(),
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            await ctx.reply({
                image: Buffer.from(data),
                caption:
                    `➛ ${formatter.bold("Done")}`
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};