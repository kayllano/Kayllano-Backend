module.exports = {
    name: "toimage",
    aliases: ["toimg", "topng"],
    category: "converter",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        if (!tools.cmd.checkQuotedMedia(ctx.quoted?.messageType, ["sticker"])) return await ctx.reply(tools.msg.generateInstruction(["reply"], ["sticker"]));

        try {
            const buffer = await ctx.quoted.download();
            const result = (await axios.post("https://nekochii-converter.hf.space/webp2png", {
                file: buffer.toString("base64"),
                json: true
            })).data.result;

            await ctx.reply({
                image: {
                    url: result
                }
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};