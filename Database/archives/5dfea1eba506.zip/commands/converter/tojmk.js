module.exports = {
name: "tojmk",
aliases: ["jmk"],
category: "converter",

permissions: {
    coin: 10
},

code: async (ctx) => {

    const [checkMedia, checkQuotedMedia] = [
        tools.cmd.checkMedia(
            ctx.msg.messageType,
            ["image", "sticker"]
        ),
        tools.cmd.checkQuotedMedia(
            ctx.quoted?.messageType,
            ["image", "sticker"]
        )
    ];

    if (!checkMedia && !checkQuotedMedia) {
        return await ctx.reply(
            tools.msg.generateInstruction(
                ["send", "reply"],
                ["image", "sticker"]
            )
        );
    }

    try {

        const uploadUrl =
            await ctx.msg.upload() ||
            await ctx.quoted.upload();

        const result =
            `https://api.nexray.eu.cc/canvas/jmk?url=${encodeURIComponent(uploadUrl)}`;

        await ctx.reply({
            image: {
                url: result
            }
        });

    } catch (error) {

        await tools.cmd.handleError(
            ctx,
            error,
            true
        );

    }
}

};