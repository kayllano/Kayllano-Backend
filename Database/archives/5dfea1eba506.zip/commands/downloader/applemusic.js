module.exports = {
    name: "applemusic",
    aliases: ["amdl", "applemusicdl"],
    category: "downloader",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const url = ctx.args[0] || tools.cmd.extractUrlFromText(ctx.quoted?.body);

        if (!url)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "https://music.apple.com/us/song/cicada/1877933451")
            );

        const isUrl = tools.cmd.isUrl(url);
        if (!isUrl) return await ctx.reply(tools.msg.info(config.msg.urlInvalid));

        try {

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.theresav.biz.id/download/applemusic",
                {
                    params: {
                        url,
                        apikey: "artoriaox"
                    },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.success || !res.result?.download?.url) {
                return await ctx.reply(tools.msg.info("Gagal mengambil lagu. Pastikan URL valid dan coba lagi."));
            }

            const { metadata, download } = res.result;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                audio: { url: download.url },
                mimetype: "audio/mpeg",
                fileName: `${metadata.title} - ${metadata.artist}.${download.format}`,
                caption:
                    `› Title: ${metadata.title}\n` +
                    `› Artist: ${metadata.artist}\n` +
                    `› Album: ${metadata.album}\n` +
                    `› Durasi: ${metadata.duration}\n` +
                    `› Kualitas: ${metadata.quality}`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};