module.exports = {
    name: "gitclone",
    aliases: ["githubdl", "gitdl"],
    category: "downloader",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const url = ctx.args[0]?.replace(/\.git$/, "");
            if (!url) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan URL repository GitHub!\nContoh: .gitclone https://github.com/user/repo"),
                    footer: config.msg.footer
                });
            }

            if (!url.includes("github.com")) {
                return await ctx.reply({
                    text: formatter.monospace("URL tidak valid! Harus berupa link GitHub.\nContoh: https://github.com/user/repo"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.theresav.biz.id/download/github",
                {
                    params: {
                        url,
                        apikey: "artoriaox"
                    },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.download) {
                return await ctx.reply({
                    text: formatter.monospace("Gagal mengambil data repository. Coba lagi nanti."),
                    footer: config.msg.footer
                });
            }

            // =========================
            // DOWNLOAD FILE ZIP
            // =========================
            const { owner, repo, language, stars, forks, size_mb, download } = res.result;

            const { data: fileData } = await axios.get(download, {
                responseType: "arraybuffer",
                timeout: 60000
            });

            const caption = `*Github Downloader*\n\n`
                + `› Owner: ${owner}\n`
                + `› Repo: ${repo}\n`
                + `› Language: ${language || "-"}\n`
                + `› Stars: ${stars ?? 0}\n`
                + `› Forks: ${forks ?? 0}\n`
                + `› Size: ${size_mb} MB`;

            // =========================
            // KIRIM FILE
            // =========================
            await ctx.reply({
                document: Buffer.from(fileData),
                mimetype: "application/zip",
                fileName: `${repo}.zip`,
                caption: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};