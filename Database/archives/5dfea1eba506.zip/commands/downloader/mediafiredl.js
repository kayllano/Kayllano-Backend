module.exports = {
    name: "mediafiredl",
    aliases: ["mediafire", "mf", "mfdl"],
    category: "downloader",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const url = ctx.args[0] || tools.cmd.extractUrlFromText(ctx.quoted?.body);

        if (!url)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "https://www.mediafire.com/file/on2jvy5540bi22u/humanity-turned-into-lcl-scene.mp4/file")
            );

        const isUrl = tools.cmd.isUrl(url);
        if (!isUrl) return await ctx.reply(tools.msg.info(config.msg.urlInvalid));

        try {

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.theresav.biz.id/download/mediafire",
                {
                    params: {
                        url,
                        apikey: "kyujir"
                    },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.directDownloadUrl) {
                return await ctx.reply(tools.msg.info("Gagal mengambil file. Pastikan URL valid dan coba lagi."));
            }

            const { fileName, fileSize, fileExtension, directDownloadUrl } = res.result;

            // =========================
            // KIRIM FILE
            // =========================
            await ctx.reply({
                document: {
                    url: directDownloadUrl
                },
                fileName: fileName,
                mimetype: `application/${fileExtension}`,
                caption:
                    `› ${formatter.bold("File")} : ${fileName}\n` +
                    `› ${formatter.bold("Size")} : ${fileSize}`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};