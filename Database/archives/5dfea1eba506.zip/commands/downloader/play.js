module.exports = {
    name: "play",
    category: "downloader",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {

        const flag = ctx.flag({
            index: {
                type: "string",
                short: "i",
                default: "0"
            },
            source: {
                type: "string",
                short: "s",
                default: "youtube"
            }
        });

        const input = flag.input;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "one last kiss - hikaru utada -i 8 -s spotify")}\n` +
                tools.msg.generatesFlagInfo({
                    "-i <number>": "Pilihan pada data indeks",
                    "-s <text>": "Sumber untuk memutar lagu (tersedia: spotify, youtube | default: youtube)"
                })
            );

        try {
            const searchIndex = parseInt(flag.index, 10);
            const source = flag.source;

            // =========================
            // SPOTIFY
            // =========================
            if (source === "spotify") {

                const searchResult = (await axios.get(
                    tools.api.createUrl("delirius", "/search/spotify", { q: input })
                )).data.data[searchIndex];

                await new ButtonV2(ctx.core)
                    .setTitle(searchResult.title)
                    .setSubtitle(searchResult.artist)
                    .setBody(
                        `Judul: ${searchResult.title}\n` +
                        `Artis: ${searchResult.artist}\n` +
                        `URL: ${searchResult.url}`
                    )
                    .setFooter(config.msg.footer)
                    .setThumbnail(searchResult.thumbnail || config.bot.thumbnail)
                    .addButton("Download Audio", `${ctx.used.prefix}play ${input} -i ${searchIndex} -s spotify`)
                    .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

                const downloadResult = (await axios.get(
                    tools.api.createUrl("delirius", "/download/spotifydl", { url: searchResult.url })
                )).data.data.download;

                await ctx.reply({
                    audio: { url: downloadResult },
                    mimetype: "audio/mpeg"
                });

            // =========================
            // YOUTUBE
            // =========================
            } else {

                const searchResult = (await axios.get(
                    tools.api.createUrl("delirius", "/search/ytsearch", { q: input })
                )).data.data[searchIndex];

                await new ButtonV2(ctx.core)
                    .setTitle(searchResult.title)
                    .setSubtitle(searchResult.author?.name || "YouTube")
                    .setBody(
                        `Judul: ${searchResult.title}\n` +
                        `Artis: ${searchResult.author?.name}\n` +
                        `URL: ${searchResult.url}\n\n` +
                        `*Audio sedang dikirim...*\n\nPencet Button di bawah untuk mendownload format video!`
                    )
                    .setThumbnail(searchResult.thumbnail || config.bot.thumbnail)
                    .addButton("Download Video", `${ctx.used.prefix}ytmp4 ${searchResult.url}`)
                    .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

                const downloadResult = (await axios.get(
                    tools.api.createUrl("delirius", "/download/ytmp3", { url: searchResult.url })
                )).data.data.download;

                await ctx.reply({
                    audio: { url: downloadResult },
                    mimetype: "audio/mpeg"
                });
            }

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};
