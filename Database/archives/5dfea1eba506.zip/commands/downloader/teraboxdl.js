module.exports = {
    name: "terabox",
    aliases: ["tbdl", "tbox"],
    category: "downloader",
    permissions: {
        coin: 10
    },

    code: async (ctx) => {
        try {
            const url = ctx.args[0];

            if (!url) {
                return await ctx.reply(
                    `*✦ Terabox Downloader*\n\n` +
                    `Cara pakai:\n` +
                    `— \`${ctx.used.prefix}terabox <url>\`\n\n` +
                    `Contoh:\n` +
                    `— \`${ctx.used.prefix}terabox https://1024terabox.com/s/xxxxx\``
                );
            }

            if (
                !url.includes("terabox.com") &&
                !url.includes("1024terabox.com") &&
                !url.includes("teraboxapp.com")
            ) {
                return await ctx.reply(
                    tools.msg.info(
                        "URL tidak valid. Masukkan link Terabox yang benar."
                    )
                );
            }

            await ctx.reply(
                tools.msg.info(
                    "Mengambil info file Terabox..."
                )
            );

            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/donwloader/terabox.php",
                {
                    params: { url },
                    timeout: 60000
                }
            );

            if (
                !data?.status ||
                !data?.result?.files?.length
            ) {
                return await ctx.reply(
                    tools.msg.info(
                        "Gagal mengambil data file. Pastikan link Terabox valid dan dapat diakses."
                    )
                );
            }

            const result = data.result;
            const files = result.files;

            // Kirim info & download satu per satu jika ada banyak file
            for (const file of files) {
                // Limit ukuran file 300 MB
                const sizeMB = file.size / (1024 * 1024);

                if (sizeMB > 300) {
                    await ctx.reply(
                        tools.msg.info(
                            `File *${file.name}* dilewati karena ukurannya melebihi batas 300 MB (${file.sizeFormatted}).`
                        )
                    );
                    continue;
                }

                const caption =
                    `*Terabox Downloader*\n\n` +
                    `*› Nama:* ${file.name}\n` +
                    `*› Ukuran:* ${file.sizeFormatted}\n` +
                    `*› Tipe:* ${file.type.toUpperCase()}`;

                // Kirim sebagai dokumen
                await ctx.reply({
                    document: { url: file.downloadUrl },
                    mimetype: getMimeType(file.type),
                    fileName: file.name,
                    caption
                });
            }

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error
            );
        }
    }
};

function getMimeType(type) {
    const mimeMap = {
        pdf: "application/pdf",
        mp4: "video/mp4",
        mp3: "audio/mpeg",
        jpg: "image/jpeg",
        jpeg: "image/jpeg",
        png: "image/png",
        zip: "application/zip",
        rar: "application/x-rar-compressed",
        docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        txt: "text/plain"
    };
    return mimeMap[type?.toLowerCase()] || "application/octet-stream";
}
