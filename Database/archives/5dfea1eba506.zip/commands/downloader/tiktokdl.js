module.exports = {
    name: "tiktokdl",
    aliases: ["tiktok", "tt", "ttdl", "vt", "vtdl"],
    category: "downloader",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const url = ctx.args[0] || tools.cmd.extractUrlFromText(ctx.quoted?.body);

        if (!url)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(
                    ctx.used,
                    "https://www.tiktok.com/@netflixanime/video/7596931111805078805"
                )
            );

        const isUrl = tools.cmd.isUrl(url);
        if (!isUrl)
            return await ctx.reply(tools.msg.info(config.msg.urlInvalid));

        try {
            // =========================
            // FETCH API UTAMA
            // =========================
            const { data: res } = await axios.get(
                "https://api.synoxcloud.xyz/download/tiktok",
                { params: { url }, timeout: 30000 }
            ).catch(() => ({ data: null }));

            // =========================
            // FETCH API BACKUP (nexray)
            // =========================
            const { data: backup } = await axios.get(
                "https://api.nexray.eu.cc/downloader/tiktok",
                { params: { url }, timeout: 30000 }
            ).catch(() => ({ data: null }));

            const backupResult = backup?.status ? backup.result : null;

            // =========================
            // MERGE DATA
            // =========================
            const title     = res?.data?.title     || backupResult?.title     || "-";
            const author    = res?.data?.author     || backupResult?.author?.fullname || "-";
            const thumbnail = res?.data?.thumbnail  || backupResult?.cover     || null;
            const musicUrl  = backupResult?.music_info?.url || null;
            const musicTitle = backupResult?.music_info?.title || "-";

            const caption =
                `➛ ${formatter.bold("Title")}  : ${title}\n` +
                `➛ ${formatter.bold("Author")} : ${author}`;

            // =========================
            // CEK SLIDE FOTO
            // =========================
            const validImages = (() => {
                // Cek dari api utama
                const fromMain = Array.isArray(res?.data?.images)
                    ? res.data.images.filter(img => typeof img === "string" && img.startsWith("http"))
                    : [];
                if (fromMain.length > 0) return fromMain;

                // Cek dari backup (field data)
                const fromBackup = Array.isArray(backupResult?.data)
                    ? backupResult.data.filter(img => typeof img === "string" && img.startsWith("http"))
                    : [];
                return fromBackup;
            })();

            if (validImages.length > 0) {
                // =========================
                // KIRIM ALBUM FOTO
                // =========================
                const album = validImages.map(img => ({ image: { url: img } }));
                album[0].caption = caption;
                await ctx.reply({ album });

                // Kirim audio jika ada
                if (musicUrl) {
                    await ctx.reply({
                        audio: { url: musicUrl },
                        mimetype: "audio/mpeg",
                        fileName: `${musicTitle}.mp3`,
                        ptt: false
                    });
                }
                return;
            }

            // =========================
            // CEK VIDEO
            // =========================
            const validLinks = (() => {
                const fromMain = Array.isArray(res?.data?.links)
                    ? res.data.links.filter(link =>
                        typeof link === "string" &&
                        link.startsWith("http") &&
                        !link.includes("play.google.com") &&
                        !link.includes("apps.apple.com")
                    )
                    : [];
                return fromMain;
            })();

            const videoUrl = validLinks[0] || null;

            if (videoUrl) {
                await ctx.reply({ video: { url: videoUrl }, caption });

                // Kirim audio jika ada
                if (musicUrl) {
                    await ctx.reply({
                        audio: { url: musicUrl },
                        mimetype: "audio/mpeg",
                        fileName: `${musicTitle}.mp3`,
                        ptt: false
                    });
                }
                return;
            }

            return await ctx.reply(tools.msg.info("Tidak ditemukan media yang valid dari URL tersebut."));

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};