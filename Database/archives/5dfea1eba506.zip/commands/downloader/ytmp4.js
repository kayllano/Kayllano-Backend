module.exports = {
    name: "ytmp4",
    aliases: ["ytv", "ytvideo"],
    category: "downloader",
    permissions: {
        coin: 10
    },

    code: async (ctx) => {
        try {
            const url = ctx.args[0];

            if (!url) {
                return await ctx.reply(
                    `*✦ YouTube Video Downloader*\n\n` +
                    `Cara pakai:\n` +
                    `— \`${ctx.used.prefix}ytmp4 https://youtu.be/xxxxx\``
                );
            }

            if (!url.includes("youtube.com") && !url.includes("youtu.be")) {
                return await ctx.reply(tools.msg.info("URL tidak valid. Masukkan link YouTube yang benar."));
            }

            await ctx.reply(tools.msg.info("Mengambil info video..."));

            const { data } = await axios.get(
                "https://fgsi.dpdns.org/api/downloader/youtube/v1",
                {
                    params: { url, apikey: "fgsiapi-2d6917a7-6d" },
                    timeout: 60000
                }
            );

            if (!data?.status || !data?.data?.url) {
                return await ctx.reply(tools.msg.info("Gagal mengambil data video."));
            }

            await ctx.reply({
                video: { url: data.data.url },
                mimetype: "video/mp4",
                caption:
                    `➛ ${formatter.bold(data.title || "YouTube Video")}\n` +
                    `➛ ${formatter.bold("Channel")}: ${data.channel || "-"}`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};