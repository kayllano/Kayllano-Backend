const session = new Map();

module.exports = {
    name: "family100",
    category: "game",
    permissions: {
        group: true
    },
    code: async (ctx) => {
        if (session.has(ctx.id)) return await ctx.reply(tools.msg.info("Sesi permainan sedang berjalan!"));

        try {
            const apiUrl = tools.api.createUrl("siputzx", "/api/games/family100");
            const result = (await axios.get(apiUrl)).data.data;

            const game = {
                coin: {
                    answered: 5,
                    allAnswered: 10
                },
                timeout: 90000,
                answers: new Set(result.jawaban.map(ans => ans.toLowerCase())),
                participants: new Set()
            };

            session.set(ctx.id, true);

            await ctx.reply({
                text: `✿ — ${result.soal}\n` +
                    "\n" +
                    `› ${formatter.bold("Bonus")}: ${game.coin.answered} Koin untuk 1 jawaban benar, ${game.coin.allAnswered} Koin untuk semua jawaban benar\n` +
                    `› ${formatter.bold("Jumlah jawaban")}: ${game.answers.size}\n` +
                    `› ${formatter.bold("Batas waktu")}: ${tools.msg.convertMsToDuration(game.timeout)}`,
                buttons: [{
                    text: "Menyerah",
                    id: `surrender_${ctx.used.command}`
                }]
            });

            const collector = ctx.MessageCollector({
                time: game.timeout
            });

            const playAgain = [{
                text: "Main Lagi",
                id: ctx.used.prefix + ctx.used.command
            }];

            collector.on("collect", async (collCtx) => {
                const participantAnswer = collCtx.msg.body?.toLowerCase();
                const participantDb = collCtx.db.user;

                if (game.answers.has(participantAnswer)) {
                    game.answers.delete(participantAnswer);
                    game.participants.add(collCtx.sender.lid);

                    participantDb.coin += game.coin.answered;
                    participantDb.save();
                    await collCtx.reply(tools.msg.info(`${tools.msg.ucwords(participantAnswer)} benar! Jawaban tersisa: ${game.answers.size}`));

                    if (game.answers.size === 0) {
                        session.delete(ctx.id);
                        collector.stop();
                        for (const participant of game.participants) {
                            const allParticipantDb = ctx.getDb("users", participant);
                            allParticipantDb.coin += game.coin.allAnswered;
                            allParticipantDb.winGame += 1;
                            allParticipantDb.save();
                        }
                        await collCtx.reply({
                            text: tools.msg.info(`Selamat! Semua jawaban telah terjawab! Setiap anggota yang menjawab mendapat ${game.coin.allAnswered} koin.`),
                            buttons: playAgain
                        });
                    }
                } else if (participantAnswer === `surrender_${ctx.used.command}`) {
                    const remaining = [...game.answers].map(tools.msg.ucwords).join(", ").replace(/, ([^,]*)$/, ", dan $1");
                    session.delete(ctx.id);
                    collector.stop();
                    await collCtx.reply({
                        text: tools.msg.info(`Anda menyerah! Jawaban yang belum terjawab adalah ${remaining}.`),
                        buttons: playAgain
                    });
                } else if (tools.cmd.didYouMean(participantAnswer, [game.answer]) === game.answer) {
                    await collCtx.reply(tools.msg.info("Sedikit lagi!"));
                }
            });

            collector.on("end", async () => {
                const remaining = [...game.answers].map(tools.msg.ucwords).join(", ").replace(/, ([^,]*)$/, ", dan $1");

                if (session.has(ctx.id)) {
                    session.delete(ctx.id);
                    await ctx.reply({
                        text: tools.msg.info(`Waktu habis! Jawaban yang belum terjawab adalah ${remaining}.`),
                        buttons: playAgain
                    });
                }
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};