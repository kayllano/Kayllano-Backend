const axios = require("axios");

const session = new Map();

module.exports = {
name: "tebaklagu",
aliases: ["lagu"],
category: "game",

code: async (ctx) => {
    if (session.has(ctx.id)) {
        return await ctx.reply(
            tools.msg.info(
                "Sesi permainan sedang berjalan!"
            )
        );
    }

    try {

        const { data: res } = await axios.get(
            "https://api.betabotz.eu.org/api/game/tebaklagu",
            {
                params: {
                    apikey: "kepinVIP"
                },
                timeout: 30000
            }
        );

        if (!res?.judul || !res?.lagu) {
            throw new Error("Data lagu tidak valid.");
        }

        const game = {
            coin: 15,
            timeout: 60000,
            answer: res.judul.toLowerCase().trim(),
            artist: res.artis,
            audio: res.lagu
        };

        session.set(ctx.id, true);

        const { data } = await axios.get(
            game.audio,
            {
                responseType: "arraybuffer"
            }
        );

        const audioBuffer = Buffer.from(data);

        // Kirim VN
        await ctx.reply({
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            ptt: true
        });

        // Kirim soal
        await ctx.reply({
            text:
                `🎵 Tebak Lagu!\n\n` +
                `Artis : ${game.artist}\n` +
                `Bonus : ${game.coin} Coin\n` +
                `Waktu : ${tools.msg.convertMsToDuration(game.timeout)}`,
            buttons: [
                {
                    text: "Petunjuk (3 Coin)",
                    id: `hint_${ctx.used.command}`
                },
                {
                    text: "Menyerah",
                    id: `surrender_${ctx.used.command}`
                }
            ]
        });

        const collector = ctx.MessageCollector({
            time: game.timeout
        });

        const playAgain = [
            {
                text: "Main Lagi",
                id: ctx.used.prefix + ctx.used.command
            }
        ];

        collector.on("collect", async (collCtx) => {

            const participantAnswer =
                collCtx.msg.body?.toLowerCase()?.trim();

            const participantDb =
                collCtx.db.user;

            if (
                participantAnswer === game.answer
            ) {

                session.delete(ctx.id);
                collector.stop();

                participantDb.coin += game.coin;
                participantDb.winGame += 1;
                participantDb.save();

                await collCtx.reply({
                    text:
                        `Benar!\n\n` +
                        `Judul : ${tools.msg.ucwords(game.answer)}\n` +
                        `Artis : ${game.artist}\n` +
                        `Hadiah : +${game.coin} Coin`,
                    buttons: playAgain
                });

            } else if (
                participantAnswer ===
                `hint_${ctx.used.command}`
            ) {

                if (participantDb.coin < 3) {
                    return await collCtx.reply(
                        tools.msg.info(
                            config.msg.coin
                        )
                    );
                }

                participantDb.coin -= 3;
                participantDb.save();

                const clue = game.answer
                    .split("")
                    .map((char, i) => {
                        if (char === " ") return " ";
                        return i % 2 === 0
                            ? char
                            : "_";
                    })
                    .join("");

                await collCtx.reply(
                    formatter.monospace(
                        clue.toUpperCase()
                    )
                );

            } else if (
                participantAnswer ===
                `surrender_${ctx.used.command}`
            ) {

                session.delete(ctx.id);
                collector.stop();

                await collCtx.reply({
                    text:
                        `Anda menyerah!\n\n` +
                        `Judul : ${tools.msg.ucwords(game.answer)}\n` +
                        `Artis : ${game.artist}`,
                    buttons: playAgain
                });

            } else if (
                tools.cmd.didYouMean(
                    participantAnswer,
                    [game.answer]
                ) === game.answer
            ) {

                await collCtx.reply(
                    tools.msg.info(
                        "Sedikit lagi!"
                    )
                );

            }

        });

        collector.on("end", async () => {

            if (session.has(ctx.id)) {

                session.delete(ctx.id);

                await ctx.reply({
                    text:
                        `Waktu habis!\n\n` +
                        `Judul : ${tools.msg.ucwords(game.answer)}\n` +
                        `Artis : ${game.artist}`,
                    buttons: playAgain
                });

            }

        });

    } catch (error) {
        session.delete(ctx.id);

        await tools.cmd.handleError(
            ctx,
            error,
            true
        );
    }
}

};