const session = new Map();

module.exports = {
    name: "tebakml",
    aliases: ["tebakmobillegend", "tebakhero"],
    category: "game",
    permissions: {
        coin: 5
    },
    code: async (ctx) => {
        if (session.has(ctx.id)) return await ctx.reply(tools.msg.info("Sesi permainan sedang berjalan!"));

        try {

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.betabotz.eu.org/api/game/tebakheroml",
                {
                    params: { apikey: "kepinVIP" },
                    timeout: 30000
                }
            );

            const game = {
                coin: 5,
                timeout: 60000,
                answer: res.jawaban.toLowerCase(),
                deskripsi: res.deskripsi
            };

            session.set(ctx.id, true);

            // =========================
            // KIRIM SOAL
            // =========================
            await ctx.reply({
                image: { url: res.img },
                caption:
                    `› ${formatter.bold("Tebak Hero ML!")}\n` +
                    `› ${formatter.bold("Petunjuk")}: ${game.deskripsi}\n` +
                    `› ${formatter.bold("Bonus")}: ${game.coin} Koin\n` +
                    `› ${formatter.bold("Batas waktu")}: ${tools.msg.convertMsToDuration(game.timeout)}`,
                buttons: [
                    {
                        text: "Petunjuk (3 Koin)",
                        id: `hint_${ctx.used.command}`
                    },
                    {
                        text: "Menyerah",
                        id: `surrender_${ctx.used.command}`
                    }
                ]
            });

            // =========================
            // COLLECTOR JAWABAN
            // =========================
            const collector = ctx.MessageCollector({
                time: game.timeout
            });

            const playAgain = [{
                text: "Main Lagi",
                id: ctx.used.prefix + ctx.used.command
            }];

            collector.on("collect", async (collCtx) => {
                const participantAnswer = collCtx.msg.body?.toLowerCase();
                const participantDb     = collCtx.db.user;

                if (participantAnswer === game.answer) {
                    session.delete(ctx.id);
                    collector.stop();
                    participantDb.coin    += game.coin;
                    participantDb.winGame += 1;
                    participantDb.save();
                    await collCtx.reply({
                        image: { url: res.fullimg },
                        caption: tools.msg.info(`Benar! Jawabannya adalah *${tools.msg.ucwords(game.answer)}*. +${game.coin} Koin`),
                        buttons: playAgain
                    });
                } else if (participantAnswer === `hint_${ctx.used.command}`) {
                    if (participantDb.coin < 3) return await collCtx.reply(tools.msg.info(config.msg.coin));
                    participantDb.coin -= 3;
                    participantDb.save();
                    const clue = game.answer.replace(/[aiueo]/g, "_");
                    await collCtx.reply(formatter.monospace(clue.toUpperCase()));
                } else if (participantAnswer === `surrender_${ctx.used.command}`) {
                    session.delete(ctx.id);
                    collector.stop();
                    await collCtx.reply({
                        text: tools.msg.info(`Anda menyerah! Jawabannya adalah *${tools.msg.ucwords(game.answer)}*.\n› Deskripsi: ${game.deskripsi}`),
                        buttons: playAgain
                    });
                } else if (tools.cmd.didYouMean(participantAnswer, [game.answer]) === game.answer) {
                    await collCtx.reply(tools.msg.info("Sedikit lagi!"));
                }
            });

            // =========================
            // TIMEOUT
            // =========================
            collector.on("end", async () => {
                if (session.has(ctx.id)) {
                    session.delete(ctx.id);
                    await ctx.reply({
                        text: tools.msg.info(`Waktu habis! Jawabannya adalah *${tools.msg.ucwords(game.answer)}*.\n› Deskripsi: ${game.deskripsi}`),
                        buttons: playAgain
                    });
                }
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};