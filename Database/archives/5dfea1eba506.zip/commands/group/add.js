module.exports = {
    name: "add",
    category: "group",
    permissions: {
        admin: true,
        botAdmin: true,
        group: true,
        restrict: true
    },
    code: async (ctx) => {
        await ctx.reply("➛ Maaf ya, fitur ini lagi dinonaktifkan oleh owner karena berpotensi membahayakan nomor bot :>."); // Jika Anda tidak menghapus ini, terima kasih!
    }
};