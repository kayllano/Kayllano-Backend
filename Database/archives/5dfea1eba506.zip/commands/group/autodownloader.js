module.exports = {
    name: "autodownloader",
    aliases: ["autodl", "toggleautodl"],
    category: "group",
    permissions: {
        admin: true,
        botAdmin: true,
        group: true
    },

    code: async (ctx) => {
        try {
            // Arahkan ke setoption supaya konsisten dan terpusat
            // Autodl sekarang dikelola melalui setoption agar sinkron dengan opsi grup lainnya
            return await ctx.reply(
                `*⌜ Auto Downloader ⌟*\n` +
                `─────────────────\n` +
                `Fitur ini kini dikelola melalui perintah ${formatter.inlineCode("setoption")}.\n\n` +
                `*— Cara toggle Auto Downloader*\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix}setoption autodl`)}\n\n` +
                `*— Perintah berguna lainnya*\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix}setoption status`)} — Lihat semua status opsi grup\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix}setoption list`)}   — Lihat semua opsi yang tersedia\n\n` +
                `*— Platform yang didukung*\n` +
                `TikTok, YouTube, Instagram, Facebook, Twitter/X,\n` +
                `Pinterest, Spotify, SoundCloud, Capcut, Snapchat,\n` +
                `Reddit, Dailymotion, Vimeo, Kwai, Threads,\n` +
                `dan 40+ platform lainnya.\n\n` +
                `─────────────────\n` +
                `ℹ️ Jika Auto DL aktif bersamaan dengan Antilink,\n` +
                `link platform download dikecualikan dari blokir antilink\n` +
                `secara otomatis agar tidak konflik.`
            );

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};