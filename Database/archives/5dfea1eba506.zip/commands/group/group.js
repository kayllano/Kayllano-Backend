module.exports = {
name: "group",
category: "group",
permissions: {
admin: true,
botAdmin: true,
group: true
},

code: async (ctx) => {

const input =
    ctx.text?.trim();

if (!input)
    return await ctx.reply(
        `${tools.msg.generateInstruction(
            ["send"],
            ["text"]
        )}\n` +
        `${tools.msg.generateCmdExample(
            ctx.used,
            "open"
        )}\n` +
        tools.msg.generateNotes([
            `Ketik ${formatter.inlineCode(
                `${ctx.used.prefix}${ctx.used.command} list`
            )} untuk melihat daftar.`
        ])
    );

if (
    input.toLowerCase() ===
    "list"
) {

    const listText =
        await tools.list.get(
            "group"
        );

    return await ctx.reply(
        listText
    );

}

const args =
    input.split(/\s+/);

const action =
    args[0]?.toLowerCase();

const time =
    args[1];

const groupDb =
    ctx.db.group;

const isTime =
    /^([01]\d|2[0-3]):([0-5]\d)$/
        .test(time || "");

try {

    if (
        (
            action === "open" ||
            action === "close"
        ) &&
        isTime
    ) {

        if (
            action === "open"
        ) {
            groupDb.autoOpen =
                time;
        } else {
            groupDb.autoClose =
                time;
        }

        groupDb.save();

        return await ctx.reply(
            tools.msg.info(
                `✅ Jadwal ${
                    action === "open"
                        ? "buka"
                        : "tutup"
                } grup berhasil disimpan.\n\n` +
                `🕒 Waktu: ${time} WIB`
            )
        );

    }

    switch (action) {

        case "schedule":

            return await ctx.reply(
                `📅 Jadwal Grup\n\n` +
                `🔓 Buka : ${
                    groupDb.autoOpen ||
                    "Tidak ada"
                }\n` +
                `🔒 Tutup : ${
                    groupDb.autoClose ||
                    "Tidak ada"
                }`
            );

        case "unschedule":

            const hasOpen =
                !!groupDb.autoOpen;

            const hasClose =
                !!groupDb.autoClose;

            delete groupDb.autoOpen;
            delete groupDb.autoClose;

            groupDb.save();

            return await ctx.reply(
                tools.msg.info(
                    !hasOpen && !hasClose
                        ? "Tidak ada jadwal yang tersimpan."
                        : "Semua jadwal otomatis berhasil dihapus."
                )
            );

        case "open":
        case "close":
        case "lock":
        case "unlock":

            await ctx.group()[
                action
            ]();

            break;

        case "approve":

            await ctx.group()
                .joinApproval(
                    "on"
                );

            break;

        case "disapprove":

            await ctx.group()
                .joinApproval(
                    "off"
                );

            break;

        case "invite":

            await ctx.group()
                .membersCanAddMemberMode(
                    "on"
                );

            break;

        case "restrict":

            await ctx.group()
                .membersCanAddMemberMode(
                    "off"
                );

            break;

        default:

            return await ctx.reply(
                tools.msg.info(
                    `Setelan "${action}" tidak valid!`
                )
            );

    }

    await ctx.reply(
        tools.msg.info(
            "Berhasil mengubah setelan grup!"
        )
    );

} catch (error) {

    await tools.cmd.handleError(
        ctx,
        error
    );

}

}

};