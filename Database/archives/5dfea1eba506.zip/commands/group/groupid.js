module.exports = {
name: "cekidgc",
aliases: ["idgc", "groupid", "infogc"],
category: "group",

code: async (ctx) => {

    const url = ctx.args?.[0];

    if (!url) {
        return await ctx.reply(
            tools.msg.info(
                `Contoh penggunaan:_\n_${ctx.used.prefix}${ctx.used.command} https://chat.whatsapp.com/xxxxx`
            )
        );
    }

    const match = url.match(
        /chat\.whatsapp\.com\/([A-Za-z0-9]+)/
    );

    if (!match) {
        return await ctx.reply(
            tools.msg.info(
                "Link grup tidak valid!"
            )
        );
    }

    try {

        const inviteCode = match[1];

        const meta =
            await ctx.core.groupGetInviteInfo(
                inviteCode
            );

        const owner =
            meta.owner
                ? `@${meta.owner.split("@")[0]}`
                : "-";

        const text =
            `Informasi Grup\n\n` +
            `› Nama: ${meta.subject || "-"}\n` +
            `› ID: ${meta.id || "-"}\n` +
            `› Member: ${meta.size || meta.participants?.length || 0}\n` +
            `› Owner: ${owner}\n` +
            ``;

        await ctx.reply({
            text,
            mentions: meta.owner
                ? [meta.owner]
                : [],

            nativeFlow: [
                {
                    text: "Salin ID Grup",
                    copy: meta.id
                }
            ]
        });

    } catch (error) {

        await ctx.reply(
            tools.msg.info(
                "Link grup tidak valid, expired, atau grup tidak dapat diakses."
            )
        );

    }

}

};