module.exports = {
    name: "setoption",
    aliases: ["setopt"],
    category: "group",
    permissions: {
        admin: true,
        botAdmin: true,
        group: true
    },
    code: async (ctx) => {
        const input = ctx.text;

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // TANPA ARGUMEN — tampilkan panduan
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (!input)
            return await ctx.reply(
                `*⌜ Pengaturan Grup ⌟*\n` +
                `─────────────────\n` +
                `Gunakan perintah ini untuk mengaktifkan atau menonaktifkan\n` +
                `fitur-fitur keamanan dan moderasi grup.\n\n` +
                `*— Cara Pakai*\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} <nama_opsi`)}\n` +
                `  Contoh: ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} antilink`)}\n\n` +
                `*— Sub-perintah*\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} list`)}   — Lihat semua opsi yang tersedia\n` +
                `› ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} status`)} — Lihat status opsi yang aktif di grup ini\n\n` +
                `*— Catatan*\n` +
                `› Hanya admin grup yang bisa mengubah pengaturan ini.\n` +
                `› Perubahan langsung berlaku tanpa perlu restart bot.`
            );

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // LIST — daftar semua opsi
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (input.toLowerCase() === "list") {
            return await ctx.reply(
                `*⌜ Daftar Opsi Grup ⌟*\n` +
                `─────────────────\n` +
                `*— Moderasi Konten*\n` +
                `› ${formatter.inlineCode("antiaudio")} — Hapus otomatis pesan audio/suara\n` +
                `› ${formatter.inlineCode("antidocument")} — Hapus otomatis pesan dokumen/file\n` +
                `› ${formatter.inlineCode("antiimage")} — Hapus otomatis pesan gambar/foto\n` +
                `› ${formatter.inlineCode("antisticker")} — Hapus otomatis pesan stiker\n` +
                `› ${formatter.inlineCode("antivideo")} — Hapus otomatis pesan video\n` +
                `─────────────────\n` +
                `*— Moderasi Link*\n` +
                `› ${formatter.inlineCode("antilink")} — Blokir SEMUA link (URL apapun)\n` +
                `› ${formatter.inlineCode("antilinkgroup")} — Blokir link undangan grup WA saja\n` +
                `  (wa.me & chat.whatsapp.com)\n` +
                `─────────────────\n` +
                `*— Fitur Download*\n` +
                `› ${formatter.inlineCode("autodl")}  — Auto unduh link dari TikTok, YouTube,\n` +
                `  Instagram, dan 40+ platform lainnya\n` +
                `  ⚠️  Jika aktif bersamaan dengan antilink,\n` +
                `  link platform download dikecualikan dari blokir\n` +
                `─────────────────\n` +
                `*— Moderasi Lainnya*\n` +
                `› ${formatter.inlineCode("antigcsw")} — Hapus otomatis kiriman GC Story WA\n` +
                `› ${formatter.inlineCode("antitagsw")} — Hapus otomatis tag Story WA ke grup\n` +
                `› ${formatter.inlineCode("antispam")} — Peringatan jika kirim pesan terlalu cepat\n` +
                `› ${formatter.inlineCode("antitoxic")} — Hapus otomatis pesan kata-kata kasar\n` +
                `─────────────────\n` +
                `*— Lainnya*\n` +
                `› ${formatter.inlineCode("gamerestrict")} — Larang member menggunakan fitur game\n` +
                `› ${formatter.inlineCode("welcome")} — Kirim sambutan otomatis saat member baru masuk\n` +
                `─────────────────\n` +
                `*— Mode Hukuman (pilih salah satu)*\n` +
                `› ${formatter.inlineCode("warnonly")} — Member hanya diperingatkan (default)\n` +
                `› ${formatter.inlineCode("autokick")} — Member dikick setelah 3x peringatan\n` +
                `─────────────────\n` +
                `Ketik ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} status`)} untuk melihat status saat ini.`
            );
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // STATUS — tampilkan semua status opsi
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (input.toLowerCase() === "status") {
            const opt = ctx.db.group.option || {};

            const s = (val) => val ? "✅ Aktif" : "❌ Nonaktif";

            // Deteksi konflik antilink
            const antilinkConflict = opt.antilink && opt.autodl
                ? " ⚠️"
                : "";
            const antilinkGroupConflict = opt.antilinkgroup && opt.autodl
                ? " ⚠️"
                : "";

            const savedWarnings  = ctx.db.group.warnings || [];
            const maxWarn        = ctx.db.group.maxwarnings || 3;
            const warnSummary    = opt.autokick && savedWarnings.length > 0
                ? ` (${savedWarnings.length} member punya catatan peringatan)`
                : "";
            const punishMode = opt.autokick
                ? `Autokick — dikick otomatis setelah ${maxWarn}x peringatan${warnSummary}`
                : "Warnonly — pelanggaran dihapus & diberi tahu, tanpa hitungan peringatan";

            let statusText =
                `*⌜ Status Opsi Grup ⌟*\n` +
                `─────────────────\n` +
                `*— Moderasi Konten*\n` +
                `› Antiaudio: ${s(opt.antiaudio)}\n` +
                `› Antidocument: ${s(opt.antidocument)}\n` +
                `› Antiimage: ${s(opt.antiimage)}\n` +
                `› Antisticker: ${s(opt.antisticker)}\n` +
                `› Antivideo: ${s(opt.antivideo)}\n` +
                `─────────────────\n` +
                `*— Moderasi Link*\n` +
                `› Antilink: ${s(opt.antilink)}${antilinkConflict}\n` +
                `› Antilinkgroup: ${s(opt.antilinkgroup)}${antilinkGroupConflict}\n` +
                `─────────────────\n` +
                `*— Fitur Download*\n` +
                `› Auto DL: ${s(opt.autodl)}\n` +
                `─────────────────\n` +
                `*— Moderasi Lainnya*\n` +
                `› Antigcsw: ${s(opt.antigcsw)}\n` +
                `› Antitagsw: ${s(opt.antitagsw)}\n` +
                `› Antispam: ${s(opt.antispam)}\n` +
                `› Antitoxic: ${s(opt.antitoxic)}\n` +
                `─────────────────\n` +
                `*— Lainnya*\n` +
                `› Gamerestrict: ${s(opt.gamerestrict)}\n` +
                `› Welcome: ${s(opt.welcome)}\n` +
                `─────────────────\n` +
                `*— Mode Hukuman*\n` +
                `› ${punishMode}`;

            // Tampilkan peringatan konflik jika ada
            const conflicts = [];
            if (opt.antilink && opt.autodl)
                conflicts.push(
                    `⚠️ *Antilink + Auto DL* aktif bersamaan.\n` +
                    `   Link dari platform download (YouTube, TikTok, Instagram, dll.)\n` +
                    `   dikecualikan dari blokir antilink secara otomatis.`
                );
            if (opt.antilinkgroup && opt.autodl)
                conflicts.push(
                    `⚠️ *Antilinkgroup + Auto DL* aktif bersamaan.\n` +
                    `   Tidak ada konflik — antilinkgroup hanya blokir link undangan grup WA,\n` +
                    `   bukan link platform download.`
                );
            if (opt.antilink && opt.antilinkgroup)
                conflicts.push(
                    `ℹ️ *Antilink + Antilinkgroup* aktif bersamaan.\n` +
                    `   Antilink sudah mencakup semua link termasuk link grup WA.\n` +
                    `   Antilinkgroup tidak perlu diaktifkan jika antilink sudah aktif.`
                );

            if (conflicts.length > 0)
                statusText += `\n─────────────────\n*— Perhatian*\n` + conflicts.join("\n");

            return await ctx.reply(statusText);
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // TOGGLE OPSI
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        try {
            const groupDb = ctx.db.group;
            const opt     = (groupDb.option ||= {});
            const key     = input.toLowerCase();

            // ── Mode Punishment ──────────────────────────────
            if (key === "warnonly") {
                if (!opt.autokick) {
                    return await ctx.reply(
                        `*⌜ Mode Hukuman ⌟*\n` +
                        `─────────────────\n` +
                        `Mode ${formatter.inlineCode("warnonly")} sudah aktif (ini adalah mode default).\n\n` +
                        `Untuk beralih ke mode autokick:\n` +
                        `› Ketik ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} autokick`)}`
                    );
                }
                // Nonaktifkan autokick → kembali ke warnonly
                // Reset semua catatan warning — tidak relevan di mode warnonly
                opt.autokick      = false;
                groupDb.warnings  = [];
                groupDb.save();
                return await ctx.reply(
                    `*⧼ Mode Hukuman ⧽*\n` +
                    `─────────────────\n` +
                    `✅ Beralih ke mode ${formatter.inlineCode("warnonly")}.\n\n` +
                    `Di mode ini:\n` +
                    `› Pelanggaran tetap dihapus dan member diberi tahu\n` +
                    `› *Tidak ada hitungan peringatan* (tidak ada 1/3, 2/3, dst.)\n` +
                    `› Member tidak akan dikick, apapun yang terjadi\n\n` +
                    `Semua catatan peringatan member sebelumnya telah direset.`
                );
            }

            if (key === "autokick") {
                const current = opt.autokick || false;
                opt.autokick  = !current;
                groupDb.save();

                if (opt.autokick) {
                    const maxWarn = groupDb.maxwarnings || 3;
                    return await ctx.reply(
                        `*⧼ Mode Hukuman ⧽*\n` +
                        `─────────────────\n` +
                        `✅ Mode ${formatter.inlineCode("autokick")} *diaktifkan*.\n\n` +
                        `Member yang melanggar peraturan grup akan:\n` +
                        `› Peringatan ke-1 → dihapus + diberi tahu (1/${maxWarn})\n` +
                        `› Peringatan ke-2 → dihapus + diberi tahu (2/${maxWarn})\n` +
                        `› Peringatan ke-3 → *dikick dari grup* (3/${maxWarn})\n\n` +
                        `Hitungan peringatan dimulai dari 0 untuk semua member.\n` +
                        `Mode warnonly dinonaktifkan secara otomatis.`
                    );
                } else {
                    // Nonaktifkan autokick → reset warning, kembali ke warnonly
                    groupDb.warnings = [];
                    groupDb.save();
                    return await ctx.reply(
                        `*⧼ Mode Hukuman ⧽*\n` +
                        `─────────────────\n` +
                        `✅ Mode ${formatter.inlineCode("autokick")} *dinonaktifkan*.\n\n` +
                        `Kembali ke mode warnonly:\n` +
                        `› Pelanggaran tetap dihapus dan member diberi tahu\n` +
                        `› Tidak ada hitungan peringatan\n` +
                        `› Member tidak akan dikick\n\n` +
                        `Semua catatan peringatan member telah direset.`
                    );
                }
            }

            // ── Autodl (auto downloader) ─────────────────────
            if (key === "autodl") {
                const current = opt.autodl || false;
                opt.autodl    = !current;
                groupDb.save();

                if (opt.autodl) {
                    let note = "";
                    if (opt.antilink)
                        note = `\n─────────────────\n` +
                               `⚠️ *Perhatian — Antilink aktif*\n` +
                               `Link dari platform download (YouTube, TikTok, Instagram, dll.)\n` +
                               `akan dikecualikan dari antilink secara otomatis.\n` +
                               `Link selain platform download tetap diblokir.`;
                    return await ctx.reply(
                        `*⌜ Auto Downloader ⌟*\n` +
                        `─────────────────\n` +
                        `✅ Auto Downloader *diaktifkan* di grup ini.\n\n` +
                        `Cara kerja:\n` +
                        `› Kirim link dari TikTok, YouTube, Instagram,\n` +
                        `  Facebook, Twitter, Spotify, dan 40+ platform lainnya\n` +
                        `› Bot akan otomatis mendeteksi dan menawarkan unduhan\n\n` +
                        `Untuk menonaktifkan: ketik perintah yang sama lagi.` +
                        note
                    );
                } else {
                    return await ctx.reply(
                        `*⌜ Auto Downloader ⌟*\n` +
                        `─────────────────\n` +
                        `❌ Auto Downloader *dinonaktifkan* di grup ini.\n\n` +
                        `Link yang dikirim tidak akan lagi otomatis diproses untuk diunduh.`
                    );
                }
            }

            // ── Antilink ─────────────────────────────────────
            if (key === "antilink") {
                const current  = opt.antilink || false;
                opt.antilink   = !current;
                groupDb.save();

                if (opt.antilink) {
                    let note = "";
                    if (opt.autodl)
                        note = `\n─────────────────\n` +
                               `⚠️ *Perhatian — Auto Downloader aktif*\n` +
                               `Link dari platform download (YouTube, TikTok, Instagram, dll.)\n` +
                               `dikecualikan secara otomatis agar tidak konflik dengan Auto DL.\n` +
                               `Link selain platform tersebut tetap diblokir.`;
                    if (opt.antilinkgroup)
                        note += `\n─────────────────\n` +
                                `ℹ️ *Info — Antilinkgroup juga aktif*\n` +
                                `Antilink sudah mencakup semua link termasuk link grup WA.\n` +
                                `Kamu bisa menonaktifkan antilinkgroup jika mau.`;
                    return await ctx.reply(
                        `*⌜ Antilink ⌟*\n` +
                        `─────────────────\n` +
                        `✅ Antilink *diaktifkan*.\n\n` +
                        `Semua URL/link yang dikirim di grup ini akan otomatis\n` +
                        `dihapus dan pengirim akan mendapat peringatan.\n\n` +
                        `Ingin blokir link undangan grup WA saja? Gunakan:\n` +
                        `› ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} antilinkgroup`)}` +
                        note
                    );
                } else {
                    return await ctx.reply(
                        `*⌜ Antilink ⌟*\n` +
                        `─────────────────\n` +
                        `❌ Antilink *dinonaktifkan*.\n\n` +
                        `Member kembali diizinkan mengirim link di grup ini.`
                    );
                }
            }

            // ── Antilinkgroup ────────────────────────────────
            if (key === "antilinkgroup") {
                const current      = opt.antilinkgroup || false;
                opt.antilinkgroup  = !current;
                groupDb.save();

                if (opt.antilinkgroup) {
                    let note = "";
                    if (opt.antilink)
                        note = `\n─────────────────\n` +
                               `ℹ️ *Info — Antilink juga aktif*\n` +
                               `Antilink sudah mencakup semua link termasuk undangan grup WA.\n` +
                               `Antilinkgroup tidak menambah fungsi baru selagi antilink aktif.`;
                    return await ctx.reply(
                        `*⌜ Antilinkgroup ⌟*\n` +
                        `─────────────────\n` +
                        `✅ Antilinkgroup *diaktifkan*.\n\n` +
                        `Link undangan grup WhatsApp (wa.me & chat.whatsapp.com)\n` +
                        `akan otomatis dihapus dan pengirim mendapat peringatan.\n\n` +
                        `Link biasa (berita, YouTube, dll.) *tidak* akan terpengaruh.\n` +
                        `Hanya link undangan grup WA yang diblokir.` +
                        note
                    );
                } else {
                    return await ctx.reply(
                        `*⌜ Antilinkgroup ⌟*\n` +
                        `─────────────────\n` +
                        `❌ Antilinkgroup *dinonaktifkan*.\n\n` +
                        `Member kembali diizinkan mengirim link undangan grup WA.`
                    );
                }
            }

            // ── Opsi Lainnya ─────────────────────────────────
            const optionMeta = {
                antiaudio:    { label: "Antiaudio",    desc: "Semua pesan audio/suara akan otomatis dihapus." },
                antidocument: { label: "Antidocument", desc: "Semua pesan dokumen/file akan otomatis dihapus." },
                antiimage:    { label: "Antiimage",    desc: "Semua pesan gambar/foto akan otomatis dihapus." },
                antisticker:  { label: "Antisticker",  desc: "Semua pesan stiker akan otomatis dihapus." },
                antivideo:    { label: "Antivideo",    desc: "Semua pesan video akan otomatis dihapus." },
                antigcsw:     { label: "Antigcsw",     desc: "Kiriman GC Story WhatsApp akan otomatis dihapus." },
                antitagsw:    { label: "Antitagsw",    desc: "Tag Story WA ke grup akan otomatis dihapus." },
                antispam:     { label: "Antispam",     desc: "Member yang kirim pesan terlalu cepat akan diperingatkan." },
                antitoxic:    { label: "Antitoxic",    desc: "Pesan yang mengandung kata-kata kasar akan otomatis dihapus." },
                gamerestrict: { label: "Gamerestrict", desc: "Member tidak dapat menggunakan fitur game bot di grup ini." },
                welcome:      { label: "Welcome",      desc: "Bot akan mengirim pesan sambutan saat ada member baru yang bergabung." }
            };

            if (!optionMeta[key]) {
                return await ctx.reply(
                    `*⌜ Opsi Tidak Ditemukan ⌟*\n` +
                    `─────────────────\n` +
                    `Opsi ${formatter.inlineCode(input)} tidak dikenali.\n\n` +
                    `Ketik ${formatter.inlineCode(`${ctx.used.prefix + ctx.used.command} list`)} untuk melihat daftar opsi yang tersedia.`
                );
            }

            const meta      = optionMeta[key];
            const newStatus = !(opt[key] || false);
            opt[key]        = newStatus;
            groupDb.save();

            return await ctx.reply(
                `*⌜ ${meta.label} ⌟*\n` +
                `─────────────────\n` +
                `${newStatus ? "✅" : "❌"} ${meta.label} *${newStatus ? "diaktifkan" : "dinonaktifkan"}*.\n\n` +
                `${newStatus ? meta.desc : `Member kembali diizinkan mengirim konten yang sebelumnya diblokir oleh ${meta.label}.`}`
            );

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};