module.exports = {
    name: "bluearchive",
    aliases: ["ba", "randomba"],
    category: "image",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // FETCH IMAGE
            // =========================
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/random/ba",
                {
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            // =========================
            // SEND RESULT
            // =========================
            await ctx.reply({
                image: Buffer.from(data),
                caption: formatter.monospace("Random BA"),
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Ambil Lagi",
                        id: `${ctx.used.prefix + ctx.used.command}`
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};