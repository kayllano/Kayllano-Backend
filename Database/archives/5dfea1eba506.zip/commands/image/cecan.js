module.exports = {
    name: "cecan",
    aliases: ["cewek", "girl"],
    category: "image",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            const countries = [
                "japan",
                "china",
                "indonesia",
                "korea",
                "malaysia",
                "thailand",
                "vietnam",
                "hijaber"
            ];

            const type = ctx.args[0]?.toLowerCase();

            // =========================
            // MENU LIST
            // =========================
            if (!type) {
                const rows = countries.map(country => ({
                    title: country.charAt(0).toUpperCase() + country.slice(1),
                    description: `Random foto cecan ${country}`,
                    id: `${ctx.used.prefix + ctx.used.command} ${country}`
                }));

                return await ctx.reply({
                    text: formatter.monospace(
                        "Pilih negara asal cecan."
                    ),
                    footer: config.msg.footer,
                    nativeFlow: [
                        {
                            text: "Pilih Negara",
                            sections: [
                                {
                                    title: "Cecan",
                                    highlight_label: "✨",
                                    rows
                                }
                            ]
                        }
                    ]
                });
            }

            // =========================
            // INVALID CATEGORY
            // =========================
            if (!countries.includes(type)) {
                return await ctx.reply(
                    formatter.monospace(
                        `Negara "${type}" tidak tersedia.`
                    )
                );
            }

            // =========================
            // FETCH IMAGE
            // =========================
            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/random/cecan.php",
                {
                    params: { country: type },
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            // =========================
            // SEND RESULT
            // =========================
            await ctx.reply({
                image: Buffer.from(data),
                caption: formatter.monospace(
                    `Cecan: ${type.charAt(0).toUpperCase() + type.slice(1)}`
                ),
                footer: config.msg.footer,
                nativeFlow: [
                    // BUTTON LIST
                    {
                        text: "Pilih Negara",
                        sections: [
                            {
                                title: "Cecan",
                                highlight_label: "✨",
                                rows: countries.map(country => ({
                                    title: country.charAt(0).toUpperCase() + country.slice(1),
                                    description: `Random foto cecan ${country}`,
                                    id: `${ctx.used.prefix + ctx.used.command} ${country}`
                                }))
                            }
                        ]
                    },
                    // BUTTON REGENERATE
                    {
                        text: "Ambil Lagi",
                        id: `${ctx.used.prefix + ctx.used.command} ${type}`
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};
