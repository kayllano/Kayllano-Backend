module.exports = {
    name: "loli",
    aliases: ["randloli"],
    category: "image",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // FETCH IMAGE
            // =========================
            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/random/loli.php",
                {
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            // =========================
            // SEND RESULT
            // =========================
            await ctx.reply({
                image: Buffer.from(data),
                caption: formatter.monospace("Random Loli"),
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Ambil Lagi",
                        id: `${ctx.used.prefix + ctx.used.command}`
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};
