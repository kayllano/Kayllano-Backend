const axios = require("axios");

module.exports = {
    name: "waifu",
    category: "image",

    code: async (ctx) => {

        try {

            const categories = [
                "waifu",
                "neko",
                "shinobu",
                "megumin",
                "bully",
                "cuddle",
                "cry",
                "hug",
                "awoo",
                "kiss",
                "lick",
                "pat",
                "smug",
                "bonk",
                "yeet",
                "blush",
                "smile",
                "wave",
                "highfive",
                "handhold",
                "nom",
                "bite",
                "glomp",
                "slap",
                "kill",
                "happy",
                "wink",
                "poke",
                "dance",
                "cringe"
            ];

            // default category
            const type = ctx.args[0]?.toLowerCase() || "waifu";

            // validasi category
            if (!categories.includes(type)) {

                return await ctx.reply(
                    formatter.monospace(
                        `Kategori "${type}" tidak tersedia.`
                    )
                );
            }

            // =========================
            // FETCH IMAGE
            // =========================
            const response = await axios.get(
                "https://api.nexray.eu.cc/random/anime",
                {
                    params: {
                        type
                    },

                    responseType: "arraybuffer"
                }
            );

            const buffer = Buffer.from(response.data);

            // =========================
            // SEND RESULT
            // =========================
            await ctx.reply({

                image: buffer,

                caption: formatter.monospace(
                    `Anime Pict: ${type}`
                ),

                footer: config.msg.footer,

                nativeFlow: [

                    // BUTTON LIST
                    {
                        text: "Pilih Kategori",

                        sections: [
                            {
                                title: "Anime Picts",
                                highlight_label: "🌸",

                                rows: categories.map(category => ({
                                    title: category.toUpperCase(),
                                    description: `Generate random anime ${category}`,
                                    id: `${ctx.used.prefix + ctx.used.command} ${category}`
                                }))
                            }
                        ]
                    },

                    // BUTTON NEXT IMAGE
                    {
                        text: "Ambil Lagi",
                        id: `${ctx.used.prefix + ctx.used.command} ${type}`
                    }
                ]
            });

        } catch (error) {

            console.error(error);

            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};