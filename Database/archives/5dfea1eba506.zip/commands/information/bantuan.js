module.exports = {
    name: "bantuan",
    aliases: ["guide", "panduan", "faq"],
    category: "information",

    code: async (ctx) => {
        try {
            const p = ctx.used.prefix;
            const sub = ctx.args[0]?.toLowerCase();

            const topics = {
                coin:       "sistem coin",
                download:   "downloader",
                search:     "pencarian",
                ai:         "fitur AI",
                game:       "bermain game",
                group:      "pengaturan grup",
                setoption:  "setoption",
                profile:    "profil & level",
                maker:      "maker / generator"
            };

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // MENU BANTUAN
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (!sub) {
                const text =
                    `*⌜ Pusat Bantuan ⌟*\n` +
                    `───────────────\n` +
                    `Halo! Bot ini punya banyak fitur yang\n` +
                    `mungkin belum kamu kenal. Pilih topik\n` +
                    `di bawah untuk membaca panduannya.\n` +
                    `───────────────\n` +
                    `› ${p}bantuan coin\n` +
                    `› ${p}bantuan download\n` +
                    `› ${p}bantuan search\n` +
                    `› ${p}bantuan ai\n` +
                    `› ${p}bantuan game\n` +
                    `› ${p}bantuan group\n` +
                    `› ${p}bantuan setoption\n` +
                    `› ${p}bantuan profile\n` +
                    `› ${p}bantuan maker\n` +
                    `───────────────\n` +
                    `_Ketik salah satu perintah di atas_\n` +
                    `_untuk membaca penjelasan lengkapnya._`;

                return await ctx.reply({
                    text,
                    footer: config.msg.footer,
                    nativeFlow: [
                        {
                            text: "Pilih Topik",
                            sections: [
                                {
                                    title: "Topik Bantuan",
                                    rows: Object.entries(topics).map(([key, label]) => ({
                                        title: label.charAt(0).toUpperCase() + label.slice(1),
                                        description: `Panduan ${label}`,
                                        id: `${p}bantuan ${key}`
                                    }))
                                }
                            ]
                        }
                    ]
                });
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // COIN
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "coin") {
                return await ctx.reply(
                    `*⌜ Sistem Coin ⌟*\n` +
                    `───────────────\n` +
                    `Coin adalah mata uang bot. Hampir semua\n` +
                    `fitur membutuhkan coin untuk digunakan.\n\n` +
                    `*◈ Cara mendapatkan coin*\n` +
                    `› Setiap hari kamu mendapat coin gratis\n` +
                    `  lewat ${p}daily\n` +
                    `› Bermain game di ${p}menu game\n` +
                    `› Beli coin melalui owner bot\n` +
                    `› Upgrade ke Premium untuk coin Unlimited\n\n` +
                    `*◈ Cara cek coin*\n` +
                    `› Ketik ${p}coin untuk melihat saldo\n\n` +
                    `*◈ Catatan*\n` +
                    `› User Premium & Owner tidak dikenakan\n` +
                    `  biaya coin apapun\n` +
                    `› Coin bisa transfer antar akun dengan\n` +
                    `  menggunakan command ${p}transfer\n` +
                    `───────────────\n` +
                    `_Butuh coin lebih? Hubungi ${p}owner_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // DOWNLOAD
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "download") {
                return await ctx.reply(
                    `*⌜ Downloader ⌟*\n` +
                    `───────────────\n` +
                    `Bot bisa mengunduh konten dari berbagai\n` +
                    `platform hanya dengan kirim link-nya.\n\n` +
                    `*◈ Platform yang didukung*\n` +
                    `› YouTube  — ${p}ytdl <link>\n` +
                    `› TikTok   — ${p}tiktok <link>\n` +
                    `› Instagram — ${p}igdl <link>\n` +
                    `› Terabox  — ${p}terabox <link>\n` +
                    `› dan lainnya di ${p}menu downloader\n\n` +
                    `*◈ Cara pakai*\n` +
                    `1. Salin link dari aplikasinya\n` +
                    `2. Ketik perintah diikuti link\n` +
                    `   Contoh: ${p}ytdl https://youtu.be/xxx\n\n` +
                    `*◈ Catatan*\n` +
                    `› File di atas 300 MB tidak bisa diunduh\n` +
                    `› Pastikan link valid dan bisa diakses\n` +
                    `───────────────\n` +
                    `_Lihat semua perintah: ${p}menu downloader_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // SEARCH
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "search") {
                return await ctx.reply(
                    `*⌜ Pencarian ⌟*\n` +
                    `───────────────\n` +
                    `Fitur search memungkinkan kamu mencari\n` +
                    `berbagai informasi langsung lewat bot.\n\n` +
                    `*◈ Yang bisa dicari*\n` +
                    `› Lagu / lirik\n` +
                    `› Informasi anime & karakter\n` +
                    `› Berita terkini\n` +
                    `› Cuaca kota\n` +
                    `› dan lainnya\n\n` +
                    `*◈ Cara pakai*\n` +
                    `› Ketik perintah diikuti kata kunci\n` +
                    `  Contoh: ${p}cuaca Jakarta\n` +
                    `  Contoh: ${p}lirik Halu\n\n` +
                    `───────────────\n` +
                    `_Lihat semua perintah: ${p}menu search_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // AI
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "ai") {
                return await ctx.reply(
                    `*⌜ Fitur AI ⌟*\n` +
                    `───────────────\n` +
                    `Bot dilengkapi fitur kecerdasan buatan\n` +
                    `yang bisa membantu berbagai kebutuhan.\n\n` +
                    `*◈ AI Chat*\n` +
                    `› Ngobrol & tanya jawab bebas\n` +
                    `› Ketik: ${p}ai <pertanyaan atau topik>\n` +
                    `  Contoh: ${p}ai jelaskan black hole\n\n` +
                    `*◈ AI Generate*\n` +
                    `› Buat gambar dari deskripsi teks\n` +
                    `› Ketik: ${p}imagine <deskripsi>\n` +
                    `  Contoh: ${p}imagine anime girl in forest\n\n` +
                    `*◈ AI Misc*\n` +
                    `› Tools AI lain seperti deteksi gambar,\n` +
                    `  translate, summarize, dll\n\n` +
                    `───────────────\n` +
                    `_Lihat semua perintah: ${p}menu ai-chat_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // GAME
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "game") {
                return await ctx.reply(
                    `*⌜ Bermain Game ⌟*\n` +
                    `───────────────\n` +
                    `Bot punya berbagai game yang bisa dimainkan\n` +
                    `sendiri maupun bersama di grup.\n\n` +
                    `*◈ Cara mulai*\n` +
                    `› Ketik nama game yang ingin dimainkan\n` +
                    `  Contoh: ${p}tebakgambar\n\n` +
                    `*◈ Catatan penting*\n` +
                    `› Beberapa game hanya bisa dimainkan\n` +
                    `  di dalam grup\n` +
                    `› Admin grup bisa menonaktifkan game\n` +
                    `  lewat ${p}setoption gamerestrict\n` +
                    `› Satu sesi game harus selesai dulu\n` +
                    `  sebelum memulai game baru\n\n` +
                    `───────────────\n` +
                    `_Lihat semua game: ${p}menu game_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // GROUP
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "group") {
                return await ctx.reply(
                    `*⌜ Pengaturan Grup ⌟*\n` +
                    `───────────────\n` +
                    `Fitur grup hanya bisa digunakan oleh\n` +
                    `admin grup dan memerlukan bot sebagai admin.\n\n` +
                    `*◈ Fitur utama*\n` +
                    `› ${p}kick — keluarkan member\n` +
                    `› ${p}add — tambah member\n` +
                    `› ${p}promote — jadikan admin\n` +
                    `› ${p}demote — turunkan admin\n` +
                    `› ${p}mute — bisukan member\n` +
                    `› ${p}warn — beri peringatan manual\n` +
                    `› ${p}warnings — lihat daftar peringatan\n\n` +
                    `*◈ Proteksi otomatis*\n` +
                    `› Aktifkan lewat ${p}setoption\n` +
                    `› Contoh: ${p}setoption antilink\n\n` +
                    `*◈ Syarat*\n` +
                    `› Bot harus sudah dijadikan admin grup\n` +
                    `› Perintah hanya bisa dijalankan admin\n` +
                    `───────────────\n` +
                    `_Lihat semua perintah: ${p}menu group_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // SETOPTION
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "setoption") {
                return await ctx.reply(
                    `*⌜ Setoption — Panduan ⌟*\n` +
                    `───────────────\n` +
                    `Setoption digunakan untuk mengaktifkan atau\n` +
                    `menonaktifkan fitur proteksi otomatis di grup.\n` +
                    `Cukup ketik ulang perintah yang sama untuk\n` +
                    `toggle on/off.\n\n` +
                    `*◈ Cara pakai*\n` +
                    `› ${p}setoption <nama opsi>\n` +
                    `  Contoh: ${p}setoption antilink\n\n` +
                    `*◈ Daftar opsi proteksi*\n` +
                    `› antilink — hapus & beri peringatan\n` +
                    `   jika ada yang kirim link\n` +
                    `› antispam — tangani pesan berulang cepat\n` +
                    `› antitoxic — filter kata-kata kasar\n` +
                    `› antiimage — larang kirim gambar\n` +
                    `› antivideo — larang kirim video\n` +
                    `› antiaudio — larang kirim audio\n` +
                    `› antisticker — larang kirim stiker\n` +
                    `› antidocument — larang kirim dokumen\n` +
                    `› antigcsw — larang status WA di grup\n` +
                    `› antitagsw — larang tag grup di status\n` +
                    `› gamerestrict — nonaktifkan game di grup\n` +
                    `› welcome — pesan sambutan member baru\n\n` +
                    `*◈ Mode punishment*\n` +
                    `› Default: hanya peringatan (warnonly)\n` +
                    `  Member tidak akan dikick\n\n` +
                    `› Autokick: kick setelah 3x peringatan\n` +
                    `  Aktifkan dengan: ${p}setoption autokick\n\n` +
                    `› Kedua mode tidak bisa aktif bersamaan.\n` +
                    `  Nonaktifkan autokick untuk kembali\n` +
                    `  ke mode peringatan saja.\n\n` +
                    `*◈ Cek status*\n` +
                    `› ${p}setoption status\n` +
                    `───────────────\n` +
                    `_Hanya admin grup yang bisa menggunakan ini_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // PROFILE
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "profile") {
                return await ctx.reply(
                    `*⌜ Profil & Level ⌟*\n` +
                    `───────────────\n` +
                    `Setiap pengguna punya profil dan sistem\n` +
                    `level yang berkembang seiring penggunaan.\n\n` +
                    `*◈ Cara kerja level*\n` +
                    `› Setiap kali kamu mengirim pesan atau\n` +
                    `  menggunakan fitur, kamu mendapat XP\n` +
                    `› Terkumpul 100 XP = naik 1 level\n` +
                    `› Level naik bisa tampil otomatis jika\n` +
                    `  kamu aktifkan autolevelup\n\n` +
                    `*◈ Perintah profil*\n` +
                    `› ${p}profile — lihat profilmu\n` +
                    `› ${p}level — lihat level & XP\n` +
                    `› ${p}setprofile — atur preferensi profil\n` +
                    `› ${p}afk <alasan> — set status AFK\n\n` +
                    `*◈ Status pengguna*\n` +
                    `› Freemium — pengguna biasa, pakai coin\n` +
                    `› Premium  — akses semua fitur, coin unlimited\n` +
                    `› Owner    — akses penuh tanpa batas\n` +
                    `───────────────\n` +
                    `_Lihat profil kamu: ${p}profile_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // MAKER
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (sub === "maker") {
                return await ctx.reply(
                    `*⌜ Maker / Generator ⌟*\n` +
                    `───────────────\n` +
                    `Fitur maker digunakan untuk membuat\n` +
                    `berbagai konten atau gambar otomatis.\n\n` +
                    `*◈ Contoh yang tersedia*\n` +
                    `› Struk Dana palsu  — ${p}fakedana <nominal>\n` +
                    `› Struk OVO palsu   — ${p}fakeovo <nominal>\n` +
                    `› dan lainnya di menu maker\n\n` +
                    `*◈ Cara pakai*\n` +
                    `1. Ketik perintahnya\n` +
                    `2. Ikuti dengan parameter yang diminta\n` +
                    `   Contoh: ${p}fakedana 50000\n\n` +
                    `*◈ Catatan*\n` +
                    `› Fitur ini hanya untuk hiburan\n` +
                    `› Gunakan dengan bertanggung jawab\n` +
                    `───────────────\n` +
                    `_Lihat semua maker: ${p}menu maker_`
                );
            }

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // TOPIK TIDAK DITEMUKAN
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            return await ctx.reply(
                tools.msg.info(
                    `Topik ${formatter.inlineCode(sub)} tidak ditemukan.\n` +
                    `Ketik ${formatter.inlineCode(`${p}bantuan`)} untuk melihat daftar topik.`
                )
            );

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
