const fs = require("node:fs");

module.exports = {
    name: "donate",
    aliases: ["donasi", "support"],
    category: "information",

    code: async (ctx) => {
        try {
            const text =
                `✦ *Donasi*\n\n` +
                `Bantu bot ini tetap online dengan donasi kecilmu.\n` +
                `Setiap rupiah sangat berarti!\n\n` +
                `*Transfer:*\n` +
                `DANA: 085607588713\n` +
                `Pulsa/Kuota: 085607588713\n` +
                `QRIS: Scan gambar di atas\n\n` +
                `_Terima kasih sudah peduli. ♡_`;

            await new ButtonV2(ctx.core)
                .setTitle(config.bot.name)
                .setSubtitle("Donasi & Support")
                .setBody(text.trim())
                .setFooter(config.msg.footer)
                .setThumbnail(fs.readFileSync("./assets/qris.jpg"))
                .addButton("List Donatur", `${ctx.used.prefix}donatur`)
                .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
