module.exports = {
    name: "donatur",
    aliases: ["donatur"],
    category: "information",
    code: async (ctx) => {
        try {

            const donatur = [
                "Rahmawati",
                "Reimau Lilitz",
                "Jastin Linggar Tama",
                "Luki Zainur",
                "Lorenzo",
                "Aulia Fitriani",
                "Bagas Saputra",
                "Reva Oktaviani",
                "Gilang Nugraha",
                "Arsani Ariadeni",
                "Hafizh Ramadhan",
                "Andi (Yanzz Bot)",
            ];

            const list = donatur.map(name => `➛ ${name}`).join("\n");

            const text =
                `${list}\n\n` +
                `Ini adalah orang-orang baik yang telah ikut berkontribusi\n` +
                `dalam perjalanan bot ini. Tanpa mereka, bot ini mungkin\n` +
                `tidak akan bisa berjalan sampai hari ini.\n\n` +
                `Nama kamu bisa ada di sini juga — sekecil apapun\n` +
                `dukunganmu, itu nyata dan sangat berarti. ♡\n\n`+
                `_Regards: © Artoria // Halfy_`;

            await ctx.reply({
                text: text.trim(),
                mentions: [ctx.sender.jid]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
