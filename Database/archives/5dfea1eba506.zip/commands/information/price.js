module.exports = {
    name: "price",
    aliases: ["belibot", "harga", "sewa", "sewabot"],
    category: "information",
    code: async (ctx) => {
        await ctx.reply("*➛ List Harga*\n- Perhari/daily = 3k\n- Perminggu/weekly = 8k\n- Perbulan/monthly = 13k\n*➛ Premium User*\n- Perminggu/weekly = 5k\n- Perbulan/monthly = 10k\n\n*➛ Payment / Pembayaran*\n- QRIS\n- DANA\n- PULSA/KUOTA\n\nJika berminat silahkan hubungi nomor dibawah.\nNarahubung: +6285607588713 (Owner)"); // Jika Anda tidak menghapus ini, terima kasih!
    }
};