module.exports = {
    name: "sc",
    aliases: ["script"],
    category: "information",
    permissions: {},

    code: async (ctx) => {
        await new AIRich(ctx.core)
            .addProduct([{
                title: "SC Neko-Arc",
                brand: "Artoria",
                price: "Rp 35.000",
                sale_price: "Rp 20.000",
                url: "https://wa.me/6285607588713",
                image: "https://x.xcute.workers.dev/f/images/af479b085819.jpg",
                icon: "https://x.xcute.workers.dev/f/images/af479b085819.jpg"
            }])
            .addText(
                `Dapatkan script bot ini dengan harga *20k* saja!\n` +
                `Fitur yang kamu dapat:\n` +
                `• UI Simple & Rapi\n` +
                `• Button Interactive\n` +
                `• Respon Cepat\n` +
                `• No Enkripsi\n` +
                `• Mudah Dikustomisasi\n` +
                `• Free Apikey\n` +
                `Hubungi owner untuk pembelian:\n\n` +
                `[Pencet Disini!](https://wa.me/6285607588713)`
            )
            .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });
    }
};