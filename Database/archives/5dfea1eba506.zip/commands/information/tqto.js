module.exports = {
    name: "tqto",
    aliases: ["thanksto"],
    category: "information",
    code: async (ctx) => {
        await ctx.reply(
            "➛ Reimau von Lilitz (Developer)\n" +
            "➛ Halfy (Owner)\n" + 
            "➛ Jastin Linggar Tama\n" +
            "➛ Lia Wynn\n" +
            "➛ Rippanteq7\n" +
            "➛ Rizky Pratama\n" +
            "➛ Fan\n" +
            "➛ Luki Zainur\n" +
            "➛ Lorenzo\n" +
            "➛ Cakra\n" +
            "➛ Arsani Ariadeni (Donatur)\n" +
            "➛ Mahesa (Donatur)\n" +
            "➛ Dan kepada semua pihak yang telah membantu dalam pengembangan bot ini. (Banyak kalo diketik satu-satu)"
        ); // Jika Anda tidak menghapus ini, terima kasih!
    }
};