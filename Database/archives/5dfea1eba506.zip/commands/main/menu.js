const fs   = require("node:fs");
const path = require("node:path");
const os   = require("node:os");

module.exports = {
    name: "menu",
    aliases: ["allmenu", "help"],
    category: "main",

    code: async (ctx) => {
        try {
            const { cmd } = ctx.bot;

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // HELPER — kirim audio voice note
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            const sendAudio = async () => {
                const chatJid    = ctx._msg.key.remoteJid;
                const senderJid  = ctx.sender.jid;
                const senderId   = senderJid.replace("@s.whatsapp.net", "");
                const senderName = ctx._msg.pushName || "User";

                let jpegThumbnail;
                try {
                    const ppUrl = await ctx.core.profilePictureUrl(senderJid, "image");
                    const { data } = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 5000 });
                    jpegThumbnail = Buffer.from(data);
                } catch { jpegThumbnail = null; }

                await ctx.core.sendMessage(chatJid, {
                    audio: fs.readFileSync("/home/container/assets/artoria.ogg"),
                    mimetype: "audio/ogg; codecs=opus",
                    ptt: true,
                    contextInfo: {
                        stanzaId: "StatusBiz",
                        participant: "0@s.whatsapp.net",
                        quotedMessage: {
                            contactMessage: {
                                displayName: senderName,
                                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${senderName}\nORG:${senderName};\nTEL;type=CELL;type=VOICE;waid=${senderId}:${senderId}\nEND:VCARD`,
                                ...(jpegThumbnail && { jpegThumbnail })
                            }
                        },
                        remoteJid: "status@broadcast"
                    }
                });
            };

            const tag = {
                "ai-chat":     { label: "AI Chat" },
                "ai-generate": { label: "AI Generate" },
                "ai-misc":     { label: "AI Misc" },
                anime:         { label: "Anime" },
                nsfw:          { label: "NSFW" },
                converter:     { label: "Converter" },
                downloader:    { label: "Downloader" },
                game:          { label: "Game" },
                group:         { label: "Group" },
                primbon:       { label: "Primbon" },
                image:         { label: "Image" },
                maker:         { label: "Maker" },
                profile:       { label: "Profile" },
                search:        { label: "Search" },
                stalker:       { label: "Stalker" },
                tool:          { label: "Tool" },
                owner:         { label: "Owner" },
                information:   { label: "Information" },
                misc:          { label: "Miscellaneous" }
            };

            const thumbnails = [
                "https://x.xcute.workers.dev/f/images/e56afac98a77.jpg",
                "https://x.xcute.workers.dev/f/images/785090407c25.jpg",
                "https://x.xcute.workers.dev/f/images/782a4dc17ca6.jpg",
                "https://x.xcute.workers.dev/f/images/396aad2b1584.jpg",
                "https://x.xcute.workers.dev/f/images/8bf3696b92aa.jpg",
                "https://x.xcute.workers.dev/f/images/195010661ff6.jpg",
                "https://x.xcute.workers.dev/f/images/bee07dec89e4.jpg",
                "https://x.xcute.workers.dev/f/images/2c6b2a46b1c2.jpg",
                "https://x.xcute.workers.dev/f/images/9e9acb3ee395.jpg",
                "https://x.xcute.workers.dev/f/images/c83e272c2278.jpg",
                "https://x.xcute.workers.dev/f/images/6347c69daa2f.jpg",
                "https://x.xcute.workers.dev/f/images/464fae6c97fa.jpg",
                "https://x.xcute.workers.dev/f/images/ded94729fd60.jpg",
                "https://x.xcute.workers.dev/f/images/dc41330ae1ee.jpg",
                "https://x.xcute.workers.dev/f/images/f45db1df0e55.jpg"
            ];

            const randomThumbnail =
                thumbnails[Math.floor(Math.random() * thumbnails.length)];

            const getCommands = (categories) => {
                const result = {};
                const allCmds = Array.from(cmd.values());
                categories.forEach(cat => {
                    const filtered = allCmds
                        .filter(c => c.category === cat)
                        .map(c => ({ name: c.name, permissions: c.permissions || {} }));
                    if (filtered.length > 0) result[cat] = filtered;
                });
                return result;
            };

            const formatPerms = (perms) => {
                const badges = [];
                if (perms.coin)    badges.push("ⓒ");
                if (perms.group)   badges.push("Ⓖ");
                if (perms.owner)   badges.push("Ⓞ");
                if (perms.premium) badges.push("Ⓟ");
                if (perms.private) badges.push("ⓟ");
                return badges.length ? ` ${badges.join("")}` : "";
            };

            // Timezone WIB
            const nowWIB = new Date(
                new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" })
            );
            const hour = nowWIB.getHours();

            const greeting =
                hour >= 5  && hour < 11 ? "Selamat pagi"  :
                hour >= 11 && hour < 15 ? "Selamat siang" :
                hour >= 15 && hour < 18 ? "Selamat sore"  :
                                          "Selamat malam";

            const timeWIB = nowWIB.toLocaleTimeString("id-ID", {
                hour: "2-digit",
                minute: "2-digit"
            });

            const dateWIB = nowWIB.toLocaleDateString("id-ID", {
                weekday: "long",
                day: "numeric",
                month: "long"
            });

            // Status server
            const cpuLoad  = os.loadavg()[0];
            const cpuCores = os.cpus().length;
            const loadPct  = (cpuLoad / cpuCores) * 100;
            const ramPct   = ((os.totalmem() - os.freemem()) / os.totalmem()) * 100;

            const serverStatus =
                loadPct > 80 || ramPct > 85
                    ? "Degraded"
                    : "Online";

            const quotes = [
                "Jangan lupa .donasi agar bot tetap online!",
                "Ketik .bantuan jika kamu kebingungan.",
                "Bot ini gratis, tapi server tidak. Yuk .donasi!",
                "Gunakan bot dengan bijak, ya.",
                "Fitur baru? Cek terus updatenya di grup!"
            ];

            const randomQuote =
                quotes[Math.floor(Math.random() * quotes.length)];

            const input = ctx.args[0]?.toLowerCase();

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // CATEGORY MENU / ALL MENU
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (input || ctx.used.command === "allmenu") {

                const selectedCats =
                    input === "all" || ctx.used.command === "allmenu"
                        ? Object.keys(tag)
                        : (tag[input] ? [input] : []);

                const commandsData = getCommands(selectedCats);

                if (Object.keys(commandsData).length === 0) {
                    return await ctx.reply("Kategori tidak ditemukan.");
                }

                let text = "";

                for (const [key, list] of Object.entries(commandsData)) {
                    const { label } = tag[key] || { label: key };
                    text += `┌── ⌗${label}\n`;
                    list.forEach((c, i) => {
                        const isLast = i === list.length - 1;
                        text += `${isLast ? "└•" : "├•"} ${ctx.used.prefix + c.name}${formatPerms(c.permissions)}\n`;
                    });
                    text += "\n";
                }

                text += "ⓒ Coin · Ⓖ Group · Ⓞ Owner · Ⓟ Premium";

                await new ButtonV2(ctx.core)
                    .setTitle(config.bot.name)
                    .setSubtitle(`${serverStatus} · ${timeWIB} WIB`)
                    .setBody(formatter.monospace(text.trim()))
                    .setFooter(config.msg.footer)
                    .setThumbnail(randomThumbnail)
                    .addRawButton({
                        buttonText: { displayText: "⦂ Navigasi" },
                        buttonId: "menu",
                        type: 1,
                        nativeFlowInfo: {
                            name: "single_select",
                            paramsJson: JSON.stringify({
                                title: "Menu Lainnya",
                                sections: [{
                                    title: "Built by Artoria",
                                    rows: [
                                        {
                                            title: "Main Menu",
                                            description: "Kembali ke menu utama",
                                            id: `${ctx.used.prefix}menu`
                                        },
                                        {
                                            title: "Semua Perintah",
                                            description: "Tampilkan seluruh daftar perintah",
                                            id: `${ctx.used.prefix}menu all`
                                        },
                                        {
                                            title: "Sewa Bot",
                                            description: "Lihat paket harga sewa bot",
                                            id: `${ctx.used.prefix}price`
                                        },
                                        {
                                            title: "Donasi",
                                            description: "Khusus orang baik",
                                            id: `${ctx.used.prefix}donasi`
                                        },
                                        {
                                            title: "Speedtest",
                                            description: "Cek performa & spesifikasi server",
                                            id: `${ctx.used.prefix}ping`
                                        },
                                        {
                                            title: "Hubungi Owner",
                                            description: "Kontak langsung owner bot",
                                            id: `${ctx.used.prefix}owner`
                                        }
                                    ]
                                }]
                            })
                        }
                    })
                    .addButton("⌕ Script", `${ctx.used.prefix}sc`)
                    .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

            } else {

                // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                // MAIN MENU
                // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                const userDb    = ctx.db.user;
                const totalCmds = Array.from(cmd.values()).length;

                const statusText =
                    ctx.sender.isOwner()
                        ? "Owner"
                        : userDb?.premium
                            ? `Premium · ${
                                userDb?.premiumExpiration
                                    ? `${tools.msg.convertMsToDuration(
                                        Date.now() - userDb.premiumExpiration,
                                        ["hari", "jam"]
                                    )} lagi`
                                    : "Selamanya"
                              }`
                            : "Freemium";

                const databaseSize =
                    fs.existsSync(ctx.bot.databaseDir)
                        ? tools.msg.formatSize(
                            fs.readdirSync(ctx.bot.databaseDir)
                                .reduce((total, file) =>
                                    total + fs.statSync(
                                        path.join(ctx.bot.databaseDir, file)
                                    ).size,
                                0) / 1024
                        )
                        : "N/A";

                // BODY — greeting + tanggal/jam aja
                const senderNumber = ctx.sender.jid.split("@")[0];
                const bodyText =
                    `${greeting}, @${senderNumber}\n` +
                    `${dateWIB} · ${timeWIB} WIB`;

                // FOOTER — USER card + SYSTEM card + watermark
                const footerText =
                    `┌─ ⎋ USER ───\n` +
                    `│Status: ${statusText}\n` +
                    `│Level: Lv.${userDb?.level || 0} · ${userDb?.xp || 0}/100 xp\n` +
                    `│Coin: ${ctx.sender.isOwner() || userDb?.premium ? "Unlimited" : (userDb?.coin || 0)}\n` +
                    `└─────────────\n\n` +

                    `┌─ ⎋ SYSTEM ───\n` +
                    `│Status: ${serverStatus}\n` +
                    `│Mode: ${tools.msg.ucwords(ctx.db.bot?.mode || "public")}\n` +
                    `│Uptime: ${tools.msg.convertMsToDuration(Date.now() - ctx.me.readyAt)}\n` +
                    `│Database: ${databaseSize}\n` +
                    `│Commands: ${totalCmds} cmd\n` +
                    `└─────────────\n\n` +

                    `${randomQuote}\n\n` +
                    `${config.msg.footer}`;

                await new ButtonV2(ctx.core)
                    .setTitle(config.bot.name)
                    .setSubtitle(`${serverStatus} · ${timeWIB} WIB`)
                    .setBody(bodyText)
                    .setFooter(footerText)
                    .setContextInfo({ mentionedJid: [ctx.sender.jid] })
                    .setThumbnail(randomThumbnail)
                    .addRawButton({
                        buttonText: { displayText: "☱ Menu" },
                        buttonId: "menu",
                        type: 1,
                        nativeFlowInfo: {
                            name: "single_select",
                            paramsJson: JSON.stringify({
                                title: "Pilih Kategori",
                                sections: [
                                    {
                                        title: "Umum",
                                        rows: [
                                            { title: "Semua Perintah", description: "Tampilkan seluruh daftar perintah", id: `${ctx.used.prefix}menu all` }
                                        ]
                                    },
                                    {
                                        title: "Kecerdasan Buatan",
                                        rows: [
                                            { title: "AI Chat",     description: "Perintah AI Chat",     id: `${ctx.used.prefix}menu ai-chat`     },
                                            { title: "AI Generate", description: "Perintah AI Generate", id: `${ctx.used.prefix}menu ai-generate` },
                                            { title: "AI Misc",     description: "Perintah AI Misc",     id: `${ctx.used.prefix}menu ai-misc`     }
                                        ]
                                    },
                                    {
                                        title: "Utilitas",
                                        rows: [
                                            { title: "Downloader", description: "Menu Downloader", id: `${ctx.used.prefix}menu downloader` },
                                            { title: "Tool",       description: "Menu Tool",       id: `${ctx.used.prefix}menu tool`       },
                                            { title: "Search",     description: "Menu Search",     id: `${ctx.used.prefix}menu search`     },
                                            { title: "Converter",  description: "Menu Converter",  id: `${ctx.used.prefix}menu converter`  },
                                            { title: "Stalker",    description: "Menu Stalker",    id: `${ctx.used.prefix}menu stalker`    }
                                        ]
                                    },
                                    {
                                        title: "Hiburan",
                                        rows: [
                                            { title: "Game",    description: "Menu Game",    id: `${ctx.used.prefix}menu game`    },
                                            { title: "Maker",   description: "Menu Maker",   id: `${ctx.used.prefix}menu maker`   },
                                            { title: "Image",   description: "Menu Image",   id: `${ctx.used.prefix}menu image`   },
                                            { title: "Primbon", description: "Menu Primbon", id: `${ctx.used.prefix}menu primbon` },
                                            { title: "Misc",    description: "Menu Misc",    id: `${ctx.used.prefix}menu misc`    }
                                        ]
                                    },
                                    {
                                        title: "Anime & NSFW",
                                        rows: [
                                            { title: "Anime", description: "Menu Anime", id: `${ctx.used.prefix}menu anime` },
                                            { title: "NSFW",  description: "Menu NSFW",  id: `${ctx.used.prefix}menu nsfw`  }
                                        ]
                                    },
                                    {
                                        title: "Sosial",
                                        rows: [
                                            { title: "Group",       description: "Menu Group",       id: `${ctx.used.prefix}menu group`       },
                                            { title: "Profile",     description: "Menu Profile",     id: `${ctx.used.prefix}menu profile`     },
                                            { title: "Information", description: "Menu Information", id: `${ctx.used.prefix}menu information` }
                                        ]
                                    },
                                    {
                                        title: "Sistem",
                                        rows: [
                                            { title: "Owner", description: "Menu Owner", id: `${ctx.used.prefix}menu owner` }
                                        ]
                                    }
                                ]
                            })
                        }
                    })
                    .addButton("⌕ Script", `${ctx.used.prefix}sc`)
                    .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

                await sendAudio();
            }

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};