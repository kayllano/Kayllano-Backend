const FormData = require("form-data");

module.exports = {
    name: "fakeberita",
    aliases: ["beritapalsu"],
    category: "maker",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const text = ctx.text || ctx.quoted?.body;

            let buffer = null;
            if (ctx.quoted?.download) {
                buffer = await ctx.quoted.download();
            } else if (ctx.msg?.download) {
                buffer = await ctx.msg.download();
            }

            if (!text && !buffer) {
                return await ctx.reply({
                    text: `*Fake Berita Generator*\n\n` +
                        `› Format : .fakeberita [teks berita]\n` +
                        `› Contoh : .fakeberita Viral! Jokowi mencuri 19jt lapangan pekerjaan\n\n` +
                        `› Kirim/reply gambar beserta teks untuk dijadikan thumbnail berita`,
                    footer: config.msg.footer
                });
            }

            if (!text) {
                return await ctx.reply(tools.msg.info("Sertakan teks berita!\nContoh: .fakeberita Viral! Artoria ketangkep polisi"));
            }

            if (!buffer) {
                return await ctx.reply(tools.msg.info("Sertakan gambar sebagai thumbnail berita!"));
            }

            await ctx.reply(tools.msg.info("Membuat berita palsu..."));

            // =========================
            // UPLOAD BUFFER KE CDN
            // =========================
            const form = new FormData();
            form.append("file", buffer, "image.jpg");

            const { data: upload } = await axios.post(
                "https://tmpfiles.org/api/v1/upload",
                form,
                {
                    headers: form.getHeaders(),
                    timeout: 30000
                }
            );

            const uploadUrl = upload?.data?.url?.replace("tmpfiles.org/", "tmpfiles.org/dl/");
            if (!uploadUrl) {
                return await ctx.reply(tools.msg.info("Gagal mengupload gambar. Coba lagi nanti."));
            }

            // =========================
            // FETCH IMAGE
            // =========================
            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/maker/berita.php",
                {
                    params: {
                        text,
                        url: uploadUrl
                    },
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                image: Buffer.from(data),
                caption: `› ${formatter.bold("Headline")} : ${text}`,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};