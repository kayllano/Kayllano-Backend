module.exports = {
    name: "fakedana",
    aliases: ["fdana"],
    category: "maker",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const nominal = ctx.args[0];

            if (!nominal) {
                return await ctx.reply({
                    text: `*Fake Dana Generator*\n\n` +
                        `› Format : .fakedana [nominal]\n` +
                        `› Contoh : .fakedana 50000`,
                    footer: config.msg.footer
                });
            }

            const cleaned = nominal.replace(/[.,]/g, "");
            if (isNaN(cleaned) || Number(cleaned) <= 0) {
                return await ctx.reply(tools.msg.info("Nominal tidak valid. Masukkan angka saja, contoh: 50000"));
            }

            await ctx.reply(tools.msg.info("Membuat struk Dana palsu..."));

            // =========================
            // FETCH IMAGE
            // kirim angka mentah ke API, bukan yang sudah diformat
            // =========================
            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/maker/fake-dana.php",
                {
                    params: { text: cleaned },
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            // format hanya untuk caption
            const formattedNominal = Number(cleaned).toLocaleString("id-ID");

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                image: Buffer.from(data),
                caption:
                    `› ${formatter.bold("Nominal")} : Rp${formattedNominal}`,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};