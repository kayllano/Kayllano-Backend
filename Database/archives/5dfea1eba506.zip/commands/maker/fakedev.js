const axios = require("axios");
const FormData = require("form-data");

module.exports = {
name: "fakedev",
aliases: ["fd"],
category: "maker",

code: async (ctx) => {

    try {

        const text =
            ctx.text ||
            ctx.quoted?.body;

        let buffer = null;

        if (ctx.quoted?.download) {
            buffer =
                await ctx.quoted.download();
        } else if (ctx.msg?.download) {
            buffer =
                await ctx.msg.download();
        }

        if (!text && !buffer) {
            return await ctx.reply(
                tools.msg.info(
                    "Reply atau kirim gambar terlebih dahulu."
                ) +
                "\n" +
                tools.msg.info(
                    `Contoh:\n${ctx.used.prefix}${ctx.used.command} Artoria`
                )
            );
        }

        if (!text) {
            return await ctx.reply(
                tools.msg.info(
                    "Masukkan nama terlebih dahulu."
                ) +
                "\n" +
                tools.msg.info(
                    `Contoh:\n${ctx.used.prefix}${ctx.used.command} Artoria`
                )
            );
        }

        if (!buffer) {
            return await ctx.reply(
                tools.msg.info(
                    "Reply atau kirim gambar terlebih dahulu."
                )
            );
        }

        await ctx.reply(
            tools.msg.info(
                "Membuat Fake Developer..."
            )
        );

        const form =
            new FormData();

        form.append(
            "file",
            buffer,
            "image.jpg"
        );

        const {
            data: upload
        } = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form,
            {
                headers:
                    form.getHeaders(),
                timeout: 30000
            }
        );

        const imageUrl =
            upload?.data?.url
                ?.replace(
                    "tmpfiles.org/",
                    "tmpfiles.org/dl/"
                );

        if (!imageUrl) {
            return await ctx.reply(
                tools.msg.info(
                    "Gagal mengupload gambar."
                )
            );
        }

        const api =
            `https://api.synoxcloud.xyz/canvas/fakedev-2?urlfoto=${encodeURIComponent(imageUrl)}&teks=${encodeURIComponent(text)}`;

        const {
            data
        } = await axios.get(
            api,
            {
                responseType:
                    "arraybuffer",
                timeout: 30000
            }
        );

        await ctx.reply({
            image:
                Buffer.from(data),
            caption:
                `*• Fake Developer*\n\n` +
                `› Nama : ${text}`,
            footer:
                config.msg.footer
        });

    } catch (error) {

        await tools.cmd.handleError(
            ctx,
            error,
            true
        );

    }

}

};