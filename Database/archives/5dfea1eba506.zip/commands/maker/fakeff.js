module.exports = {
name: "fakeff",
category: "maker",

permissions: {
    coin: 10
},

code: async (ctx) => {
    const input =
        ctx.text ||
        ctx.quoted?.body;

    if (!input) {
        return await ctx.reply(
            `${tools.msg.generateInstruction(["send"], ["nickname"])}\n` +
            tools.msg.generateCmdExample(
                ctx.used,
                "artoria"
            )
        );
    }

    if (input.length > 50) {
        return await ctx.reply(
            tools.msg.info(
                "Maksimal 50 karakter!"
            )
        );
    }

    try {

        const result =
            `https://api.nexray.eu.cc/maker/fakelobyff?nickname=${encodeURIComponent(input)}`;

        await ctx.reply({
            image: {
                url: result
            }
        });

    } catch (error) {
        await tools.cmd.handleError(
            ctx,
            error,
            true
        );
    }
}

};