module.exports = {
    name: "fakeovo",
    aliases: ["fovo"],
    category: "maker",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {
            const nominal = ctx.args[0];

            if (!nominal) {
                return await ctx.reply(
                    `*✦ Fake OVO Generator*\n\n` +
                    `Cara pakai:\n` +
                    `— \`${ctx.used.prefix}fakeovo <nominal>\`\n\n` +
                    `Contoh:\n` +
                    `— \`${ctx.used.prefix}fakeovo 50000\``
                );
            }

            // Validasi nominal harus angka
            if (isNaN(nominal)) {
                return await ctx.reply(
                    tools.msg.info(
                        "Nominal tidak valid. Masukkan angka saja, contoh: 50000"
                    )
                );
            }

            await ctx.reply(
                tools.msg.info(
                    "Membuat struk OVO palsu..."
                )
            );

            // Format nominal ke 1.000 (pakai titik sebagai pemisah ribuan)
            const formattedNominal = Number(nominal).toLocaleString("id-ID");

            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/maker/fake-ovo.php",
                {
                    params: {
                        amount: formattedNominal
                    },
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            await ctx.reply({
                image: Buffer.from(data),
                caption: tools.msg.info(
                    `Struk OVO palsu dengan nominal *Rp${formattedNominal}* berhasil dibuat.`
                )
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error
            );
        }
    }
};
