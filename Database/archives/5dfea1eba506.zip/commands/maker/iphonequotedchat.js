module.exports = {
name: "iphonequotedchat",
aliases: ["iqc"],
category: "maker",

permissions: {
    coin: 10
},

code: async (ctx) => {
    const input =
        ctx.text ||
        ctx.quoted?.body;

    if (!input) {
        return await ctx.reply(
            `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
            tools.msg.generateCmdExample(
                ctx.used,
                "siapa presiden Indonesia sekarang?"
            )
        );
    }

    if (input.length > 1000) {
        return await ctx.reply(
            tools.msg.info(
                "Maksimal 1000 karakter!"
            )
        );
    }

    try {

        const result =
            `https://api.nexray.eu.cc/maker/iqc?text=${encodeURIComponent(input)}`;

        await ctx.reply({
            image: {
                url: result
            }
        });

    } catch (error) {
        await tools.cmd.handleError(
            ctx,
            error,
            true
        );
    }
}

};