const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const fs   = require("node:fs");
const path = require("node:path");
const https = require("node:https");
const http  = require("node:http");

const ASSETS_DIR    = path.join(__dirname, "assets", "tiktokchat");
const FONTS_DIR     = path.join(ASSETS_DIR, "fonts");
const TEMPLATE_PATH = path.join(ASSETS_DIR, "template.png");
const TEMPLATE_URL  = "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/qyzwa.png";

const FONT_ASSETS = [
    { name: "PlusJakartaSans-Regular", file: "PlusJakartaSans-Regular.ttf", url: "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Regular.ttf", family: "Plus Jakarta Sans" },
    { name: "PlusJakartaSans-Medium",  file: "PlusJakartaSans-Medium.ttf",  url: "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Medium.ttf",  family: "Plus Jakarta Sans" },
    { name: "PlusJakartaSans-Bold",    file: "PlusJakartaSans-Bold.ttf",    url: "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Bold.ttf",    family: "Plus Jakarta Sans" },
    { name: "FontAwesome-Solid",       file: "fa-solid-900.ttf",            url: "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/fa-solid-900.ttf",            family: "Font Awesome 6 Free" },
    { name: "NotoColorEmoji",          file: "NotoColorEmoji.ttf",          url: "https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf",                     family: "Noto Color Emoji" },
];

const MENU_ICONS = [
    { unicode: "\uf3e5", text: "Balas",            color: "#000000" },
    { unicode: "\uf064", text: "Teruskan",         color: "#000000" },
    { unicode: "\uf0c5", text: "Salin",            color: "#000000" },
    { unicode: "\uf1ab", text: "Terjemahkan",      color: "#000000" },
    { unicode: "\uf2ed", text: "Hapus untuk saya", color: "#000000" },
    { unicode: "\uf024", text: "Laporkan",         color: "#ea4335" },
];

const CFG = {
    topPPX: 183, topPPY: 83, topPPRadius: 42,
    topNameX: 250, topNameY: 82, topNameSize: 34,
    chatPPX: 75, chatPPRadius: 38,
    textX: 175, textY: 962,
    bubbleWidth: 520, textSize: 30,
    bubbleBgColor: "#ffffff", textColor: "#161823",
};

function fetchBuffer(url) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith("https") ? https : http;
        client.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, (res) => {
            if (res.statusCode === 301 || res.statusCode === 302)
                return fetchBuffer(res.headers.location).then(resolve).catch(reject);
            if (res.statusCode !== 200)
                return reject(new Error(`HTTP ${res.statusCode}`));
            const chunks = [];
            res.on("data", c => chunks.push(c));
            res.on("end", () => resolve(Buffer.concat(chunks)));
            res.on("error", reject);
        }).on("error", reject);
    });
}

async function ensureAssets() {
    fs.mkdirSync(FONTS_DIR, { recursive: true });
    if (!fs.existsSync(TEMPLATE_PATH))
        fs.writeFileSync(TEMPLATE_PATH, await fetchBuffer(TEMPLATE_URL));
    for (const font of FONT_ASSETS) {
        const dest = path.join(FONTS_DIR, font.file);
        if (!fs.existsSync(dest))
            fs.writeFileSync(dest, await fetchBuffer(font.url));
        GlobalFonts.registerFromPath(dest, font.family);
    }
}

function wrapText(ctx, text, maxWidth) {
    const words = text.split(/(\s+)/);
    const lines = [];
    let cur = "";
    for (const word of words) {
        if (!word) continue;
        if (word.trim() === "" && cur === "") continue;
        const test = cur + word;
        if (ctx.measureText(test).width > maxWidth) {
            if (cur !== "") { lines.push(cur.trimEnd()); cur = word.trimStart(); }
            else { lines.push(test); cur = ""; }
        } else cur = test;
    }
    if (cur.trim()) lines.push(cur.trimEnd());
    return lines;
}

function drawRoundedRect(ctx, x, y, w, h, r, fill, stroke = null, shadow = false) {
    ctx.save();
    if (shadow) { ctx.shadowColor = "rgba(0,0,0,0.05)"; ctx.shadowBlur = 40; ctx.shadowOffsetY = 12; }
    ctx.fillStyle = fill;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
    ctx.restore();
}

function drawCircleImage(ctx, img, cx, cy, r) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
    ctx.restore();
}

async function renderTiktokChat(username, chatText, avatarSrc) {
    await ensureAssets();

    const templateImage = await loadImage(TEMPLATE_PATH);
    const avatarBuffer  = await fetchBuffer(avatarSrc);
    const avatarImage   = await loadImage(avatarBuffer);

    const canvas = createCanvas(1080 * 2, 2280 * 2);
    const ctx    = canvas.getContext("2d");

    ctx.scale(2, 2);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    ctx.clearRect(0, 0, 1080, 2280);
    ctx.drawImage(templateImage, 0, 0, 1080, 2280);

    drawCircleImage(ctx, avatarImage, CFG.topPPX, CFG.topPPY, CFG.topPPRadius);

    ctx.font         = `bold ${CFG.topNameSize}px 'Plus Jakarta Sans', 'Noto Color Emoji'`;
    ctx.fillStyle    = "#000000";
    ctx.textAlign    = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(username, CFG.topNameX, CFG.topNameY);

    ctx.font = `500 ${CFG.textSize}px 'Plus Jakarta Sans', 'Noto Color Emoji'`;

    const lines = wrapText(ctx, chatText, CFG.bubbleWidth - 52);
    const lineH = CFG.textSize * 1.45;

    let maxW = 0;
    for (const l of lines) {
        const w = ctx.measureText(l).width;
        if (w > maxW) maxW = w;
    }

    const padX    = 30, padY = 24;
    const bubbleW = Math.max(maxW + padX * 2, 180);
    const bubbleH = lines.length * lineH + padY * 2;
    const bubbleX = CFG.textX - padX;
    const bubbleY = CFG.textY - padY;

    drawCircleImage(ctx, avatarImage, CFG.chatPPX, bubbleY + bubbleH / 2, CFG.chatPPRadius);
    drawRoundedRect(ctx, bubbleX, bubbleY, bubbleW, bubbleH, 35, CFG.bubbleBgColor);

    ctx.fillStyle    = CFG.textColor;
    ctx.textAlign    = "left";
    ctx.textBaseline = "middle";

    lines.forEach((line, i) => {
        const lineY = CFG.textY + i * lineH + CFG.textSize / 2;
        ctx.fillText(line, CFG.textX, lineY);
    });

    const menuX = 90;
    const menuY = bubbleY + bubbleH + 28;
    drawRoundedRect(ctx, menuX, menuY, 565, 580, 40, "#ffffff", "rgba(0,0,0,0.02)", true);

    const itemH = 90, iconX = menuX + 60, labelX = menuX + 130;
    MENU_ICONS.forEach((item, i) => {
        const cy = menuY + 25 + i * itemH + itemH / 2;
        ctx.fillStyle    = item.color;
        ctx.font         = `900 34px 'Font Awesome 6 Free'`;
        ctx.textAlign    = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(item.unicode, iconX, cy);
        ctx.font      = `500 34px 'Plus Jakarta Sans'`;
        ctx.textAlign = "left";
        ctx.fillText(item.text, labelX, cy);
    });

    return await canvas.encode("png");
}

module.exports = {
    name: "iphonequotedchat2",
    aliases: ["iqc2", "ttchat"],
    category: "maker",
    permissions: { coin: 5 },

    code: async (ctx) => {
        try {
            let customName = null;
            let rawArgs    = ctx.args.join(" ");

            const namaMatch = rawArgs.match(/--nama\s+(\S+)/);
            if (namaMatch) {
                customName = namaMatch[1];
                rawArgs    = rawArgs.replace(/--nama\s+\S+/, "").trim();
            }

            const chatText = rawArgs || ctx.quoted?.body;

            if (!chatText) {
                return await ctx.reply(
                    `*✦ TikTok Chat*\n\n` +
                    `Cara pakai:\n` +
                    `— \`${ctx.used.prefix}tiktokchat <teks>\`\n` +
                    `— \`${ctx.used.prefix}tiktokchat --nama Rin <teks>\`\n` +
                    `— Reply pesan lalu \`${ctx.used.prefix}tiktokchat\`\n\n` +
                    `Contoh:\n` +
                    `— \`${ctx.used.prefix}tiktokchat Halo kak gimana kabar?\``
                );
            }

            await ctx.reply(tools.msg.info("Membuat TikTok chat..."));

            const username  = customName || ctx.sender.pushName || "User";
            const avatarUrl = await ctx.profilePictureUrl(ctx.sender.jid).catch(() =>
                "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/6b71d84a580f385bd7ee36402df5341ead4770a0/Image/artworks-gWLRE6HyPH3DgVMG-ZFFxtg-t500x500.jpg"
            );

            const buffer = await renderTiktokChat(username, chatText, avatarUrl);

            await ctx.reply({
                image: buffer,
                caption: `_${username}: ${chatText.substring(0, 80)}${chatText.length > 80 ? "..." : ""}_`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};