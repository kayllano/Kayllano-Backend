const axios = require("axios");
const FormData = require("form-data");

module.exports = {
    name: "bugilkan",
    aliases: ["deepnudes"],
    category: "nsfw",
    permissions: {
        premium: true
    },

    code: async (ctx) => {
        try {

            let buffer = null;

            if (ctx.quoted?.download) {
                buffer = await ctx.quoted.download();
            } else if (ctx.msg?.download) {
                buffer = await ctx.msg.download();
            }

            if (!buffer) {
                return await ctx.reply(
                    `${tools.msg.generateInstruction(
                        ["send", "reply"],
                        ["image"]
                    )}\n` +
                    tools.msg.generateCmdExample(
                        ctx.used,
                        ""
                    )
                );
            }

            await ctx.reply(
                tools.msg.info("Memproses gambar...")
            );

            const form = new FormData();

            form.append(
                "apikey",
                "kyujir"
            );

            form.append(
                "image",
                buffer,
                "image.jpg"
            );

            const { data } = await axios.post(
                "https://api.theresav.biz.id/nsfw/deepnudes",
                form,
                {
                    headers: form.getHeaders(),
                    responseType: "arraybuffer",
                    timeout: 30000
                }
            );

            await ctx.reply({
                image: Buffer.from(data),
                caption: `➛ ${formatter.bold("Done")}`
            });

        } catch (error) {
            console.error(error);
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};