const axios = require("axios");

module.exports = {
    name: "manstrubation",
    aliases: [],
    category: "nsfw",
    permissions: {
        premium: true
    },

    code: async (ctx) => {
        try {

            // =========================
            // JIKA BUTTON YES
            // =========================
            if (ctx.args[0] === "yes") {

                const api = await axios.get(
                    "https://api.theresav.biz.id/nsfw/manstrubation?apikey=5W9Z8",
                    {
                        responseType: "arraybuffer"
                    }
                );

                const buffer = Buffer.from(api.data);

                return await ctx.bot.sendMessage(
                    ctx.id,
                    {
                        image: buffer,
                        viewOnce: true
                    },
                    {
                        quoted: ctx.msg
                    }
                );
            }

            // =========================
            // JIKA BUTTON NO
            // =========================
            if (ctx.args[0] === "no") {

                return await ctx.reply(
                    "Eits jangan dulu yaa 🥺\nTunggu umur kamu cukup dulu baru boleh lihat beginian."
                );
            }

            // =========================
            // PERTANYAAN UMUR
            // =========================
            await ctx.reply({
                text:
`⚠️ Konten ini mengandung unsur 18+.

Apakah umur kamu sudah 18 tahun?`,

                footer: "Developer by Artoria",

                nativeFlow: [
                    {
                        text: "Ya, saya 18+",
                        id: `${ctx.used.prefix}ass yes`
                    },
                    {
                        text: "Belum",
                        id: `${ctx.used.prefix}ass no`
                    }
                ]
            });

        } catch (error) {

            console.error(error);

            return await ctx.reply(
                `Terjadi kesalahan: ${error.message}`
            );
        }
    }
};