module.exports = {
    name: "tobrut",
    category: "nsfw",
    permissions: {
        premium: true
    },

    code: async (ctx) => {
        try {
            const videos = [
                "https://files.catbox.moe/053cbw.mp4",
                "https://files.catbox.moe/fke4ht.mp4",
                "https://files.catbox.moe/mi8ouf.mp4",
                "https://files.catbox.moe/wtc2c9.mp4",
                "https://files.catbox.moe/j40xwe.mp4",
                "https://files.catbox.moe/l7shcw.mp4",
                "https://files.catbox.moe/18izfd.mp4",
                "https://files.catbox.moe/malsfc.mp4",
                "https://files.catbox.moe/xgfmr2.mp4",
                "https://files.catbox.moe/n317h3.mp4",
                "https://files.catbox.moe/lrffgg.mp4",
                "https://files.catbox.moe/z6pt9y.mp4",
                "https://files.catbox.moe/urdave.mp4",
                "https://files.catbox.moe/gcyk70.mp4",
                "https://files.catbox.moe/zm0p4a.mp4",
                "https://files.catbox.moe/k9pg17.mp4",
                "https://files.catbox.moe/l4i0gn.mp4",
                "https://files.catbox.moe/ap31lj.mp4",
                "https://files.catbox.moe/3a7beg.mp4",
                "https://files.catbox.moe/osgu8o.mp4",
                "https://files.catbox.moe/ysedtl.mp4",
                "https://files.catbox.moe/i8sewv.mp4",
                "https://files.catbox.moe/3i9kq4.mp4",
                "https://files.catbox.moe/nq4v6b.mp4",
                "https://files.catbox.moe/39yyc7.mp4",
                "https://files.soonex.biz.id/upload/f9edfd299a6b.mp4",
                "https://files.soonex.biz.id/upload/4eb2ab3e492c.mp4",
                "https://files.soonex.biz.id/upload/c58370d04a00.mp4",
                "https://files.soonex.biz.id/upload/fa6146882809.mp4",
                "https://files.soonex.biz.id/upload/27c3c85295e9.mp4",
                "https://files.soonex.biz.id/upload/9400448f7c2c.mp4",
                "https://files.soonex.biz.id/upload/217ed43801a8.mp4",
                "https://files.soonex.biz.id/upload/ffc02dfb4fae.mp4"
            ];

            const randomUrl = tools.cmd.getRandomElement(videos);

            await ctx.reply({
                video: { url: randomUrl },
                caption: `➛ ${formatter.bold("Random Video")}`,
                buttons: [{
                    text: "Ambil Lagi",
                    id: ctx.used.prefix + ctx.used.command
                }]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};
