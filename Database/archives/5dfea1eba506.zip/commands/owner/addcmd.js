const fs   = require("node:fs");
const path = require("node:path");

module.exports = {
    name: "addcmd",
    aliases: ["editcmd", "savecmd"],
    category: "owner",
    permissions: {
        owner: true
    },

    code: async (ctx) => {
        try {
            const fileName = ctx.args[0];
            const code     = ctx.quoted?.body || ctx.text?.replace(fileName || "", "").trim();

            if (!code || code.trim().length < 10)
                return await ctx.reply(tools.msg.info(
                    `Cara pakai:\n` +
                    `— Reply kode dengan \`${ctx.used.prefix}addcmd namafile\`\n` +
                    `— Atau: \`${ctx.used.prefix}addcmd namafile [kode]\``
                ));

            // Ekstrak category dari kode
            const categoryMatch = code.match(/category\s*:\s*["']([^"']+)["']/);

            if (!categoryMatch)
                return await ctx.reply(tools.msg.info("Tidak ditemukan `category` di kode."));

            const cmdCat  = categoryMatch[1].trim();

            // Nama file: dari argumen jika ada, fallback ke name di kode
            let cmdName = fileName;
            if (!cmdName) {
                const nameMatch = code.match(/name\s*:\s*["']([^"']+)["']/);
                if (!nameMatch) return await ctx.reply(tools.msg.info("Tidak ditemukan `name` di kode dan tidak ada argumen nama file."));
                cmdName = nameMatch[1].trim();
            }

            const cmdDir   = path.resolve(__dirname, "../../commands", cmdCat);
            const filePath = path.join(cmdDir, `${cmdName}.js`);

            if (!fs.existsSync(cmdDir)) fs.mkdirSync(cmdDir, { recursive: true });

            const isNew = !fs.existsSync(filePath);
            fs.writeFileSync(filePath, code, "utf-8");

            await ctx.reply(
                `➛ ${formatter.bold(isNew ? "Command ditambahkan!" : "Command diperbarui!")}\n\n` +
                `Name: ${formatter.inlineCode(cmdName)}\n` +
                `Category: ${formatter.inlineCode(cmdCat)}\n` +
                `Path: ${formatter.inlineCode(`commands/${cmdCat}/${cmdName}.js`)}\n\n` +
                `_Bot akan reload otomatis._`
            );

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};
