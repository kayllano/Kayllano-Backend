module.exports = {
    name: "addsewagroup",
    aliases: ["addsewa", "addsewagrup", "adg"],
    category: "owner",
    permissions: {
        owner: true
    },
    code: async (ctx) => {

        // =========================
        // AMBIL TARGET & DURASI
        // logic: kalau arg pertama adalah ID grup (angka panjang 15+ digit)
        // berarti user mau target grup lain
        // kalau bukan, anggap durasi untuk grup aktif sekarang
        // =========================
        let targetJid, daysAmount;

        const firstArg  = ctx.args[0];
        const isGroupId = firstArg && /^\d{10,}$/.test(firstArg.replace("@g.us", ""));

        if (isGroupId) {
            // target grup lain — bisa dipanggil dari grup manapun atau private
            targetJid  = firstArg.replace("@g.us", "") + "@g.us";
            daysAmount = parseInt(ctx.args[1], 10);
        } else if (ctx.isGroup()) {
            // tidak ada ID grup di arg — target grup aktif sekarang
            targetJid  = ctx.id;
            daysAmount = parseInt(ctx.args[0], 10);
        } else {
            targetJid = null;
        }

        if (!targetJid)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "1234567890 8 -s")}\n` +
                `${tools.msg.generateNotes(["Gunakan di grup untuk otomatis menyewakan grup tersebut.", "Atau sebutkan ID grup untuk menyewakan grup lain dari mana saja."])}\n` +
                tools.msg.generatesFlagInfo({
                    "-s": "Tetap diam dengan tidak menyiarkan ke owner grup"
                })
            );

        if (!await ctx.group(targetJid)) return await ctx.reply(tools.msg.info("Grup tidak valid atau bot tidak ada di grup tersebut!"));
        if (daysAmount && daysAmount <= 0) return await ctx.reply(tools.msg.info("Durasi sewa (dalam hari) harus diisi dan lebih dari 0!"));

        try {
            const flag = ctx.flag({
                silent: {
                    type: "boolean",
                    short: "s",
                    default: false
                }
            });
            const silent = flag?.silent;

            const group      = await ctx.group(targetJid);
            const groupOwner = await group.owner();

            const groupMentions = [{
                groupJid: `${group.id}@g.us`,
                groupSubject: await group.name()
            }];

            const targetDb  = ctx.getDb("groups", targetJid);
            const isCurrent = ctx.isGroup() && targetJid === ctx.id;

            if (daysAmount && daysAmount > 0) {
                const expirationDate    = Date.now() + (daysAmount * 24 * 60 * 60 * 1000);
                targetDb.sewa           = true;
                targetDb.sewaExpiration = expirationDate;
                targetDb.save();

                if (!silent && groupOwner && !config.system.restrict)
                    await ctx.sendMessage(groupOwner, {
                        text: tools.msg.info(`Bot berhasil disewakan ke grup @${group.id}@g.us selama ${daysAmount} hari!`),
                        contextInfo: { groupMentions }
                    });

                await ctx.reply(tools.msg.info(`Berhasil menyewakan bot ke grup ${isCurrent ? "ini" : `@${group.id}@g.us`} selama ${daysAmount} hari!`));
            } else {
                targetDb.sewa = true;
                delete targetDb.sewaExpiration;
                targetDb.save();

                if (!silent && groupOwner && !config.system.restrict)
                    await ctx.sendMessage(groupOwner, {
                        text: tools.msg.info(`Bot berhasil disewakan ke grup @${group.id}@g.us selamanya!`),
                        contextInfo: { groupMentions }
                    });

                await ctx.reply(tools.msg.info(`Berhasil menyewakan bot ke grup ${isCurrent ? "ini" : `@${group.id}@g.us`} selamanya!`));
            }
        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};