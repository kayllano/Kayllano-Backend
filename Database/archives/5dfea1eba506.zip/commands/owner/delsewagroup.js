module.exports = {
    name: "delsewagroup",
    aliases: ["delsewa", "delsewagrup", "dsg"],
    category: "owner",
    permissions: {
        owner: true
    },
    code: async (ctx) => {

        // =========================
        // AMBIL TARGET
        // logic sama seperti addsewagroup —
        // kalau arg pertama ID grup (angka 10+ digit), target grup itu
        // kalau bukan, target grup aktif sekarang
        // =========================
        let targetJid;

        const firstArg  = ctx.args[0];
        const isGroupId = firstArg && /^\d{10,}$/.test(firstArg.replace("@g.us", ""));

        if (isGroupId) {
            targetJid = firstArg.replace("@g.us", "") + "@g.us";
        } else if (ctx.isGroup()) {
            targetJid = ctx.id;
        } else {
            targetJid = null;
        }

        if (!targetJid)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                `${tools.msg.generateCmdExample(ctx.used, "1234567890 -s")}\n` +
                `${tools.msg.generateNotes(["Gunakan di grup untuk otomatis menghapus sewa grup tersebut.", "Atau sebutkan ID grup untuk menghapus sewa grup lain dari mana saja."])}\n` +
                tools.msg.generatesFlagInfo({
                    "-s": "Tetap diam dengan tidak menyiarkan ke owner grup"
                })
            );

        if (!await ctx.group(targetJid)) return await ctx.reply(tools.msg.info("Grup tidak valid atau bot tidak ada di grup tersebut!"));

        try {
            const targetDb = ctx.getDb("groups", targetJid);
            delete targetDb.sewa;
            delete targetDb.sewaExpiration;
            targetDb.save();

            const flag = ctx.flag({
                silent: {
                    type: "boolean",
                    short: "s",
                    default: false
                }
            });
            const silent     = flag?.silent;
            const group      = await ctx.group(targetJid);
            const groupOwner = await group.owner();
            const isCurrent  = ctx.isGroup() && targetJid === ctx.id;

            if (!silent && groupOwner && !config.system.restrict) {
                const groupMentions = [{
                    groupJid: `${group.id}@g.us`,
                    groupSubject: await group.name()
                }];
                await ctx.sendMessage(groupOwner, {
                    text: tools.msg.info(`Sewa bot untuk grup @${group.id}@g.us telah dihentikan oleh owner!`),
                    contextInfo: { groupMentions }
                });
            }

            await ctx.reply(tools.msg.info(`Berhasil menghapus sewa bot untuk grup ${isCurrent ? "ini" : `@${group.id}@g.us`}!`));
        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};