module.exports = {
    name: "listsewagroup",
    aliases: ["listsewa"],
    category: "owner",
    permissions: {
        owner: true
    },
    code: async (ctx) => {
        try {
            const groups      = ctx.db.groups.getMany(group => group.sewa);
            const sewaGroups  = [];

            for (const group of groups)
                sewaGroups.push({
                    jid: group.jid,
                    expiration: group.sewaExpiration
                });

            if (!sewaGroups.length)
                return await ctx.reply(tools.msg.info(config.msg.notFound));

            let resultText     = "";
            let groupMentions  = [];

            for (const group of sewaGroups) {
                const groupJid     = group.jid;
                const groupInfo    = await ctx.group(groupJid);
                const groupSubject = await groupInfo.name();

                groupMentions.push({
                    groupJid,
                    groupSubject
                });

                if (group.expiration) {
                    const timeDiff = group.expiration - Date.now();
                    const daysLeft = tools.msg.convertMsToDuration(timeDiff, ["hari", "jam"]);
                    resultText += `› @${groupJid} (${daysLeft} tersisa)\n`;
                } else {
                    resultText += `› @${groupJid} (Permanen)\n`;
                }
            }

            await ctx.reply({
                text: `*Daftar Grup Sewa*\n\n${resultText.trim()}`,
                contextInfo: { groupMentions }
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};