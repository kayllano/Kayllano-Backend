module.exports = {
    name: "nekoai",
    aliases: ["neko-ai", "toggleneko"],
    category: "owner",
    permissions: {
        owner: true
    },

    code: async (ctx) => {
        try {

            const sub = ctx.args[0]?.toLowerCase();

            // =========================
            // TOGGLE DI GRUP
            // .nekoai grup on/off
            // =========================
            if (sub === "grup" || sub === "group") {
                if (!ctx.isGroup())
                    return await ctx.reply(tools.msg.info("Command ini harus dijalankan di dalam grup!"));

                const groupDb        = ctx.db.group;
                groupDb.option       = groupDb.option || {};
                const current        = groupDb.option?.neko || false;
                groupDb.option.neko  = !current;
                groupDb.save();

                return await ctx.reply(tools.msg.info(
                    `Neko AI di grup ini ${groupDb.option.neko ? "diaktifkan" : "dimatikan"}!\n` +
                    `${groupDb.option.neko ? "Sekarang user bisa memanggil Neko di chat grup nyan~" : "Neko sudah tidak akan merespon di grup ini."}`
                ));
            }

            // =========================
            // TOGGLE DI PRIVATE
            // .nekoai private on/off
            // =========================
            if (sub === "private" || sub === "pm") {
                const botDb  = ctx.db.bot;
                const current = botDb?.neko || false;
                botDb.neko   = !current;
                botDb.save();

                return await ctx.reply(tools.msg.info(
                    `Neko AI di private chat ${botDb.neko ? "diaktifkan" : "dimatikan"}!\n` +
                    `${botDb.neko ? "Sekarang user bisa memanggil Neko di PM nyan~" : "Neko sudah tidak akan merespon di PM."}`
                ));
            }

            // =========================
            // INFO / PANDUAN
            // =========================
            const groupDb  = ctx.isGroup() ? ctx.db.group : null;
            const botDb    = ctx.db.bot;
            const nekoGrup = groupDb?.option?.neko || false;
            const nekoPm   = botDb?.neko || false;

            await ctx.reply({
                text: `*Neko AI Toggle*\n\n` +
                    `› Status Grup: ${ctx.isGroup() ? (nekoGrup ? "Aktif" : "Nonaktif") : "N/A (bukan di grup)"}\n` +
                    `› Status PM: ${nekoPm ? "Aktif" : "Nonaktif"}\n\n` +
                    `*— Cara Pakai*\n` +
                    `› Toggle di grup: .nekoai grup\n` +
                    `› Toggle di PM: .nekoai private\n\n` +
                    `*— Cara User Panggil Neko*\n` +
                    `› "neko jadiin stiker" + reply gambar\n` +
                    `› "neko cariin info black hole"\n` +
                    `› "neko buatin musik jazz chill"\n` +
                    `› "neko download [url tiktok/youtube]"\n` +
                    `› "neko halo" — ngobrol biasa`,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};