module.exports = {
    name: "artinama",
    aliases: ["namaarti"],
    category: "primbon",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const name = ctx.args.join(" ");
            if (!name) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan nama yang ingin dicari artinya!\nContoh: .artinama halfy"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/primbon/artinama",
                {
                    params: { name },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result) {
                return await ctx.reply({
                    text: formatter.monospace("Gagal mengambil data. Coba lagi nanti."),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const { nama, arti, catatan } = res.result;

            const caption = `*Arti Nama*\n\n`
                + `› Nama    : ${nama}\n\n`
                + `› Arti    :\n${arti}\n\n`
                + `› Catatan :\n${catatan}`;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};