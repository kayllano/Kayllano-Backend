module.exports = {
    name: "livefunfact",
    aliases: ["biodatahidup", "faktahidup"],
    category: "primbon",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const input = ctx.args[0];
            if (!input) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan tanggal lahir kamu!\nFormat: YYYY-MM-DD\nContoh: .livefunfact 2005-12-28"),
                    footer: config.msg.footer
                });
            }

            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(input)) {
                return await ctx.reply({
                    text: formatter.monospace("Format tanggal salah!\nGunakan format: YYYY-MM-DD\nContoh: 2005-12-28"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/fun/livefunfact",
                {
                    params: { birthdate: input },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result) {
                return await ctx.reply({
                    text: formatter.monospace("Gagal mengambil data. Coba lagi nanti."),
                    footer: config.msg.footer
                });
            }

            const d = res.result;
            const b = d.basic_info;
            const r = d.respiratory;
            const c = d.cardiovascular;
            const n = d.neurological;
            const im = d.immune_system;
            const ce = d.cellular_activity;
            const m = d.metabolic_summary;
            const lc = d.life_comparison;
            const af = d.amazing_facts;

            const fmt = (n) => Number(n).toLocaleString("id-ID");

            // =========================
            // FORMAT HASIL
            // =========================
            const caption =
                `*Live Fun Fact — Tubuhmu Selama Ini*\n\n` +

                `*— Info Dasar*\n` +
                `› Tanggal Lahir : ${d.birth_date}\n` +
                `› Usia          : ${b.age_in_years} tahun\n` +
                `› Hari Hidup    : ${fmt(b.age_in_days)} hari\n` +
                `› Jam Hidup     : ${fmt(b.age_in_hours)} jam\n` +
                `› Detik Hidup   : ${fmt(b.age_in_seconds)} detik\n\n` +

                `*— Jantung & Darah*\n` +
                `› Detak Jantung : ${fmt(c.heart_beats_total)} kali\n` +
                `› Darah Dipompa : ${fmt(c.blood_pumped_l)} liter\n` +
                `› Jarak Darah   : ${fmt(c.blood_distance_km)} km\n` +
                `› Sel Darah Merah Diproduksi: ${fmt(c.red_blood_cells_produced)}\n\n` +

                `*— Pernapasan*\n` +
                `› Total Napas   : ${fmt(r.total_breaths)} kali\n` +
                `› Volume Udara  : ${fmt(r.total_air_volume_l)} liter\n` +
                `› O₂ Dikonsumsi : ${fmt(r.oxygen_consumed_l)} liter\n` +
                `› CO₂ Dihasilkan: ${fmt(r.co2_produced_l)} liter\n\n` +

                `*— Otak & Saraf*\n` +
                `› Energi Otak   : ${fmt(n.brain_energy_consumed_kj)} kJ\n` +
                `› Konsolidasi Memori: ${fmt(n.memory_consolidations)} kali\n` +
                `› Proses Kognitif: ${fmt(n.cognitive_processes)}\n\n` +

                `*— Sistem Imun*\n` +
                `› Sel Darah Putih: ${fmt(im.white_cells_produced)}\n` +
                `› Patogen Dieliminasi: ${fmt(im.pathogens_eliminated)}\n` +
                `› Respons Imun  : ${fmt(im.immune_responses)} kali\n\n` +

                `*— Metabolisme*\n` +
                `› Kalori Terbakar: ${fmt(m.total_calories_burned)} kkal\n` +
                `› Air Diproses  : ${fmt(m.water_processed_l)} liter\n` +
                `› Energi Dihasilkan: ${fmt(m.energy_produced_kj)} kJ\n\n` +

                `*— Fakta Menakjubkan*\n` +
                `› Total Sel Tubuh: ${fmt(af.total_body_cells)}\n` +
                `› Panjang DNA   : ${fmt(af.total_dna_length_km)} km\n` +
                `› Koneksi Neuron: ${fmt(af.neuron_connections)}\n` +
                `› Panjang Pembuluh Darah: ${fmt(af.blood_vessel_length_km)} km\n\n` +

                `*— Perbandingan Hidup*\n` +
                `› Harapan Hidup Dunia : ${lc.world_life_expectancy} tahun\n` +
                `› Sudah Dilalui       : ${lc.percentage_of_life_lived}%\n` +
                `› Sisa Estimasi       : ${lc.estimated_remaining_years} tahun\n` +
                `› Status Biologis     : ${lc.biological_systems_optimal}`;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};