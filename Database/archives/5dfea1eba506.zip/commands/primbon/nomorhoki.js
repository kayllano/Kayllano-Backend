module.exports = {
    name: "nomorhoki",
    aliases: ["hokinom", "ceknom"],
    category: "primbon",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const phone = ctx.args[0];
            if (!phone) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan nomor HP yang ingin dicek!\nContoh: .nomorhoki 6285706606594"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/primbon/nomerhoki",
                {
                    params: { phone_number: phone },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result) {
                return await ctx.reply({
                    text: formatter.monospace("Gagal mengambil data. Coba lagi nanti."),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const { nomor, angka_bagua_shuzi, energi_positif, energi_negatif, analisis } = res.result;
            const status = analisis.status ? "HOKI ✓" : "TIDAK HOKI ✗";

            const caption = `*Cek Nomor Hoki*\n\n`
                + `› Nomor       : ${nomor}\n`
                + `› Status      : ${status}\n\n`
                + `*— Bagua Shuzi*\n`
                + `› Nilai       : ${angka_bagua_shuzi.value}%\n\n`
                + `*— Energi Positif*\n`
                + `› Total       : ${energi_positif.total}%\n`
                + `› Kekayaan    : ${energi_positif.details.kekayaan}\n`
                + `› Kesehatan   : ${energi_positif.details.kesehatan}\n`
                + `› Cinta       : ${energi_positif.details.cinta}\n`
                + `› Kestabilan  : ${energi_positif.details.kestabilan}\n\n`
                + `*— Energi Negatif*\n`
                + `› Total       : ${energi_negatif.total}%\n`
                + `› Perselisihan: ${energi_negatif.details.perselisihan}\n`
                + `› Kehilangan  : ${energi_negatif.details.kehilangan}\n`
                + `› Malapetaka  : ${energi_negatif.details.malapetaka}\n`
                + `› Kehancuran  : ${energi_negatif.details.kehancuran}`;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};