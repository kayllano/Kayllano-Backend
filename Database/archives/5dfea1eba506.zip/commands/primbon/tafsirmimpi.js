module.exports = {
    name: "tafsirmimpi",
    aliases: ["mimpi", "artimimpi"],
    category: "primbon",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const mimpi = ctx.args.join(" ");
            if (!mimpi) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan kata kunci mimpi yang ingin ditafsirkan!\nContoh: .tafsirmimpi hantu"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/primbon/tafsirmimpi",
                {
                    params: { mimpi },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result || !res.result.hasil?.length) {
                return await ctx.reply({
                    text: formatter.monospace(`Tafsir mimpi untuk "${mimpi}" tidak ditemukan.`),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const { keyword, hasil, total, solusi } = res.result;

            const listHasil = hasil.map((item, i) =>
                `${i + 1}. *${item.mimpi}*\n    › ${item.tafsir}`
            ).join("\n\n");

            // potong solusi biar ga terlalu panjang
            const solusiSingkat = solusi.trim().slice(0, 200) + "...";

            const caption = `*Tafsir Mimpi*\n\n`
                + `› Keyword : ${keyword}\n`
                + `› Total   : ${total} hasil\n\n`
                + `*— Hasil Tafsir*\n`
                + `${listHasil}\n\n`
                + `*— Solusi*\n`
                + `${solusiSingkat}`;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};