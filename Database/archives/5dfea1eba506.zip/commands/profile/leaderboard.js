module.exports = {
    name: "leaderboard",
    aliases: ["lb", "peringkat"],
    category: "profile",
    code: async (ctx) => {
        try {
            const users     = ctx.db.users.getAll();
            const senderLid = ctx.sender.lid;
            const senderId  = ctx.getId(senderLid);

            const leaderboardData = users
                .map(u => ({
                    jid:      u.jid,
                    pushName: u.pushName,
                    level:    u.level || 0,
                    winGame:  u.winGame || 0
                }))
                .sort((a, b) => b.winGame - a.winGame || b.level - a.level);

            const userRank = leaderboardData.findIndex(
                u => tools.cmd.areJidsSameUser(u.jid, senderLid)
            ) + 1;

            const topUsers = leaderboardData.slice(0, 10);

            const medals = ["🥇", "🥈", "🥉"];

            let text = `\`Leaderboard\` 🏆\n`;
            text += `───────────────\n`;

            topUsers.forEach((user, i) => {
                const isSelf    = tools.cmd.areJidsSameUser(user.jid, senderLid);
                const medal     = medals[i] || `${i + 1}.`;
                const name      = isSelf
                    ? `@${senderId}`
                    : (user.pushName || ctx.getId(user.jid));
                const marker    = isSelf ? " ◀" : "";
                text += `${medal} *${name}*${marker}\n`;
                text += `   Win: ${user.winGame}  ·  Lv.${user.level}\n`;
            });

            // Kalau user di luar top 10
            if (userRank > 10) {
                const userStats = leaderboardData[userRank - 1];
                text += `───────────────\n`;
                text += `📍 Posisi kamu: #${userRank}\n`;
                text += `   Win: ${userStats.winGame}  ·  Lv.${userStats.level}\n`;
            }

            text += `───────────────\n`;
            text += `_Total pemain: ${leaderboardData.length}_`;

            await ctx.reply({
                text,
                mentions: [senderLid],
                nativeFlow: [
                    {
                        text: "Profil Saya",
                        id: `${ctx.used.prefix}profile`
                    },
                    {
                        text: "Main Game",
                        id: `${ctx.used.prefix}menu game`
                    }
                ]
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};