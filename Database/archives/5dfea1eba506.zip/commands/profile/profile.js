module.exports = {
    name: "profile",
    aliases: ["me", "prof", "profil"],
    category: "profile",
    code: async (ctx) => {
        try {
            const users     = ctx.db.users.getAll();
            const userDb    = ctx.db.user;
            const senderLid = ctx.sender.lid;

            const leaderboardData = users
                .map(u => ({
                    jid:     u.jid,
                    level:   u.level   || 0,
                    winGame: u.winGame || 0
                }))
                .sort((a, b) => b.winGame - a.winGame || b.level - a.level);

            const rank = leaderboardData.findIndex(
                u => tools.cmd.areJidsSameUser(u.jid, senderLid)
            ) + 1;

            const statusText =
                ctx.sender.isOwner()
                    ? "✦ Owner"
                    : userDb?.premium
                        ? `★ Premium · ${
                            userDb?.premiumExpiration
                                ? `${tools.msg.convertMsToDuration(Date.now() - userDb.premiumExpiration, ["hari", "jam"])} lagi`
                                : "Selamanya"
                          }`
                        : "Freemium";

            const pp = await ctx.profilePictureUrl(ctx.sender.jid).catch(() => null);

            await new AIRich(ctx.core)
                .addProduct([{
                    title:      ctx.sender.pushName || "Unknown",
                    brand:      statusText,
                    price:      `Lv.${userDb?.level || 0}`,
                    sale_price: `#${rank} Peringkat`,
                    url:        `https://chat.whatsapp.com/DtadVBXdxDc1U8vtAcrRcU?s=cl&p=a&mlu=0&amv=2`,
                    image:      pp || "https://x.xcute.workers.dev/f/images/af479b085819.jpg",
                    icon:       pp || "https://x.xcute.workers.dev/f/images/af479b085819.jpg"
                }])
                .addText(
                    `\`User Info\` 👤\n` +
                    `*› Status:* ${statusText}\n` +
                    `*› Level:* Lv.${userDb?.level || 0}  ·  ${userDb?.xp || 0}/100 xp\n` +
                    `*› Coin:* ${ctx.sender.isOwner() || userDb?.premium ? "Unlimited" : (userDb?.coin || 0)}\n` +
                    `*› Menang:* ${userDb?.winGame || 0} kali\n` +
                    `*› Peringkat:* #${rank} dari ${leaderboardData.length} pengguna`
                )
                .addSuggest([
                    `${ctx.used.prefix}leaderboard`,
                    `${ctx.used.prefix}daily`,
                    `${ctx.used.prefix}coin`
                ])
                .send(ctx._msg.key.remoteJid, { quoted: ctx._msg });

        } catch (error) {
            await tools.cmd.handleError(ctx, error);
        }
    }
};