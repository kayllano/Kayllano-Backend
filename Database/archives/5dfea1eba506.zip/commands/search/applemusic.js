module.exports = {
    name: "applemusic",
    aliases: ["amsearch", "cariapplemusic"],
    category: "search",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const query = ctx.args.join(" ");
            if (!query) {
                return await ctx.reply({
                    text: `*Apple Music Search*\n\n` +
                        `› Format : .applemusic [judul lagu/artis]\n` +
                        `› Contoh : .applemusic goodkid cicada`,
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.theresav.biz.id/search/applemusic",
                {
                    params: {
                        q: query,
                        apikey: "artoriaox"
                    },
                    timeout: 30000
                }
            );

            if (!res.status || !res.results?.length) {
                return await ctx.reply(tools.msg.info(`Hasil pencarian untuk "${query}" tidak ditemukan.`));
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const results = res.results.slice(0, 6);

            const list = results.map((item, i) =>
                [
                    `${i + 1}. *${item.title}*`,
                    `   › ${item.artist}`,
                    `   › ${item.link}`
                ].join("\n")
            ).join("\n\n");

            const caption = `*Apple Music Search*\n\n` +
                `› Query : ${query}\n` +
                `› Total : ${res.total} hasil\n\n` +
                list;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                image: { url: results[0].image },
                caption: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};