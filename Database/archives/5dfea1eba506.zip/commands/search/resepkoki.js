module.exports = {
    name: "resep",
    aliases: ["cariresep", "resepkoki"],
    category: "search",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const query = ctx.args.join(" ");
            if (!query) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan nama resep yang ingin dicari!\nContoh: .resep ayam bakar"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/search/resep",
                {
                    params: { q: query },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.length) {
                return await ctx.reply({
                    text: formatter.monospace(`Resep untuk "${query}" tidak ditemukan.`),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const results = res.result.slice(0, 5);

            const list = results.map((item, i) =>
                [
                    `${i + 1}. *${item.judul}*`,
                    `   › Waktu  : ${item.waktu_masak}`,
                    `   › Hasil  : ${item.hasil}`,
                    `   › Level  : ${item.tingkat_kesulitan}`,
                    `   › Link   : ${item.link}`
                ].join("\n")
            ).join("\n\n");

            const caption = `*Resep Koki*\n\n`
                + `› Query : ${query}\n`
                + `› Total : ${res.result.length} resep\n\n`
                + list;

            // =========================
            // KIRIM HASIL + THUMBNAIL RESEP PERTAMA
            // =========================
            const { data: imgData } = await axios.get(results[0].thumbnail, {
                responseType: "arraybuffer",
                timeout: 30000
            });

            await ctx.reply({
                image: Buffer.from(imgData),
                caption: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};