module.exports = {
    name: "wikipedia",
    aliases: ["wiki", "wikicari"],
    category: "search",
    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const query = ctx.args.join(" ");
            if (!query) {
                return await ctx.reply({
                    text: formatter.monospace("Masukkan kata kunci yang ingin dicari!\nContoh: .wikipedia Earth"),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api.nexray.eu.cc/search/wikipedia",
                {
                    params: { q: query },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.length) {
                return await ctx.reply({
                    text: formatter.monospace(`Artikel Wikipedia untuk "${query}" tidak ditemukan.`),
                    footer: config.msg.footer
                });
            }

            // =========================
            // FORMAT HASIL
            // =========================
            const results = res.result.slice(0, 5);

            const list = results.map((item, i) => {
                const snippet = item.snippet.replace(/<[^>]*>/g, "").trim();
                const link = `https://en.wikipedia.org/?curid=${item.pageid}`;
                return [
                    `${i + 1}. *${item.title}*`,
                    `   › ${snippet}...`,
                    `   › Link : ${link}`
                ].join("\n");
            }).join("\n\n");

            const caption = `*Wikipedia Search*\n\n`
                + `› Query : ${query}\n`
                + `› Total : ${res.result.length} artikel\n\n`
                + list;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text: caption,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};