module.exports = {
    name: "ghstalk",
    aliases: ["githubstalk", "stalkgithub"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "mirai-kanade")
            );

        try {
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/stalker/github",
                {
                    params: {
                        username: input
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("User Github tidak ditemukan.");

            const result = data.result;

            await ctx.reply({
                image: {
                    url: result.profile_pic
                },
                caption:
                    `➛ ${formatter.bold("Username")}: ${result.username}\n` +
                    `➛ ${formatter.bold("Nickname")}: ${result.nickname || "-"}\n` +
                    `➛ ${formatter.bold("Bio")}: ${result.bio || "-"}\n` +
                    `➛ ${formatter.bold("ID")}: ${result.id}\n` +
                    `➛ ${formatter.bold("Type")}: ${result.type}\n` +
                    `➛ ${formatter.bold("Admin")}: ${result.admin ? "Yes" : "No"}\n` +
                    `➛ ${formatter.bold("Company")}: ${result.company || "-"}\n` +
                    `➛ ${formatter.bold("Blog")}: ${result.blog || "-"}\n` +
                    `➛ ${formatter.bold("Location")}: ${result.location || "-"}\n` +
                    `➛ ${formatter.bold("Email")}: ${result.email || "-"}\n` +
                    `➛ ${formatter.bold("Public Repo")}: ${result.public_repo}\n` +
                    `➛ ${formatter.bold("Public Gists")}: ${result.public_gists}\n` +
                    `➛ ${formatter.bold("Followers")}: ${result.followers}\n` +
                    `➛ ${formatter.bold("Following")}: ${result.following}\n` +
                    `➛ ${formatter.bold("Created At")}: ${result.created_at}\n` +
                    `➛ ${formatter.bold("Updated At")}: ${result.updated_at}\n` +
                    `➛ ${formatter.bold("URL")}: ${result.url}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};