module.exports = {
    name: "igstalk",
    aliases: ["iginfo", "stalkg"],
    category: "stalker",
    permissions: {
        coin: 5
    },

    code: async (ctx) => {
        try {
            const username = ctx.args[0]?.replace("@", "");

            if (!username) {
                return await ctx.reply(
                    `*✦ Instagram Stalker*\n\n` +
                    `Cara pakai:\n` +
                    `— \`${ctx.used.prefix}igstalk <username>\`\n\n` +
                    `Contoh:\n` +
                    `— \`${ctx.used.prefix}igstalk kersenify666\``
                );
            }

            await ctx.reply(
                tools.msg.info(
                    `Mengambil info akun @${username}...`
                )
            );

            const { data } = await axios.get(
                "https://api-nanzz.my.id/docs/api/stalker/ig-stalk.php",
                {
                    params: { username },
                    timeout: 30000
                }
            );

            if (!data?.status || !data?.result) {
                return await ctx.reply(
                    tools.msg.info(
                        "Gagal mengambil data. Pastikan username Instagram valid."
                    )
                );
            }

            const r = data.result;
            const s = r.stats;

            const caption =
                `*Instagram Stalker*\n` +
                `${"─".repeat(15)}\n` +
                `› Username   : @${r.username}\n` +
                `› Nama       : ${r.full_name || "-"}\n` +
                `› Bio        : ${r.bio ? r.bio.replace(/\n/g, " ") : "-"}\n` +
                `› Followers  : ${s.followers.toLocaleString("id-ID")}\n` +
                `› Following  : ${s.following.toLocaleString("id-ID")}\n` +
                `› Posts      : ${s.posts.toLocaleString("id-ID")}\n` +
                `› Private    : ${r.is_private ? "Ya" : "Tidak"}\n` +
                `› Verified   : ${r.is_verified ? "Ya" : "Tidak"}\n` +
                `› URL        : ${r.external_url || "-"}\n` +
                `${"─".repeat(15)}`;

            await ctx.reply({
                image: { url: r.profile_pic },
                caption
            });

        } catch (error) {
            await tools.cmd.handleError(
                ctx,
                error
            );
        }
    }
};
