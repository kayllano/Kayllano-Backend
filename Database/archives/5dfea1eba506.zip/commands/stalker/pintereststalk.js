module.exports = {
    name: "pinstalk",
    aliases: ["pintereststalk", "stalkpin"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "halfilofi")
            );

        try {
            const { data } = await axios.get(
                "https://api.theresav.biz.id/stalk/pinterest",
                {
                    params: {
                        username: input,
                        apikey: "artoriaox"
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("User Pinterest tidak ditemukan.");

            const r      = data.result;
            const stats  = r.stats;
            const social = r.social_links;

            const verified = r.is_verified && Object.keys(r.is_verified).length > 0 ? "✅ Ya" : "❌ Tidak";
            const partner  = r.is_partner ? "✅ Ya" : "❌ Tidak";

            // Kumpulkan social links yang tersedia
            const socialList = Object.entries(social)
                .filter(([, val]) => val)
                .map(([platform, url]) => `  • ${platform}: ${url}`)
                .join("\n");

            await ctx.reply({
                image: {
                    url: r.image.original || r.image.large
                },
                caption:
                    `➛ ${formatter.bold("Username")}: @${r.username}\n` +
                    `➛ ${formatter.bold("Nama")}: ${r.full_name || "-"}\n` +
                    `➛ ${formatter.bold("Bio")}: ${r.bio || "-"}\n` +
                    `➛ ${formatter.bold("Lokasi")}: ${r.location || "-"}\n` +
                    `➛ ${formatter.bold("Negara")}: ${r.country || "-"}\n` +
                    `➛ ${formatter.bold("Website")}: ${r.website || "-"}\n` +
                    `➛ ${formatter.bold("Pins")}: ${stats.pins.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Boards")}: ${stats.boards.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Followers")}: ${stats.followers.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Following")}: ${stats.following.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Likes")}: ${stats.likes.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Saves")}: ${stats.saves.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Verified")}: ${verified}\n` +
                    `➛ ${formatter.bold("Partner")}: ${partner}\n` +
                    (socialList ? `➛ ${formatter.bold("Sosial Media")}:\n${socialList}\n` : "") +
                    `➛ ${formatter.bold("Profil")}: ${r.profile_url}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};