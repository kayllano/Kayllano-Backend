module.exports = {
    name: "rblxstalk",
    aliases: ["robloxstalk", "stalkroblox"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "builderman")
            );

        try {
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/stalker/roblox",
                {
                    params: {
                        username: input
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("User Roblox tidak ditemukan.");

            const result = data.result;

            const basic = result.basic;
            const social = result.social;
            const avatar = result.avatar;

            let groups = "-";

            if (result.groups?.list?.data?.length) {
                groups = result.groups.list.data
                    .slice(0, 5)
                    .map(v =>
                        `• ${v.group.name} (${v.role.name})`
                    )
                    .join("\n");
            }

            let badges = "-";

            if (result.achievements?.robloxBadges?.length) {
                badges = result.achievements.robloxBadges
                    .slice(0, 5)
                    .map(v => `• ${v.name}`)
                    .join("\n");
            }

            await ctx.reply({
                image: {
                    url: avatar.fullBody.data[0].imageUrl
                },
                caption:
                    `➛ ${formatter.bold("Username")}: ${basic.name}\n` +
                    `➛ ${formatter.bold("Display Name")}: ${basic.displayName}\n` +
                    `➛ ${formatter.bold("User ID")}: ${basic.id}\n` +
                    `➛ ${formatter.bold("Verified")}: ${basic.hasVerifiedBadge ? "Yes" : "No"}\n` +
                    `➛ ${formatter.bold("Banned")}: ${basic.isBanned ? "Yes" : "No"}\n` +
                    `➛ ${formatter.bold("Created")}: ${basic.created}\n` +
                    `➛ ${formatter.bold("Description")}: ${basic.description || "-"}\n\n` +

                    `➛ ${formatter.bold("Followers")}: ${social.followers.count}\n` +
                    `➛ ${formatter.bold("Following")}: ${social.following.count}\n` +
                    `➛ ${formatter.bold("Friends")}: ${social.friends.count}\n\n` +

                    `➛ ${formatter.bold("Presence")}: ${result.presence.userPresences[0].lastLocation || "-"}\n\n` +

                    `➛ ${formatter.bold("Groups")}:\n${groups}\n\n` +

                    `➛ ${formatter.bold("Badges")}:\n${badges}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};