module.exports = {
    name: "threadstalk",
    aliases: ["stalkthreads", "threadsstalk"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "zuck")
            );

        try {
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/stalker/threads",
                {
                    params: {
                        username: input
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("User Threads tidak ditemukan.");

            const result = data.result;

            let links = "-";

            if (result.links?.length) {
                links = result.links.join("\n");
            }

            await ctx.reply({
                image: {
                    url: result.hd_profile_picture || result.profile_picture
                },
                caption:
                    `➛ ${formatter.bold("Username")}: ${result.username}\n` +
                    `➛ ${formatter.bold("Nama")}: ${result.name || "-"}\n` +
                    `➛ ${formatter.bold("Bio")}: ${result.bio || "-"}\n` +
                    `➛ ${formatter.bold("Followers")}: ${result.followers}\n` +
                    `➛ ${formatter.bold("Verified")}: ${result.is_verified ? "Yes" : "No"}\n` +
                    `➛ ${formatter.bold("ID")}: ${result.id}\n` +
                    `➛ ${formatter.bold("Links")}: ${links}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};