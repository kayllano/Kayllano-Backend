module.exports = {
    name: "ttstalk",
    aliases: ["tiktokstalk", "stalktt"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "halfy")
            );

        try {
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/stalker/tiktok",
                {
                    params: {
                        username: input
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("User TikTok tidak ditemukan.");

            const result = data.result;

            await ctx.reply({
                image: {
                    url: result.avatar
                },
                caption:
                    `➛ ${formatter.bold("Username")}: ${result.username}\n` +
                    `➛ ${formatter.bold("Nama")}: ${result.name || "-"}\n` +
                    `➛ ${formatter.bold("Bio")}: ${result.bio || "-"}\n` +
                    `➛ ${formatter.bold("Followers")}: ${result.stats.followers}\n` +
                    `➛ ${formatter.bold("Following")}: ${result.stats.following}\n` +
                    `➛ ${formatter.bold("Likes")}: ${result.stats.likes}\n` +
                    `➛ ${formatter.bold("Videos")}: ${result.stats.videos}\n` +
                    `➛ ${formatter.bold("Verified")}: ${result.verified}\n` +
                    `➛ ${formatter.bold("Private")}: ${result.private}\n` +
                    `➛ ${formatter.bold("Region")}: ${result.region}\n` +
                    `➛ ${formatter.bold("Seller")}: ${result.seller}\n` +
                    `➛ ${formatter.bold("Organization")}: ${result.organization}\n` +
                    `➛ ${formatter.bold("Link")}: ${result.link}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};