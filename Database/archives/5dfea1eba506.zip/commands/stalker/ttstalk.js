module.exports = {
    name: "ttstalk",
    aliases: ["tiktokstalk", "stalktt"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "halfy")
            );

        try {
            const { data } = await axios.get(
                "https://api.theresav.biz.id/stalk/tiktok",
                {
                    params: {
                        username: input,
                        apikey: "artoriaox"
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result?.status || !data.result?.profile)
                return await ctx.reply("User TikTok tidak ditemukan.");

            const profile = data.result.profile;
            const stats   = data.result.stats;

            const verified = profile.verified      ? "✅ Ya" : "❌ Tidak";
            const private_ = profile.privateAccount ? "🔒 Ya" : "🌐 Tidak";

            await ctx.reply({
                image: {
                    url: profile.avatar.large
                },
                caption:
                    `➛ ${formatter.bold("Username")}: @${profile.username}\n` +
                    `➛ ${formatter.bold("Nama")}: ${profile.nickname || "-"}\n` +
                    `➛ ${formatter.bold("Bio")}: ${profile.bio || "-"}\n` +
                    `➛ ${formatter.bold("Bahasa")}: ${profile.language || "-"}\n` +
                    `➛ ${formatter.bold("Followers")}: ${stats.followers.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Following")}: ${stats.following.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Likes")}: ${stats.likes.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Videos")}: ${stats.videos.toLocaleString("id-ID")}\n` +
                    `➛ ${formatter.bold("Verified")}: ${verified}\n` +
                    `➛ ${formatter.bold("Private")}: ${private_}\n` +
                    `➛ ${formatter.bold("Link")}: ${profile.url}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};