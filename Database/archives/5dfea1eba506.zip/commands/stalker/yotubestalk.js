module.exports = {
    name: "ytstalk",
    aliases: ["youtubestalk", "stalkyt"],
    category: "stalker",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const input = ctx.text;

        if (!input)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["username"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "@hvlfy")
            );

        try {
            const { data } = await axios.get(
                "https://api.nexray.eu.cc/stalker/youtube",
                {
                    params: {
                        username: input
                    },
                    headers: {
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            if (!data.status || !data.result)
                return await ctx.reply("Channel YouTube tidak ditemukan.");

            const result = data.result.channel;

            let latestVideos = "Tidak ada video.";

            if (data.result.latest_videos?.length) {
                latestVideos = data.result.latest_videos
                    .map((v, i) =>
                        `${i + 1}. ${v.title}\n${v.url}`
                    )
                    .join("\n\n");
            }

            await ctx.reply({
                image: {
                    url: result.avatarUrl
                },
                caption:
                    `➛ ${formatter.bold("Username")}: ${result.username}\n` +
                    `➛ ${formatter.bold("Nama")}: ${result.name || "-"}\n` +
                    `➛ ${formatter.bold("Subscriber")}: ${result.subscriberCount}\n` +
                    `➛ ${formatter.bold("Video")}: ${result.videoCount}\n` +
                    `➛ ${formatter.bold("Deskripsi")}: ${result.description || "-"}\n` +
                    `➛ ${formatter.bold("URL")}: ${result.channelUrl}\n\n` +
                    `➛ ${formatter.bold("Latest Videos")}:\n${latestVideos}`
            });
        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};