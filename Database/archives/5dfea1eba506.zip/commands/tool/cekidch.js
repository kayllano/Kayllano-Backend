module.exports = {
    name: "cekidch",
    aliases: ["idch"],
    category: "tool",

    permissions: {
        coin: 3
    },

    code: async (ctx) => {
        try {

            const input = ctx.text?.trim();

            if (!input) {
                return await ctx.reply(
                    formatter.monospace(
                        `Masukkan URL channel!\n\nContoh:\n${ctx.used.prefix + ctx.used.command} https://whatsapp.com/channel/xxxx`
                    )
                );
            }

            const keyCh = input.match(
                /^https:\/\/whatsapp\.com\/channel\/(.+?)$/i
            )?.[1];

            if (!keyCh) {
                return await ctx.reply(
                    formatter.monospace(
                        "URL tidak valid!\nPastikan format:\nhttps://whatsapp.com/channel/ID"
                    )
                );
            }

            const data = await ctx.core.newsletterMetadata(
                "invite",
                keyCh
            );

            const meta    = data.thread_metadata || {};
            const id      = data.id                || "-";
            const name    = meta.name?.text        || "-";
            const desc    = meta.description?.text || "-";
            const subs    = meta.subscribers_count || "0";
            const status  = data.state?.type       || "-";
            const verif   = meta.verification      || "-";
            const invite  = meta.invite            || keyCh;
            const created = meta.creation_time
                ? new Date(parseInt(meta.creation_time) * 1000)
                    .toLocaleString("id-ID")
                : "-";

            const text =
                `「 *CHANNEL INFO* 」\n\n` +
                `➛ Nama: ${formatter.bold(name)}\n` +
                `➛ ID: ${id}\n` +
                `➛ Invite: ${invite}\n` +
                `➛ Pengikut: ${formatter.bold(Number(subs).toLocaleString("id-ID"))}\n` +
                `➛ Status: ${status}\n` +
                `➛ Verifikasi: ${verif}\n` +
                `➛ Dibuat: ${created}\n`;

            await ctx.reply({
                text: text.trim(),
                footer: config.msg.footer,
                nativeFlow: [
                    {
                        text: "Salin ID Channel",
                        copy: id
                    }
                ]
            });

        } catch (error) {

            console.error(error);

            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};
