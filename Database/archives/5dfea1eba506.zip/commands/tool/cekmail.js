// =========================
// CEKMAIL
// =========================

const axios = require("axios");

module.exports = {
    name: "cekmail",
    aliases: ["checkmail"],
    category: "tool",

    code: async (ctx) => {
        try {

            const session =
                ctx.db.user.tempMail;

            // BELUM PUNYA EMAIL
            if (!session?.email) {

                return await ctx.reply(
                    formatter.monospace(
                        "Kamu belum memiliki temp mail."
                    )
                );
            }

            // AUTO EXPIRE
            if (
                Date.now() - session.createdAt >
                1000 * 60 * 30
            ) {

                delete ctx.db.user.tempMail;

                return await ctx.reply(
                    formatter.monospace(
                        "Temp mail sudah expired, silahkan buat ulang."
                    )
                );
            }

            // CHECK INBOX
            const response = await axios.get(
                "https://api.synoxcloud.xyz/tempmail/tempmail-inbox",
                {
                    params: {
                        id: session.visitorId
                    },
                    timeout: 20000
                }
            );

            if (!response.data?.status) {

                return await ctx.reply(
                    tools.msg.info(
                        "Gagal mengecek inbox."
                    )
                );
            }

            const messages =
                response.data.result.messages || [];

            // BELUM ADA PESAN
            if (messages.length < 1) {

                return await ctx.reply({
                    text:

`${formatter.bold("Inbox Temp Mail")}

${formatter.monospace("Email")} :
${formatter.bold(session.email)}

${formatter.monospace("Status")} :
${formatter.bold("Belum ada pesan masuk")}`,

                    footer: config.msg.footer,

                    nativeFlow: [
                        {
                            text: "Refresh Inbox",
                            id: `${ctx.used.prefix}cekmail`
                        },
                        {
                            text: "Salin Email",
                            copy: session.email
                        }
                    ]
                });
            }

            // ADA PESAN
            let text =

`${formatter.bold("Inbox Temp Mail")}

${formatter.monospace("Email")} :
${formatter.bold(session.email)}

`;

            for (const msg of messages) {

                text +=

`${formatter.monospace("From")} :
${formatter.bold(msg.from || "-")} (${msg.from_address || "-"})

${formatter.monospace("Subject")} :
${formatter.bold(msg.subject || "-")}

${formatter.monospace("Time")} :
${formatter.bold(msg.date || "-")}

${formatter.monospace("Message")} :
${msg.content || msg.preview || "-"}

─────────────────

`;
            }

            await ctx.reply({
                text: text.trim(),

                footer: config.msg.footer,

                nativeFlow: [
                    {
                        text: "Refresh Inbox",
                        id: `${ctx.used.prefix}cekmail`
                    },
                    {
                        text: "Salin Email",
                        copy: session.email
                    }
                ]
            });

        } catch (error) {

            console.error(error);

            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};