const axios = require("axios");

module.exports = {
name: "reactch",
aliases: ["rch"],
category: "tools",
    permissions: {
        premium: true
    },

code: async (ctx) => {
    try {
        const input = ctx.args.join(" ");

        if (!input) {
            return await ctx.reply(
                tools.msg.info(
                    `Contoh:\n${ctx.used.prefix}reactch https://whatsapp.com/channel/xxxxx|🔥❤️😂`
                )
            );
        }

        const [url, emojiInput = "🔥,✨,☝️"] = input.split("|");

        if (!url || !url.includes("whatsapp.com/channel")) {
            return await ctx.reply(
                tools.msg.info("URL channel WhatsApp tidak valid.")
            );
        }

        await ctx.reply("ⓘ Sedang mengirim reaction...");

        const csrf = await axios.get(
            "https://react-channelwa.vercel.app/api/csrf-token",
            {
                headers: {
                    Referer: "https://react-channelwa.vercel.app/"
                },
                timeout: 15000
            }
        );

        const { token, sessionId } = csrf.data;

        const deviceId =
            `device_${Date.now()}_${Math.random()
                .toString(36)
                .slice(2, 8)}`;

        const register = await axios.post(
            "https://react-channelwa.vercel.app/api/register-device",
            { deviceId },
            {
                headers: {
                    "Content-Type": "application/json",
                    "X-Session-Id": sessionId
                },
                timeout: 15000
            }
        );

        if (!register.data?.success || !register.data?.deviceKey) {
            return await ctx.reply(
                tools.msg.info("Gagal register device.")
            );
        }

        const inject = await axios.post(
            "https://react-channelwa.vercel.app/api/inject",
            {
                deviceKey: register.data.deviceKey,
                url,
                emojis: emojiInput,
                csrfToken: token,
                sessionId
            },
            {
                headers: {
                    "Content-Type": "application/json",
                    "X-Session-Id": sessionId
                },
                timeout: 30000
            }
        );

        const result = inject.data;

        await ctx.reply(
            `ⓘ Status: ${result.success ? "Berhasil" : "Gagal"}

Pesan: ${result.message || "-"}

Emoji: ${emojiInput}`
);

    } catch (e) {
        console.error(e);

        await ctx.reply(
            tools.msg.info(
                e?.response?.data?.message ||
                e?.message ||
                "Terjadi kesalahan."
            )
        );
    }
}

};