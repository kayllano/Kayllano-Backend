module.exports = {
    name: "screenshot",
    aliases: ["ss", "ssmobile", "sstablet", "ssdesktop", "ssweb"],
    category: "tool",
    permissions: {
        coin: 10
    },
    code: async (ctx) => {
        const url = ctx.args[0] || tools.cmd.extractUrlFromText(ctx.quoted?.body);

        if (!url)
            return await ctx.reply(
                `${tools.msg.generateInstruction(["send"], ["text"])}\n` +
                tools.msg.generateCmdExample(ctx.used, "https://artoria.work.gd")
            );

        const isUrl = tools.cmd.isUrl(url);
        if (!isUrl) return await ctx.reply(tools.msg.info(config.msg.urlInvalid));

        try {

            // =========================
            // DEVICE SELECTOR
            // =========================
            const deviceMap = {
                ssmobile:  "mobile",
                sstablet:  "tablet",
                ssdesktop: "desktop",
                ss:        "mobile",
                ssweb:     "desktop"
            };
            const device = deviceMap[ctx.used.command] || "mobile";

            // =========================
            // FETCH SCREENSHOT
            // =========================
            const { data: res } = await axios.get(
                "https://api-nanzz.my.id/docs/api/tools/ssweb.php",
                {
                    params: { url, device },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.screenshot_url) {
                return await ctx.reply(tools.msg.info("Gagal mengambil screenshot. Pastikan URL valid dan coba lagi."));
            }

            const { screenshot_url, dimensions, size } = res.result;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                image: { url: screenshot_url },
                caption:
                    `› ${formatter.bold("URL")}     : ${url}\n` +
                    `› ${formatter.bold("Device")}  : ${tools.msg.ucwords(device)}\n` +
                    `› ${formatter.bold("Dimensi")} : ${dimensions.width}x${dimensions.height}px\n` +
                    `› ${formatter.bold("Ukuran")}  : ${size}`
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};