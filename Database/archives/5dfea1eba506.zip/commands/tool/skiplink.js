module.exports = {
    name: "skiplink",
    aliases: ["bypasslink", "skipads"],
    category: "tool",
    permissions: {
        coin: 10
    },

    code: async (ctx) => {
        try {

            // =========================
            // VALIDASI INPUT
            // =========================
            const url = ctx.args[0];

            if (!url) {
                return await ctx.reply({
                    text: `*Skip Link*\n\n` +
                        `› Format : .skiplink [url]\n` +
                        `› Contoh : .skiplink https://sfl.gl/tjKZof\n\n` +
                        `*— Support*\n` +
                        `› linkvertise, sfl.gl, workink, fly.inc\n` +
                        `› shrtfly, sub2unlock, sub4unlock\n` +
                        `› rekonise, boostellar, pastebin\n` +
                        `› paste-drop, pastefy, pasterso, dll`,
                    footer: config.msg.footer
                });
            }

            const isUrl = tools.cmd.isUrl(url);
            if (!isUrl) return await ctx.reply(tools.msg.info(config.msg.urlInvalid));

            await ctx.reply(tools.msg.info("Memproses link, harap tunggu..."));

            // =========================
            // FETCH DATA
            // =========================
            const { data: res } = await axios.get(
                "https://api-nanzz.my.id/docs/api/tools/skip-link.php",
                {
                    params: { url },
                    timeout: 30000
                }
            );

            if (!res.status || !res.result?.result) {
                return await ctx.reply(tools.msg.info("Gagal memproses link. Pastikan link yang kamu masukkan didukung."));
            }

            const { result, cached } = res.result;

            // =========================
            // KIRIM HASIL
            // =========================
            await ctx.reply({
                text:
                    `*Skip Link*\n\n` +
                    `› ${formatter.bold("Original")} : ${url}\n` +
                    `› ${formatter.bold("Result")}   : ${result}\n` +
                    `› ${formatter.bold("Cache")}    : ${cached ? "Ya" : "Tidak"}`,
                footer: config.msg.footer
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};