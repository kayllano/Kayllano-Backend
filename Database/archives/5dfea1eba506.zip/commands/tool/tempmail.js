// =========================
// TEMPMAIL
// =========================

const axios = require("axios");

module.exports = {
    name: "tempmail",
    aliases: ["tmpmail"],
    category: "tool",

    code: async (ctx) => {
        try {

            const sub = ctx.args[0]?.toLowerCase();

            // =========================
            // RESET / HAPUS EMAIL
            // =========================
            if (sub === "reset" || sub === "hapus" || sub === "delete") {
                if (!ctx.db.user.tempMail?.email) {
                    return await ctx.reply(
                        formatter.monospace("Kamu belum memiliki temp mail untuk dihapus.")
                    );
                }

                delete ctx.db.user.tempMail;

                return await ctx.reply(
                    tools.msg.info("Temp mail berhasil dihapus. Ketik .tempmail untuk membuat yang baru.")
                );
            }

            // DATABASE USER
            ctx.db.user.tempMail =
                ctx.db.user.tempMail || null;

            // AUTO EXPIRE 30 MENIT
            if (
                ctx.db.user.tempMail &&
                Date.now() - ctx.db.user.tempMail.createdAt >
                1000 * 60 * 30
            ) {
                delete ctx.db.user.tempMail;
            }

            // SUDAH PUNYA EMAIL
            if (ctx.db.user.tempMail?.email) {

                return await ctx.reply({
                    text:

`${formatter.bold("Temp Mail Aktif")}

${formatter.monospace("Email")} :
${formatter.bold(ctx.db.user.tempMail.email)}`,

                    footer: config.msg.footer,

                    nativeFlow: [
                        {
                            text: "Cek Inbox",
                            id: `${ctx.used.prefix}cekmail`
                        },
                        {
                            text: "Reset Email",
                            id: `${ctx.used.prefix}tempmail reset`
                        },
                        {
                            text: "Salin Email",
                            copy: ctx.db.user.tempMail.email
                        }
                    ]
                });
            }

            // CREATE EMAIL
            const response = await axios.get(
                "https://api.synoxcloud.xyz/tempmail/tempmail-create",
                {
                    timeout: 20000
                }
            );

            if (!response.data?.status) {
                return await ctx.reply(
                    tools.msg.info(
                        "Gagal membuat temp mail."
                    )
                );
            }

            const result =
                response.data.result;

            // SAVE SESSION PER USER
            ctx.db.user.tempMail = {
                email: result.address,
                visitorId: result.visitor_id,
                createdAt: Date.now()
            };

            await ctx.reply({
                text:

`${formatter.bold("Temp Mail Berhasil Dibuat")}

${formatter.monospace("Email")} :
${formatter.bold(result.address)}

${formatter.monospace("Berlaku")} :
${formatter.bold(`${result.expire_minutes} menit`)}`,

                footer: config.msg.footer,

                nativeFlow: [
                    {
                        text: "Cek Inbox",
                        id: `${ctx.used.prefix}cekmail`
                    },
                    {
                        text: "Salin Email",
                        copy: result.address
                    }
                ]
            });

        } catch (error) {

            console.error(error);

            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};