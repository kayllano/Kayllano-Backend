const axios = require("axios");
const FormData = require("form-data");

module.exports = {
    name: "upload",
    aliases: ["up", "tourl"],
    category: "tool",

    permissions: {
        coin: 10
    },

    code: async (ctx) => {

        const checkMedia = tools.cmd.checkMedia(
            ctx.msg.messageType,
            ["audio", "document", "image", "sticker", "video"]
        );

        const checkQuotedMedia = tools.cmd.checkQuotedMedia(
            ctx.quoted ? ctx.quoted.messageType : null,
            ["audio", "document", "image", "sticker", "video"]
        );

        if (!checkMedia && !checkQuotedMedia) {
            return await ctx.reply(
                tools.msg.generateInstruction(
                    ["send", "reply"],
                    ["audio", "document", "image", "sticker", "video"]
                )
            );
        }

        try {

            const target = checkMedia
                ? ctx.msg
                : ctx.quoted;

            const buffer = await target.download();

            const mimetype =
                target.mimetype ||
                "application/octet-stream";

            const ext =
                mimetype.split("/")[1] || "bin";

            const form = new FormData();

            form.append("file", buffer, {
                filename: "upload." + ext,
                contentType: mimetype
            });

            const { data } = await axios({
                method: "POST",
                url: "https://x.xcute.workers.dev/api/upload",

                headers: {
                    ...form.getHeaders()
                },

                data: form,
                maxBodyLength: Infinity
            });

            if (!data.status) {
                throw new Error(
                    data.message || "Upload gagal"
                );
            }

            const result = data.result.url;

            await ctx.reply({
                text:
                    `➛ ${formatter.bold("URL")}: ${result}\n` +
                    `➛ ${formatter.bold("Size")}: ${data.result.sizeHuman}\n` +
                    `➛ ${formatter.bold("Mime")}: ${data.result.mimetype}\n` +
                    `➛ ${formatter.bold("Storage")}: ${data.result.storage}`,

                footer: tools.msg.info(
                    "File tersimpan permanen."
                ),

                nativeFlow: [
                    {
                        text: "Salin URL",
                        copy: result
                    }
                ]
            });

        } catch (error) {

            console.log(
                error.response
                    ? error.response.data
                    : error
            );

            await tools.cmd.handleError(
                ctx,
                error,
                true
            );
        }
    }
};