const FormData = require("form-data");

module.exports = {
    name: "videohd",
    aliases: ["enhancevideo", "videnhance", "vhd"],
    category: "tool",
    permissions: {
        coin: 25
    },
    code: async (ctx) => {
        let buffer = null;

        if (ctx.quoted?.download) {
            buffer = await ctx.quoted.download();
        } else if (ctx.msg?.download) {
            buffer = await ctx.msg.download();
        }

        if (!buffer)
            return await ctx.reply(
                `*⌜ Video Enhancer — Ultra HD ⌟*\n` +
                `─────────────────\n` +
                `Tingkatkan kualitas video ke resolusi Ultra HD\n` +
                `secara otomatis menggunakan AI.\n\n` +
                `*— Cara Pakai*\n` +
                `› Kirim atau reply video, lalu ketik perintah ini\n` +
                `  Contoh: kirim video → reply dengan ${formatter.inlineCode(ctx.used.prefix + ctx.used.command)}\n\n` +
                `*— Format yang Didukung*\n` +
                `› MP4, MOV, WEBM, MKV\n\n` +
                `*— Catatan*\n` +
                `› Proses membutuhkan waktu 1–5 menit\n` +
                `› Biaya: 25 koin per proses`
            );

        try {
            await ctx.reply(
                `⏳ *Memproses video...*\n` +
                `Mohon tunggu, proses enhancement bisa memakan waktu\n` +
                `1–5 menit tergantung durasi dan ukuran video.`
            );

            const form = new FormData();
            form.append("apikey", "artoriaox");
            form.append("video", buffer, "video.mp4");

            const { data } = await axios.post(
                "https://api.theresav.biz.id/tools/winkvideo",
                form,
                {
                    headers: form.getHeaders(),
                    maxBodyLength: Infinity,
                    maxContentLength: Infinity,
                    timeout: 300000 // 5 menit
                }
            );

            if (!data.status || !data.result?.url)
                return await ctx.reply("❌ Gagal memproses video. Coba lagi nanti.");

            await ctx.reply({
                video: { url: data.result.url },
                caption:
                    `✅ *Video berhasil di-enhance ke Ultra HD!*\n` +
                    `─────────────────\n` +
                    `› Diproses menggunakan Wink AI\n` +
                    `› Resolusi ditingkatkan otomatis oleh AI\n\n` +
                    `_Jika video tidak terkirim, buka link berikut:_\n` +
                    data.result.url
            });

        } catch (error) {
            await tools.cmd.handleError(ctx, error, true);
        }
    }
};