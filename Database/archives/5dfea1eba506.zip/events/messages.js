// Impor modul dan dependensi yang diperlukan
const { Baileys, Events, Gktw } = require("@itsreimau/gktw");
const moment = require("moment-timezone");
const { handleAutoDownloader } = require("../tools/neko");

// Fungsi untuk menambahkan warning
async function handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb) {
    const maxWarnings = groupDb?.maxwarnings || 3;
    const warnings    = groupDb?.warnings || [];

    // Mode punishment: autokick = kick setelah maxWarnings, warnonly = peringatan saja
    const isAutokick  = groupDb?.option?.autokick || false;

    const senderWarning = warnings.find(warning => tools.cmd.areJidsSameUser(warning.jid, senderLid));
    let currentWarnings = senderWarning ? senderWarning.count : 0;
    currentWarnings    += 1;

    if (senderWarning) {
        senderWarning.count = currentWarnings;
    } else {
        warnings.push({ jid: senderLid, count: currentWarnings });
    }

    groupDb.warnings = warnings;

    // Teks peringatan berbeda tergantung mode
    const warnSuffix = isAutokick
        ? ` — kick otomatis saat peringatan ke-${maxWarnings}.`
        : ` — hanya peringatan, tidak ada kick.`;

    await ctx.reply({
        text: tools.msg.info(
            `Peringatan ${currentWarnings}/${maxWarnings} untuk @${ctx.getId(senderId)}!${warnSuffix}`
        ),
        mentions: [senderJid]
    });

    // Kick hanya jika mode autokick aktif dan sudah mencapai maxWarnings
    if (isAutokick && currentWarnings >= maxWarnings) {
        const isBotAdmin = await ctx.group(groupJid, !config.system.selfReply).isBotAdmin();
        if (isBotAdmin) {
            await ctx.reply({
                text: tools.msg.info(
                    `@${ctx.getId(senderId)} telah menerima ${maxWarnings} peringatan dan dikeluarkan dari grup.`
                ),
                mentions: [senderJid]
            });
            if (!config.system.restrict) await ctx.group().kick(senderJid);
            groupDb.warnings = warnings.filter(warning => warning.jid !== senderLid);
        } else {
            await ctx.reply({
                text: tools.msg.info(
                    `${config.msg.botAdmin} Tidak dapat mengeluarkan @${ctx.getId(senderId)} yang telah mencapai ${maxWarnings} peringatan.`
                ),
                mentions: [senderJid]
            });
        }
    }

    groupDb.save();
}

module.exports = (bot) => {

    if (!global.groupScheduler) {

        console.log("[GroupScheduler] Started");

        global.groupScheduler = setInterval(async () => {

            try {

                const groups =
                    bot.db.collections
                        .find(v => v.name === "groups")
                        ?.getAll() || [];

                const now = moment()
                    .tz(config.system.timeZone);

                const current =
                    String(now.hour()).padStart(2, "0") +
                    ":" +
                    String(now.minute()).padStart(2, "0");

                for (const group of groups) {

                    try {

                        if (
                            group.autoClose &&
                            group.autoClose === current
                        ) {

                            console.log(
                                "[AUTO CLOSE]",
                                group.jid
                            );

                            await bot.core.groupSettingUpdate(
                                group.jid,
                                "announcement"
                            );

                            await bot.sendMessage(
                                group.jid,
                                {
                                    text: "🔒 Grup ditutup otomatis sesuai jadwal."
                                }
                            );

                        }

                        if (
                            group.autoOpen &&
                            group.autoOpen === current
                        ) {

                            console.log(
                                "[AUTO OPEN]",
                                group.jid
                            );

                            await bot.core.groupSettingUpdate(
                                group.jid,
                                "not_announcement"
                            );

                            await bot.sendMessage(
                                group.jid,
                                {
                                    text: "🔓 Grup dibuka otomatis sesuai jadwal."
                                }
                            );

                        }

                        if (
                            group.spamLockUntil &&
                            Date.now() >= group.spamLockUntil
                        ) {
                            try {
                                await bot.core.groupSettingUpdate(
                                    group.jid,
                                    "not_announcement"
                                );
                                await bot.sendMessage(
                                    group.jid,
                                    {
                                        text: tools.msg.info("Grup telah dibuka kembali setelah masa penguncian spam selesai.")
                                    }
                                );
                                delete group.spamLockUntil;
                                group.save();
                            } catch (err) {
                                console.error("[AutoUnlockSpam]", err);
                            }
                        }

                    } catch (err) {
                        console.error(
                            "[GroupScheduler]",
                            err
                        );
                    }

                }

            } catch (err) {
                console.error(
                    "[GroupScheduler]",
                    err
                );
            }

        }, 30000);

    }

    // Event saat bot menerima pesan
    bot.ev.on(Events.MessagesUpsert, async (ctx) => {
        const {
            msg
        } = ctx;
        if (msg.key.fromMe) return;

        // Variabel umum
        const isGroup = ctx.isGroup();
        const isPrivate = ctx.isPrivate();

        // Grup atau obrolan pribadi
        if (isGroup || isPrivate) {
            // Variabel umum
            const senderJid = ctx.sender.jid;
            const senderId = ctx.getId(senderJid);
            const senderLid = ctx.sender.lid;
            const groupJid = isGroup ? ctx.id : null;
            const groupId = isGroup ? ctx.getId(groupJid) : null;
            const isOwner = ctx.sender.isOwner();
            const isCmd = ctx.isCmd();
            const isAdmin = isGroup ? await ctx.group().isSenderAdmin() : false;

            // Mengambil database
            const botDb = ctx.db.bot;
            const senderDb = ctx.db.user;
            const groupDb = ctx.db.group;

            // Penanganan database pengguna
            if (senderDb) {
                if (senderDb?.premium && Date.now() > senderDb?.premiumExpiration) {
                    delete senderDb.premium;
                    delete senderDb.premiumExpiration;
                }
                if (isOwner || senderDb?.premium) senderDb.coin = 0;
                if (!senderDb?.coin || !Number.isFinite(senderDb?.coin)) senderDb.coin = 100;
                senderDb.save();
            }

            // Pengecekan mode bot (premium, group, private, self)
            if (botDb?.mode === "premium" && !isOwner && !senderDb?.premium) return;
            if (botDb?.mode === "group" && isPrivate && !isOwner && !senderDb?.premium) return;
            if (botDb?.mode === "private" && isGroup && !isOwner && !senderDb?.premium) return;
            if (botDb?.mode === "self" && !isOwner) return;

            // Penanganan bug hama!
            if (typeof Gktw.analyzeBug === "function") {
                const analyze = Gktw.analyzeBug(msg.message, {
                    maxTextLength: 10000,
                    maxMentions: 1000,
                    maxFileLength: 2 * 1024 * 1024 * 1024,
                    maxPageCount: 10000,
                    maxCharacterFlood: 20000
                });
                if (config.system.antiBug && analyze.isMalicious && !senderDb?.banned && !isOwner) {
                    await ctx.deleteMessage(ctx.id, msg.key);
                    await ctx.block(senderJid);
                    senderDb.banned = true;
                    senderDb.save();

                    const reportOwner = tools.cmd.getReportOwner();
                    if (reportOwner && reportOwner.length > 0) {
                        const {
                            delay
                        } = tools.cmd.calculateDelay(reportOwner.length);
                        for (const ownerId of reportOwner) {
                            await ctx.replyWithJid(ownerId + Baileys.S_WHATSAPP_NET, {
                                text: tools.msg.info(`Akun @${senderId} telah dibanned secara otomatis karena alasan ${formatter.inlineCode(`Anti Bug - ${analyze.reason}`)}, tingkat bahaya ${formatter.inlineCode(analyze.severity)}, jenis ancaman ${formatter.inlineCode(analyze.severity)}.`),
                                mentions: [senderJid]
                            });
                            await tools.cmd.delay(delay);
                        }
                    }
                }
            } else if (!global.gktwBugWarned) {
                global.gktwBugWarned = true;
                console.warn("[WARNING] Gktw.analyzeBug tidak tersedia di versi package ini — fitur anti-bug dinonaktifkan sementara.");
            }

            // Pengecekan mute pada grup
            if (isGroup) {
                if (groupDb?.mutebot) return;

                const muteList = groupDb?.mute || [];

                groupDb.mute = muteList.filter(
                    mute => !mute.expiration || Date.now() <= mute.expiration
                );

                if (groupDb.mute.length !== muteList.length) {
                    await groupDb.save();
                }

                if (groupDb.mute.some(mute => mute.jid === ctx.sender.lid)) {
                    await ctx.deleteMessage(ctx.id, msg.key);
                }
            }

            // Pengecekan untuk tidak tersedia pada malam hari
            const now = moment().tz(config.system.timeZone);
            const hour = now.hour();
            if (config.system.unavailableAtNight && !isOwner && !senderDb?.premium && hour >= 0 && hour < 6) return;

            // Did you mean?
            if (isCmd?.didyoumean)
                await ctx.reply({
                    text: tools.msg.info(`Apakah maksudmu ${formatter.inlineCode(isCmd.prefix + isCmd.didyoumean)}?`),
                    buttons: [{
                        text: "Ya, benar!",
                        id: `${isCmd.prefix + isCmd.didyoumean} ${isCmd.input}`
                    }]
                });

            // Penanganan AFK (Menghapus status AFK pengguna yang mengirim pesan)
            const senderAfk = senderDb?.afk || {};
            if (senderAfk.reason || senderAfk.timestamp) {
                const timeElapsed = Date.now() - senderAfk.timestamp;
                if (timeElapsed > 3000) {
                    const timeago = tools.msg.convertMsToDuration(timeElapsed);
                    await ctx.reply(tools.msg.info(`Anda telah keluar dari AFK ${senderAfk.reason ? `dengan alasan ${formatter.inlineCode(senderAfk.reason)}` : "tanpa alasan"} selama ${timeago}.`));
                    delete senderDb.afk;
                    senderDb.save();
                }
            }

            // =========================
            // AUTO DOWNLOADER
            // dijalankan SEBELUM antilink biar link yang
            // terdeteksi platform download tidak ikut terhapus
            // =========================
            const autoDlActive = isGroup
                ? groupDb?.option?.autodl
                : botDb?.autodl;

            if (!isCmd && autoDlActive) {
                await handleAutoDownloader(ctx);
            }

            // Penanganan obrolan grup
            if (isGroup) {
                if (!isCmd || isCmd?.didyoumean)
                    log.info(
                        `MSG | ${groupId} | ${senderId}`
                    ); // Log pesan masuk

                // Variabel umum
                const messageType = ctx.getMessageType();
                // Penanganan database grup
                if (groupDb?.sewa && Date.now() > senderDb?.sewaExpiration) {
                    delete groupDb.sewa;
                    delete groupDb.sewaExpiration;
                    groupDb.save();
                }

                // Penanganan AFK (Pengguna yang disebutkan atau di-balas/quote)
                const afkMentions = ctx.quoted ? [ctx.quoted.sender] : await ctx.getMentioned();
                if (afkMentions.length > 0) {
                    for (const afkMention of afkMentions) {
                        const mentionAfk = ctx.getDb("users", afkMention)?.afk || {};
                        if (mentionAfk.reason || mentionAfk.timestamp) {
                            const timeago = tools.msg.convertMsToDuration(Date.now() - mentionAfk.timestamp);
                            await ctx.reply({
                                text: tools.msg.info(`Jangan ganggu! @${ctx.getId(afkMention)} sedang AFK ${mentionAfk.reason ? `dengan alasan ${formatter.inlineCode(mentionAfk.reason)}` : "tanpa alasan"} selama ${timeago}.`),
                                mentions: [afkMention]
                            });
                        }
                    }
                }

                if (!isCmd && !isOwner && !isAdmin) {
                    // Penanganan antimedia
                    for (const type of ["audio", "document", "image", "sticker", "video"]) {
                        if (groupDb?.option?.[`anti${type}`]) {
                            const checkMedia = tools.cmd.checkMedia(messageType, type);
                            if (!!checkMedia) {
                                await ctx.reply(tools.msg.info(`Jangan kirim ${type}!`));
                                await ctx.deleteMessage(ctx.id, msg.key);
                                await handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb);
                            }
                        }
                    }

                    // Penanganan antigcsw
                    if (groupDb?.option?.antigcsw) {
                        const checkMedia = msg.message?.groupStatusMessageV2?.contextInfo?.isGroupStatus;
                        if (checkMedia) {
                            await ctx.reply(tools.msg.info("Jangan bikin SW di grup, gak ada yg peduli!"));
                            await ctx.deleteMessage(ctx.id, msg.key);
                            await handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb);
                        }
                    }

                    // Penanganan antilink
                    // skip kalau link itu sedang diproses auto downloader
                    if (groupDb?.option?.antilink) {
                        if (msg.body && tools.cmd.isUrl(msg.body) && !autoDlActive) {
                            await ctx.reply(tools.msg.info("Jangan kirim link!"));
                            await ctx.deleteMessage(ctx.id, msg.key);
                            await handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb);
                        }
                    }

                    // Penanganan antispam
                    if (groupDb?.option?.antispam) {
                        const now = Date.now();
                        const spamData = groupDb?.spam || [];
                        const senderSpam = spamData.find(spam => tools.cmd.areJidsSameUser(spam.jid, senderLid)) || {
                            jid: senderLid,
                            count: 0,
                            lastMessageTime: 0
                        };

                        const timeDiff = now - senderSpam.lastMessageTime;
                        const newCount = timeDiff < 5000 ? senderSpam.count + 1 : 1;

                        senderSpam.count = newCount;
                        senderSpam.lastMessageTime = now;
                        if (!spamData.some(spam => tools.cmd.areJidsSameUser(spam.jid, senderLid))) spamData.push(senderSpam);
                        groupDb.spam = spamData;

                        if (newCount > 9) {
                            await ctx.deleteMessage(ctx.id, msg.key);
                            groupDb.spam = spamData.filter(spam => spam.jid !== senderLid);

                            const isAutokickSpam = groupDb?.option?.autokick || false;
                            const isBotAdminSpam = await ctx.group(groupJid, !config.system.selfReply).isBotAdmin();

                            senderDb.banned = true;
                            senderDb.save();

                            if (!isAutokickSpam) {
                                await ctx.reply({
                                    text: tools.msg.info(
                                        `@${ctx.getId(senderId)} terdeteksi spam! Grup ditutup sementara selama 3 menit dan user telah dibanned dari bot.`
                                    ),
                                    mentions: [senderJid]
                                });

                                if (isBotAdminSpam && !config.system.restrict) {
                                    await ctx.core.groupSettingUpdate(groupJid, "announcement");
                                    groupDb.spamLockUntil = Date.now() + (3 * 60 * 1000);
                                    groupDb.save();
                                } else if (!isBotAdminSpam) {
                                    await ctx.reply(tools.msg.info(`${config.msg.botAdmin} Tidak dapat menutup grup karena bot bukan admin.`));
                                }
                            } else {
                                if (isBotAdminSpam) {
                                    await ctx.reply({
                                        text: tools.msg.info(
                                            `@${ctx.getId(senderId)} terdeteksi spam! User telah dikeluarkan dari grup dan dibanned dari bot.`
                                        ),
                                        mentions: [senderJid]
                                    });
                                    if (!config.system.restrict) await ctx.group().kick(senderJid);
                                } else {
                                    await ctx.reply({
                                        text: tools.msg.info(
                                            `${config.msg.botAdmin} Tidak dapat mengeluarkan @${ctx.getId(senderId)}, tapi user telah dibanned dari bot.`
                                        ),
                                        mentions: [senderJid]
                                    });
                                }
                            }
                        }

                        groupDb.save();
                    }

                    // Penanganan antitagsw
                    if (groupDb?.option?.antitagsw) {
                        const checkMedia = msg.message?.protocolMessage?.type === 25;
                        if (!!checkMedia) {
                            await ctx.reply(tools.msg.info("Jangan tag grup di SW, gak ada yg peduli!"));
                            await ctx.deleteMessage(ctx.id, msg.key);
                            await handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb);
                        }
                    }

                    // Penanganan antitoxic
                    if (groupDb?.option?.antitoxic) {
                        const toxicRegex = /anj(k|g)|ajn?(g|k)|a?njin(g|k)|bajingan|b(a?n)?gsa?t|ko?nto?l|me?me?(k|q)|pe?pe?(k|q)|meki|titi(t|d)|pe?ler|tetek|toket|ngewe|go?blo?k|to?lo?l|idiot|(k|ng)e?nto?(t|d)|jembut|bego|dajj?al|janc(u|o)k|pantek|puki ?(mak)?|kimak|kampang|lonte|col(i|mek?)|pelacur|henceu?t|nigga|fuck|dick|bitch|tits|bastard|asshole|dontol|kontoi|ontol/i;
                        if (msg.body && toxicRegex.test(msg.body)) {
                            await ctx.reply(tools.msg.info("Jangan toxic!"));
                            await ctx.deleteMessage(ctx.id, msg.key);
                            await handleWarning(ctx, senderJid, senderId, senderLid, groupJid, groupDb);
                        }
                    }
                }
            }

            // Penanganan obrolan pribadi
            if (isPrivate) {
                if (!isCmd || isCmd?.didyoumean)
                    log.info(
                        `PM | ${senderId}`
                    ); // Log pesan masuk
            }
        }
    });
};

module.exports.handleWarning = handleWarning;