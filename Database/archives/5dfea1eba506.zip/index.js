// Impor modul dan dependensi yang diperlukan
try {
    require("node:process").loadEnvFile();
} catch {}

const fs = require("node:fs");
const path = require("node:path");

// Buat symlink baileys otomatis
try {
    const src = path.join(
        process.cwd(),
        "node_modules",
        "@itsreimau",
        "gktw",
        "node_modules",
        "baileys"
    );

    const dest = path.join(
        process.cwd(),
        "node_modules",
        "baileys"
    );

    if (
        fs.existsSync(src) &&
        !fs.existsSync(dest)
    ) {
        fs.symlinkSync(src, dest);
    }
} catch (_) {}

const { Config, Formatter } = require("@itsreimau/gktw");
const axios = require("axios");
const axiosRetry = require("axios-retry").default;
const pkg = require("./package.json");
const CFonts = require("cfonts");
const http = require("node:http");

/// Tetapkan axios retry
axiosRetry(axios, {
    retries: 3,
    retryCondition: (error) => {
        const status = error.response?.status;

        return (
            axiosRetry.isNetworkOrIdempotentRequestError(error) ||
            status === 408 ||
            status === 429
        );
    },

    retryDelay: (retryCount) =>
        Math.pow(2, retryCount - 1) * 1000 +
        Math.random() * 500
});

// Tetapkan variabel global
Object.assign(global, {
    axios,
    config: new Config(
        path.resolve(__dirname, "config.json")
    ),
    formatter: Formatter,
    tools: require("./tools/exports.js")
});

// Logger
global.log = {
    print(type, color, ...msg) {
        const time =
            new Date().toLocaleTimeString("id-ID");

        console.log(
            `\x1b[90m${time}\x1b[0m`,
            `\x1b[${color}m ${type} \x1b[0m`,
            ...msg
        );
    },

    info(...msg) {
        this.print("INFO", "44", ...msg);
    },

    success(...msg) {
        this.print("SUCCESS", "42", ...msg);
    },

    warn(...msg) {
        this.print("WARN", "43", ...msg);
    },

    error(...msg) {
        this.print("ERROR", "41", ...msg);
    },

    cmd(...msg) {
        this.print("CMD", "45", ...msg);
    }
};

log.info("Starting...");

// Tampilkan nama proyek serta deskripsi lain
CFonts.say(pkg.name, {
    colors: ["#00A1E0", "#00FFFF"],
    align: "center"
});

CFonts.say(
    `${pkg.description} - By ${pkg.author}`,
    {
        font: "console",
        colors: ["#E0F7FF"],
        align: "center"
    }
);

// Jalankan server jika diaktifkan dalam konfigurasi
if (config.system?.useServer) {
    const port = config.system.port;

    http.createServer((_, res) => {
        res.end(
            `${pkg.name} berjalan di port ${port}`
        );
    }).listen(port, () => {
        log.success(
            `${pkg.name} runs on port ${port}`
        );
    });
}

// Load MessageBuilder (async karena ESM)
import(
    `file://${path.join(
        process.cwd(),
        "tools",
        "MessageBuilder.js"
    )}`
)
.then(
    ({
        Button,
        ButtonV2,
        Carousel,
        AIRich
    }) => {

        Object.assign(global, {
            Button,
            ButtonV2,
            Carousel,
            AIRich
        });

        log.success(
            "[MessageBuilder] Loaded!"
        );
    }
)
.catch((e) => {
    log.error(
        "[MessageBuilder] Failed:",
        e.message
    );
});

require("./main.js");