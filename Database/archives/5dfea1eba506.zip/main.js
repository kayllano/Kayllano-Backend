// Impor modul dan dependensi yang diperlukan
const { Client, CommandHandler } = require("@itsreimau/gktw");
const path    = require("node:path");
const events  = require("./events/exports.js");
const middleware = require("./middleware.js");
const util    = require("node:util");
const chokidar = require("chokidar");

// Konfigurasi bot
const { bot: botConfig, system } = config;
const diretory = {
    auth:     path.resolve(__dirname, "state"),
    database: path.resolve(__dirname, "database"),
    command:  path.resolve(__dirname, "commands")
};

console.log("Connecting...");

// Fungsi untuk mengurai prefix
const parsePrefix = function(prefix) {
    if (typeof prefix !== "string") return prefix;
    var match = prefix.match(/(\/?)(.+)\1([a-z]*)/i);
    if (!match) return prefix;
    var validFlags = Array.from(new Set(match[3])).filter(function(flag) {
        return "gimsuy".includes(flag);
    }).join("");
    try {
        return new RegExp(match[2], validFlags);
    } catch (error) {
        return prefix;
    }
};

// Buat instance bot
const bot = new Client({
    auth: {
        dir: diretory.auth,
        phoneNumber: botConfig.phoneNumber,
        usePairingCode: system.usePairingCode,
        customPairingCode: system.customPairingCode,
        useStore: system.useStore
    },
    connection: {
        version: system?.WAVersion,
        alwaysOnline: system.alwaysOnline,
        selfReply: system.selfReply,
        loggerLevel: system?.loggerLevel
    },
    messaging: {
        autoRead: system.autoRead,
        prefix: parsePrefix(botConfig?.prefix)
    },
    database: {
        dir: diretory.database
    },
    owner: [config.owner.id, ...config.owner.co.map(co => co.id)].filter(Boolean)
});

// Inisialisasi event dan middleware
events(bot);
middleware(bot);

// Muat dan jalankan command handler
const cmd = new CommandHandler(bot, diretory.command);
cmd.load();

// Hot reload - watch perubahan di folder commands
chokidar.watch(diretory.command, {
    ignoreInitial: true,
    persistent: true
}).on("change", (filePath) => {
    try {
        delete require.cache[require.resolve(filePath)];
        cmd.load();
        console.log(`[hot-reload] Reloaded: ${path.basename(filePath)}`);
    } catch (err) {
        console.error(`[hot-reload] Error: ${err.message}`);
    }
}).on("add", (filePath) => {
    try {
        cmd.load();
        console.log(`[hot-reload] Added: ${path.basename(filePath)}`);
    } catch (err) {
        console.error(`[hot-reload] Error: ${err.message}`);
    }
}).on("unlink", (filePath) => {
    try {
        delete require.cache[require.resolve(filePath)];
        cmd.load();
        console.log(`[hot-reload] Removed: ${path.basename(filePath)}`);
    } catch (err) {
        console.error(`[hot-reload] Error: ${err.message}`);
    }
});

bot.launch().catch(error => console.error(`Error: ${util.format(error)}`));
