files_efectos = {--Marcador
"efecto 1.mp3",
"Intentando Abrir Puerta Cerrada 🔊- Efecto de Sonido_16-04-23_15-49-17-865.ogg"
}

files_efectos2 = {--Marcador
"efecto 4 puerta.m4a",
"pista 50.ogg"
}

files_dialogos = {--Marcador
"pista 1.ogg",
"pista 2.ogg",
"Intentando Abrir Puerta Cerrada 🔊- Efecto de Sonido_16-04-23_15-49-17-865.ogg"
}
files_fondo = {--Marcador
"fondo uno.m4a",
"fondo 6.ogg"
}
