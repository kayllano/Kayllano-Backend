require "import"
import "android.graphics.Bitmap"
import "android.graphics.Color"
import "android.graphics.drawable.ColorDrawable"
import "android.widget.TextView"
import "android.widget.ImageView"
import "android.widget.ListView"
import "android.view.View"
import "android.widget.PageView"
import "android.widget.CardView"

import "android.media.MediaPlayer"
import "android.widget.*"
import "com.androlua.*"
import "android.net.Uri"
import "android.content.*"
import "android.os.*"
import "java.io.*"


---------------------------
-- Funciones de Audio
---------------------------
function get_file_path(filename)
  local script_dir = get_script_dir()
  return script_dir .. filename
end

function file_exists(path)
  local file = io.open(path, "r")
  if file then
    io.close(file)
    return true
  else
    return false
  end
end



if global_mp_efectos ~= nil then
  global_mp_efectos.stop()
  global_mp_efectos.release()
  global_mp_efectos = nil
end
global_mp_efectos = nil
function play_music_efectos(index, volume)
  if global_mp_efectos ~= nil then
    global_mp_efectos.stop()
    global_mp_efectos.release()
    global_mp_efectos = nil
  end
  local file_path = get_file_path(files_efectos[index])
  if file_path == nil then return end
  local mp_efectos = MediaPlayer()
  mp_efectos.setDataSource(file_path)
  mp_efectos.setVolume(volume, volume)
  mp_efectos.prepare()
  mp_efectos.start()
  mp_efectos.setOnCompletionListener(MediaPlayer.OnCompletionListener{
    onCompletion = function()
      mp_efectos.release()
      global_mp_efectos = nil
    end
  })
  global_mp_efectos = mp_efectos
end


if global_mp_efectos2 ~= nil then
  global_mp_efectos2.stop()
  global_mp_efectos2.release()
  global_mp_efectos2 = nil
end
global_mp_efectos2 = nil
function play_music_efectos2(index, volume)
  if global_mp_efectos2 ~= nil then
    global_mp_efectos2.stop()
    global_mp_efectos2.release()
    global_mp_efectos2 = nil
  end
  local file_path = get_file_path(files_efectos2[index])
  if file_path == nil then
    print("Archivo no encontrado: " .. files_efectos2[index])
    return
  end
  local mp_efectos2 = MediaPlayer()
  mp_efectos2.setDataSource(file_path)
  mp_efectos2.setVolume(volume, volume)
  mp_efectos2.prepare()
  mp_efectos2.start()
  mp_efectos2.setOnCompletionListener(MediaPlayer.OnCompletionListener{
    onCompletion = function()
      mp_efectos2.release()
      global_mp_efectos2 = nil
    end
  })
  global_mp_efectos2 = mp_efectos2
end


if global_mp_fondo ~= nil then
  global_mp_fondo.stop()
  global_mp_fondo.release()
  global_mp_fondo = nil
end
global_mp_fondo = nil
function play_music_fondo(index, volume)
  if global_mp_fondo ~= nil then
    global_mp_fondo.stop()
    global_mp_fondo.release()
    global_mp_fondo = nil
  end
  local file_path = get_file_path(files_fondo[index])
  if file_path == nil then
    print("Archivo no encontrado: " .. files_fondo[index])
    return
  end
  local mp_fondo = MediaPlayer()
  mp_fondo.setDataSource(file_path)
  mp_fondo.setVolume(volume, volume)
  mp_fondo.prepare()
  mp_fondo.setLooping(true)
  mp_fondo.start()
  mp_fondo.setOnCompletionListener(MediaPlayer.OnCompletionListener{
    onCompletion = function()
      mp_fondo.release()
      global_mp_fondo = nil
    end
  })
  global_mp_fondo = mp_fondo
end



if global_mp_dialogos ~= nil then
  global_mp_dialogos.stop()
  global_mp_dialogos.release()
  global_mp_dialogos = nil
end
global_mp_dialogos = nil
function play_music_dialogos(index, volume)
  if global_mp_dialogos ~= nil then
    global_mp_dialogos.stop()
    global_mp_dialogos.release()
    global_mp_dialogos = nil
  end
  local file_path = get_file_path(files_dialogos[index])
  if file_path == nil then
    print("Archivo no encontrado: " .. files_dialogos[index])
    return
  end
  local mp_dialogos = MediaPlayer()
  mp_dialogos.setDataSource(file_path)
  mp_dialogos.setVolume(volume, volume)
  mp_dialogos.prepare()
  mp_dialogos.start()
  mp_dialogos.setOnCompletionListener(MediaPlayer.OnCompletionListener{
    onCompletion = function()
      mp_dialogos.release()
      global_mp_dialogos = nil
    end
  })
  global_mp_dialogos = mp_dialogos
end


---------------------------