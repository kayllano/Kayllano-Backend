require "import"
import("Sonido")
import("Modulo audio absoluto")
import("Listas de audio")
import "android.media.MediaPlayer"
import "android.content.*"
import "android.widget.*"
import "android.os.*"
import "java.io.*"
import "android.net.Uri"
import "android.graphics.Bitmap"
import "android.net.ConnectivityManager"
import "java.net.URL"
import "org.json.JSONObject"
context = activity or service




local PATHS = {
    screenshot = "/storage/emulated/0/Absoluta by sergiopina/Screenshot_by_SP.jpg",
    vision = "/storage/emulated/0/Absoluta by sergiopina/Dictado absoluto gemini",
    api_file = "/storage/emulated/0/Absoluta by sergiopina/Dictado absoluto gemini/api.txt",
    model_file = "/storage/emulated/0/Absoluta by sergiopina/Dictado absoluto gemini/model.txt"
}
local DEFAULT_MODEL = "gemini-2.0-flash-exp"
local MIN_API_KEY_LENGTH = 30
local MODELOS_DISPONIBLES = {
    "gemini-2.0-flash-exp",
    "gemini-1.5-flash-latest",
    "gemini-1.5-pro-latest"
}






play_music_dialogos(1, 0.5)
local function createFolder(folderPath)

    local folder = File(folderPath)
    if not folder.exists() then
        local created = folder.mkdirs()

        return created
    end

    return true
end
function runOnUiThread(task)
    local handler = luajava.bindClass("android.os.Handler")
    handler = handler(luajava.bindClass("android.os.Looper").getMainLooper())
    handler.post(luajava.createProxy("java.lang.Runnable", {run = task}))
end
function hasInternetConnection()
    local connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE)
    local networkInfo = connectivityManager.getActiveNetworkInfo()
    return networkInfo ~= nil and networkInfo.isConnected()
end



local function readFileSafe(filePath)
    local success, result = pcall(function()
        local file = io.open(filePath, "r")
        if not file then return nil end
        local content = file:read("*a")
        file:close()
        return content
    end)
    
    if success and result then
        result = result:gsub("^%s+", ""):gsub("%s+$", "")
        result = result:gsub('"', ''):gsub("'", '')
        return result
    end
    return nil
end
local function writeFileSafe(filePath, content)
    local success, err = pcall(function()
        local parentDir = filePath:match("^(.+)/[^/]+$")
        if parentDir then
            local folder = File(parentDir)
            if not folder.exists() then
                folder.mkdirs()
            end
        end
        
        local fileObj = File(filePath)
        if fileObj.exists() and fileObj.isDirectory() then
            fileObj.delete()
        end
        
        local file = io.open(filePath, "w")
        if not file then
            error("No se pudo crear el archivo")
        end
        file:write(content)
        file:close()
        return true
    end)
    
    return success
end
local function isValidApiKey(apiKey)
    if not apiKey or apiKey == "" then
        return false, "API Key vacía"
    end
    
    if #apiKey < MIN_API_KEY_LENGTH then
        return false, "API Key demasiado corta"
    end
    
    if apiKey:match("%s") then
        return false, "API Key contiene espacios"
    end
    
    return true, "API Key válida"
end
function leerConfiguracionVision()

    local apiKey = readFileSafe(PATHS.api_file)
    local modelo = readFileSafe(PATHS.model_file)
    
    if not modelo or modelo == "" then
        modelo = DEFAULT_MODEL

    else

    end
    
    if not apiKey or apiKey == "" then

        return nil, nil, "FILE_EMPTY"
    end
    
    local isValid, errorMsg = isValidApiKey(apiKey)
    if not isValid then

        return nil, nil, "FILE_INVALID"
    end
    

    return apiKey, modelo, nil
end
function guardarConfiguracionVision(apiKey, modelo)

    if not apiKey or apiKey == "" then
        return false, "API Key vacía"
    end
    
    apiKey = apiKey:gsub("^%s+", ""):gsub("%s+$", "")
    apiKey = apiKey:gsub('"', ''):gsub("'", '')
    
    local isValid, errorMsg = isValidApiKey(apiKey)
    if not isValid then
        return false, errorMsg
    end
    
    if not writeFileSafe(PATHS.api_file, apiKey) then
        return false, "Error escribiendo archivo de API"
    end
    
    modelo = modelo or DEFAULT_MODEL
    if not writeFileSafe(PATHS.model_file, modelo) then
        return false, "Error escribiendo archivo de modelo"
    end
    

    return true, "Configuración guardada correctamente"
end
function obtenerModelosDisponibles(apiKey, callback)
    import "android.os.AsyncTask"
    
    AsyncTask.execute(function()
        local success, err = pcall(function()
            local url = "https://generativelanguage.googleapis.com/v1beta/models?key=" .. apiKey
            
            local url_obj = URL(url)
            local connection = url_obj.openConnection()
            connection.setRequestMethod("GET")
            connection.setConnectTimeout(10000)
            connection.setReadTimeout(10000)
            
            local response_code = connection.getResponseCode()
            
            if response_code == 200 then
                local input_stream = connection.getInputStream()
                local reader = luajava.bindClass("java.io.BufferedReader")(luajava.bindClass("java.io.InputStreamReader")(input_stream))
                local response = {}
                local line = reader.readLine()
                while line do
                    table.insert(response, line)
                    line = reader.readLine()
                end
                reader.close()
                input_stream.close()
                
                local fullResponse = table.concat(response)
                
                local success_parse, json_obj = pcall(function()
                    return JSONObject(fullResponse)
                end)
                
                if success_parse then
                    local modelos = {}
                    local models_array = json_obj.getJSONArray("models")
                    
                    for i = 0, models_array.length() - 1 do
                        local model = models_array.getJSONObject(i)
                        local name = model.getString("name"):gsub("models/", "")
                        
                        local methods = model.getJSONArray("supportedGenerationMethods")
                        for j = 0, methods.length() - 1 do
                            if methods.getString(j) == "generateContent" then
                                table.insert(modelos, name)
                                break
                            end
                        end
                    end
                    
                    callback(true, modelos)
                else
                    callback(false, MODELOS_DISPONIBLES)
                end
            else
                callback(false, MODELOS_DISPONIBLES)
            end
            connection.disconnect()
        end)
        
        if not success then
            callback(false, MODELOS_DISPONIBLES)
        end
    end)
end
function mostrarDialogoConfiguracionVision()

    local currentApi = readFileSafe(PATHS.api_file) or ""
    local shouldFetchModels = false
    
    if currentApi ~= "" then
        local isValid, _ = isValidApiKey(currentApi)
        shouldFetchModels = isValid
    end
    
    local layout = LinearLayout(context)
    layout.setOrientation(LinearLayout.VERTICAL)
    layout.setPadding(40, 40, 40, 40)
    
    local instructionsText = TextView(context)
    instructionsText.setText("Configuración de Visión con Gemini\n\n" ..
                            "Pasos:\n" ..
                            "1. Obtén tu API Key en:\n   https://aistudio.google.com/apikey\n\n" ..
                            "2. Pégala abajo (mínimo " .. MIN_API_KEY_LENGTH .. " caracteres)\n\n" ..
                            "3. Selecciona el modelo\n\n" ..
                            "4. Presiona Guardar")
    instructionsText.setPadding(0, 0, 0, 20)
    instructionsText.setTextSize(14)
    layout.addView(instructionsText)
    
    local apiLabel = TextView(context)
    apiLabel.setText("API Key:")
    apiLabel.setTextSize(16)
    apiLabel.setPadding(0, 10, 0, 5)
    layout.addView(apiLabel)
    
    local editText = EditText(context)
    editText.setText(currentApi)
    editText.setHint("Pega tu API Key aquí")
    editText.setSingleLine(false)
    editText.setMinLines(2)
    layout.addView(editText)
    
    local modelLabel = TextView(context)
    modelLabel.setText("Modelo:")
    modelLabel.setTextSize(16)
    modelLabel.setPadding(0, 20, 0, 5)
    layout.addView(modelLabel)
    
    local spinner = Spinner(context)
    local modelsList = {}
    for _, model in ipairs(MODELOS_DISPONIBLES) do
        table.insert(modelsList, model)
    end
    
    local adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, modelsList)
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    spinner.setAdapter(adapter)
    
    local currentModel = readFileSafe(PATHS.model_file) or DEFAULT_MODEL
    for i = 0, #modelsList - 1 do
        if modelsList[i + 1] == currentModel then
            spinner.setSelection(i)
            break
        end
    end
    layout.addView(spinner)
    
    local modelInfoText = TextView(context)
    modelInfoText.setText("⏳ Cargando modelos disponibles...")
    modelInfoText.setTextSize(11)
    modelInfoText.setPadding(0, 5, 0, 0)
    layout.addView(modelInfoText)
    
    local reloadButton = Button(context)
    reloadButton.setText("🔄 Recargar Modelos Disponibles")
    reloadButton.setPadding(0, 10, 0, 0)
    layout.addView(reloadButton)
    
    local statusText = TextView(context)
    statusText.setText("")
    statusText.setPadding(0, 10, 0, 0)
    statusText.setTextSize(12)
    layout.addView(statusText)
    
    local saveButton = Button(context)
    saveButton.setText("Guardar y Cerrar")
    saveButton.setPadding(0, 30, 0, 0)
    layout.addView(saveButton)
    
    local dialog = LuaDialog(context)
    dialog.setTitle("Configurar Visión Gemini")
    dialog.setView(layout)
    dialog.show()
    
    local function updateModelsList(apiKey)
        modelInfoText.setText("⏳ Obteniendo modelos desde Google...")
        statusText.setText("")
        
        obtenerModelosDisponibles(apiKey, function(success, modelos)
            runOnUiThread(function()
                if success and #modelos > 0 then
                    modelsList = modelos
                    local newAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, modelsList)
                    newAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner.setAdapter(newAdapter)
                    
                    for i = 0, #modelsList - 1 do
                        if modelsList[i + 1] == currentModel then
                            spinner.setSelection(i)
                            break
                        end
                    end
                    
                    modelInfoText.setText("✓ " .. #modelos .. " modelos disponibles")
                    statusText.setText("💡 Modelos actualizados correctamente")
                else
                    modelInfoText.setText("⚠️ No se pudieron obtener modelos, usando lista básica")
                end
            end)
        end)
    end
    
    if shouldFetchModels then
        updateModelsList(currentApi)
    else
        modelInfoText.setText("💡 Ingresa tu API Key y presiona 🔄 para ver modelos disponibles")
    end
    
    reloadButton.setOnClickListener {
        onClick = function(view)
            local apiKey = editText.getText().toString()
            apiKey = apiKey:gsub("^%s+", ""):gsub("%s+$", "")
            
            if apiKey == "" then
                statusText.setText("❌ Ingresa una API Key primero")
                Toast.makeText(context, "Ingresa tu API Key primero", Toast.LENGTH_SHORT).show()
                return
            end
            
            local isValid, errorMsg = isValidApiKey(apiKey)
            if not isValid then
                statusText.setText("❌ " .. errorMsg)
                Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                return
            end
            
            updateModelsList(apiKey)
        end
    }
    
    saveButton.setOnClickListener {
        onClick = function(view)
            local apiKey = editText.getText().toString()
            apiKey = apiKey:gsub("^%s+", ""):gsub("%s+$", "")
            
            if apiKey == "" then
                statusText.setText("❌ Error: API Key vacía")
                Toast.makeText(context, "Por favor ingresa una API Key válida", Toast.LENGTH_LONG).show()
                return
            end
            
            local isValid, errorMsg = isValidApiKey(apiKey)
            if not isValid then
                statusText.setText("❌ Error: " .. errorMsg)
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                return
            end
            
            local selectedPosition = spinner.getSelectedItemPosition()
            local selectedModel = modelsList[selectedPosition + 1]
            local success, msg = guardarConfiguracionVision(apiKey, selectedModel)
            if success then
                Toast.makeText(context, "✓ Configuración guardada correctamente", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            else
                statusText.setText("❌ " .. msg)
                Toast.makeText(context, "Error: " .. msg, Toast.LENGTH_LONG).show()
            end
        end
    }
end



function describirImagen(imagePath)


    
    if not hasInternetConnection() then

        service.asyncSpeak("No hay conexión a Internet")
        return
    end
    
    local apiKey, modelo, error = leerConfiguracionVision()
    if not apiKey or not modelo then

        service.asyncSpeak("Configura tu API Key primero")
        runOnUiThread(function()
            mostrarDialogoConfiguracionVision()
        end)
        return
    end
    

    runOnUiThread(function()
        Toast.makeText(context, "🔍 Analizando imagen...", Toast.LENGTH_SHORT).show()
    end)
    
    local Thread = luajava.bindClass("java.lang.Thread")
    local Runnable = luajava.createProxy("java.lang.Runnable", {
        run = function()

            local success, err = pcall(function()
                local imageFile = File(imagePath)
                if not imageFile.exists() then
                    error("La imagen no existe")
                end
                

                local bytes
                local success_read = pcall(function()
                    local Files = luajava.bindClass("java.nio.file.Files")
                    local Paths = luajava.bindClass("java.nio.file.Paths")
                    bytes = Files.readAllBytes(Paths.get(imagePath))

                end)
                
                if not success_read then

                    local fileInputStream = luajava.newInstance("java.io.FileInputStream", imageFile)
                    local byteArrayOutputStream = luajava.newInstance("java.io.ByteArrayOutputStream", imageFile.length())
                    local buffer = luajava.newArray(luajava.bindClass("java.lang.Byte").TYPE, 8192)
                    
                    local bytesRead = fileInputStream.read(buffer)
                    while bytesRead ~= -1 do
                        byteArrayOutputStream.write(buffer, 0, bytesRead)
                        bytesRead = fileInputStream.read(buffer)
                    end
                    
                    fileInputStream.close()
                    bytes = byteArrayOutputStream.toByteArray()
                    byteArrayOutputStream.close()
                end
                

                local base64 = luajava.bindClass("android.util.Base64")
                local imageBase64 = base64.encodeToString(bytes, base64.NO_WRAP)
                
                if not imageBase64 or #imageBase64 == 0 then
                    error("Error al codificar imagen")
                end

                

                local StringBuilder = luajava.bindClass("java.lang.StringBuilder")
                local jsonBuilder = StringBuilder()
                
                jsonBuilder.append('{"contents":[{"parts":[{"text":"')
                jsonBuilder.append("Describe detalladamente esta imagen en español. Menciona todos los elementos visibles, colores, objetos, personas, texto y cualquier detalle relevante.")
                jsonBuilder.append('"},{"inline_data":{"mime_type":"image/jpeg","data":"')
                jsonBuilder.append(imageBase64)
                jsonBuilder.append('"}}]}],"generationConfig":{"temperature":0.4,"maxOutputTokens":8192}}')
                
                local jsonData = jsonBuilder.toString()

                

                local url = "https://generativelanguage.googleapis.com/v1beta/models/" .. modelo .. ":generateContent?key=" .. apiKey
                local connection = URL(url).openConnection()
                connection.setDoOutput(true)
                connection.setRequestMethod("POST")
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setConnectTimeout(60000)
                connection.setReadTimeout(60000)
                
                local OutputStreamWriter = luajava.bindClass("java.io.OutputStreamWriter")
                local writer = OutputStreamWriter(connection.getOutputStream(), "UTF-8")
                writer.write(jsonData)
                writer.flush()
                writer.close()
                

                local response_code = connection.getResponseCode()

                
                if response_code == 200 then

                    local BufferedReader = luajava.bindClass("java.io.BufferedReader")
                    local InputStreamReader = luajava.bindClass("java.io.InputStreamReader")
                    local reader = BufferedReader(InputStreamReader(connection.getInputStream()))
                    local response = {}
                    local line = reader.readLine()
                    while line do
                        table.insert(response, line)
                        line = reader.readLine()
                    end
                    reader.close()
                    
                    local success_parse, json_obj = pcall(function()
                        return JSONObject(table.concat(response))
                    end)
                    
                    if success_parse then

                        local candidates = json_obj.getJSONArray("candidates")
                        if candidates.length() > 0 then
                            local parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                            if parts.length() > 0 then
                                local descripcion = parts.getJSONObject(0).getString("text"):gsub("^%s+", ""):gsub("%s+$", "")

                                
                                runOnUiThread(function()
                                    service.copy(descripcion)
service.speak(descripcion)
play_music_dialogos(2, 0.3)
--                                    Toast.makeText(context, "descripcion", Toast.LENGTH_LONG).show()
                                end)

                            else

                                runOnUiThread(function()
                                    Toast.makeText(context, "Respuesta vacía de Gemini", Toast.LENGTH_LONG).show()
                                end)
                            end
                        else

                            runOnUiThread(function()
                                Toast.makeText(context, "No se pudo describir la imagen", Toast.LENGTH_LONG).show()
                            end)
                        end
                    else

                        runOnUiThread(function()
                            Toast.makeText(context, "Error al procesar respuesta", Toast.LENGTH_LONG).show()
                        end)
                    end
                else

                    runOnUiThread(function()
                        Toast.makeText(context, "Error de Gemini (código: " .. response_code .. ")", Toast.LENGTH_LONG).show()
                        if response_code == 400 or response_code == 401 or response_code == 403 then
                            mostrarDialogoConfiguracionVision()
                        end
                    end)
                end
                connection.disconnect()
            end)
            
            if not success then

                runOnUiThread(function()
                    Toast.makeText(context, "Error: " .. tostring(err), Toast.LENGTH_LONG).show()
                end)
            end
        end
    })
    
    local thread = Thread(Runnable)
    thread.setPriority(Thread.MIN_PRIORITY)
    thread.start()

end




local apiKey, modelo, error = leerConfiguracionVision()
if not apiKey or not modelo then

    service.asyncSpeak("Configura tu API Key antes de capturar")
    mostrarDialogoConfiguracionVision()
    return
end



if not createFolder(PATHS.vision) then

    service.asyncSpeak("Error al crear carpeta")
    return
end

service.asyncSpeak("Capturando pantalla")
task(500, function()
    this.getScreenShot(node, {
        onScreenCaptureDone = function(screenshot)

            local screenshotFile = File(PATHS.screenshot)
            local fileOutputStream = FileOutputStream(screenshotFile)
            screenshot.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream)
            fileOutputStream.close()
            

            service.asyncSpeak("Analizando imagen")
            

            describirImagen(PATHS.screenshot)
        end
    })
end)

return true